<?php require_once __DIR__ . '/application/utils/app_config.php'; ?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SalonHub | Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $app_name; ?>/public/img/icon/favicon.png">

    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/animate.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/slicknav.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/cart_style.css">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

    <style>
        .row::-webkit-scrollbar {
            width: 2px;
            height: 10px;
        }

        .row::-webkit-scrollbar-track {
            background: rgb(179, 177, 177);
            border-radius: 10px;
        }

        .row::-webkit-scrollbar-thumb {
            background-color: #0dcaf0;
            border-radius: 10px;
        }

        .row::-webkit-scrollbar-thumb:hover {
            background: #0dcaf0;
            border-radius: 10px;
        }

        .row::-webkit-scrollbar-thumb:active {
            background: #0dcaf0;
            border-radius: 10px;
        }

        .slick-arrow {
            background: none;
            border: none;
            color: rgba(26, 33, 61, 0.4);
            font-size: 23px;
        }

        .slick-arrow:hover {
            color: black;
        }

        .work_img {
            width: 65px;
            height: 65px;
        }
    </style>
</head>

<body>
    <!-- header -->
    <?php require_once __DIR__ . '/view/partials/top_bar.php'; ?>

    <main>

        <div class="slider-area hero-bg1">
            <div class="single-slider hero-overly  slider-height1 d-flex align-items-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-9 col-lg-11">

                            <div class="hero-caption pt-10">
                                <h1>"Beauty is our duty"</h1>
                                <p>Find salon and book easily for hair cuting.</p>
                            </div>

                            <div class="category-items text-center">
                                <ul>
                                    <li><a href="javascript:void(0)" class="active"><i class="fas fa-search"></i>&nbsp&nbsp Find</a></li>
                                    <li><a href="javascript:void(0)" class="active"><i class="fas fa-calendar-check"></i>&nbsp&nbsp Book</a></li>
                                    <li><a href="javascript:void(0)" class="active"><i class="fas fa-universal-access"></i>&nbsp&nbsp Experience</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <section class="great-stuffs section-padding" style="padding-bottom: 0px !important;">
            <div class="container" style="max-width: 100%;background:white;box-shadow:0px 1px 13px -2px rgba(0,0,0,0.5)">
                <div>
                    <div class="section-tittle text-center mb-35">
                        <h2>category</h2>
                    </div>
                </div>

                    
                
                </div>
            </div>
        </section>

        <section class="container">
            <div class="row justify-content-center ">
                <div class="col-xl-8 col-lg-9">
                    <div class="wantToWork-area w-padding2 mt-30" style="background: white;">
                        <div class="pera">
                            <h2>find more category?</h2>
                            <p>10,563 listing for you on our list.</p>
                        </div>
                        <div class="linking">
                            <a href="<?php echo $app_name; ?>/view/all_category.php" class="btn wantToWork-btn">Explore More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="popular-directorya-area section-padding fix">
            <div class="container-fluid" style="background:white;box-shadow:0px 1px 13px -2px rgba(0,0,0,0.5)">
                <div class="row">
                    <div class="col-lg-12">

                        <div class="section-tittle text-center mb-35">
                            <h2>Popular Salon</h2>
                            <p>Popular Exclusive Listings In Our Directory</p>
                        </div>
                    </div>
                </div>
                <div class="directory-active row d-flex" id="popular_salon_div">

                          <div class="contact">
                                    <ul>
                                        <li><a href="tel:${getsalon.mobile_no}"><i class="fas fa-phone-alt"></i></a></li>
                                        <li><a href="mailto:${getsalon.email_id}"><i class="far fa-envelope"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> 
                
                </div>
            </div>

            <section class="container">
                <div class="row justify-content-center ">
                    <div class="col-xl-8 col-lg-9">
                        <div class="wantToWork-area w-padding2 mt-30" style="background: white;">
                            <div class="pera">
                                <h2>Do you want to find more Salon?</h2>
                                <p>10,563 listing for you on our list.</p>
                            </div>
                            <div class="linking">
                                <a href="<?php echo $app_name; ?>/view/all_salon.php" class="btn wantToWork-btn">Explore More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </section>


        <section class="our-services section-padding position-relative">
            <div class="container">
                <div class="row justify-content-sm-center">
                    <div class="col-xl-7 col-lg-8 col-md-11">

                        <div class="section-tittle text-center mb-70">
                            <h2>How It Work?</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-between">
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-6">
                        <div class="single-services text-center mb-30">
                            <div class="services-icon">
                                <img class="work_img" src="<?php echo $app_name; ?>/public/img/icon/search.webp" alt="">
                            </div>
                            <div class="services-cap">
                                <h5><a href="#">Find Salons</a></h5>
                                <p>Discover the widest selection of salons in and around your area.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-6">
                        <div class="single-services text-center mb-30">
                            <div class="services-icon">
                                <img class="work_img" src="<?php echo $app_name; ?>/public/img/icon/appointment.webp" alt="">
                            </div>
                            <div class="services-cap">
                                <h5><a href="#">Online Appointments</a></h5>
                                <p>Select your preferred time slot and book appointments online with just a tap or two.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 col-sm-6">
                        <div class="single-services text-center mb-30">
                            <div class="services-icon">
                                <img class="work_img" src="<?php echo $app_name; ?>/public/img/icon/waiting.webp" alt="">
                            </div>
                            <div class="services-cap">
                                <h5><a href="#">Zero Waiting Time</a></h5>
                                <p>No more waiting in the queues. Turn up to the venue at your selected time and enjoy.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
    <!-- footer -->
    <?php require_once __DIR__ . '/view/partials/footer.php'; ?>

    <div id="back-top">
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>


    <script>
        var appname = "<?php echo $app_name; ?>";
    </script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/popper.min.js+bootstrap.min.js.pagespeed.jc.rDz9KUXW0v.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/salon_booking.js"></script>

    <script>
        eval(mod_pagespeed_h6FSS0R5Nk);
    </script>
    <script>
        eval(mod_pagespeed_nAF17_H0Ki);
    </script>

    <script src="<?php echo $app_name; ?>/public/js/owl.carousel.min.js+slick.min.js.pagespeed.jc.Dccc_xx8PD.js"></script>
    <script>
        eval(mod_pagespeed_4EWkIIjjEL);
    </script>
    <script>
        eval(mod_pagespeed_b61UQMOxQz);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.slicknav.min.js+wow.min.js+jquery.magnific-popup.js+jquery.nice-select.min.js+jquery.counterup.min.js+waypoints.min.js+contact.js.pagespeed.jc.isQq4h3kta.js"></script>
    <script>
        eval(mod_pagespeed_u74TJ7b4ya);
    </script>

    <script>
        eval(mod_pagespeed_jkoDhHOz0u);
    </script>
    <script>
        eval(mod_pagespeed_LXmZQChS9I);
    </script>
    <script>
        eval(mod_pagespeed_weSlV7qHIh);
    </script>
    <script>
        eval(mod_pagespeed_5FaTDDR9BI);
    </script>
    <script>
        eval(mod_pagespeed_$E6h4J_eHl);
    </script>

    <script>
        eval(mod_pagespeed_3Bn1QXBxeT);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.form.js+jquery.validate.min.js+mail-script.js+jquery.ajaxchimp.min.js+plugins.js+main.js.pagespeed.jc.UiK9nRMxfh.js"></script>
    <script>
        eval(mod_pagespeed_wwngUhmEap);
    </script>
    <script>
        eval(mod_pagespeed_p1DPFKbsIO);
    </script>
    <script>
        eval(mod_pagespeed_qHuP$p3A$U);
    </script>
    <script>
        eval(mod_pagespeed_cha65DBll0);
    </script>
    <script>
        eval(mod_pagespeed__9GFzCTG35);
    </script>
    <script>
        eval(mod_pagespeed_3_hkYAdE2S);
    </script>

    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script>
        $('.slider-catagory').slick({
            slidesToShow: 6,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 2000,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 1,
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }
            ],
            prevArrow: $(".slick-prev-1"),
            nextArrow: $(".slick-next-1")
        });
    </script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

</body>

</html>
<script>
    /* get popular salon */
    getPopularSalon();

    /* get top 10 category */
    topCategories();

    /* toggle profile */
    $('#header_profile_part').click(function() {
        $('.fa-chevron-down').toggleClass("arrow-dropdown-toggle");
        $('.dropdown-menu').toggle(".dropdown-toggle");
    })

    /* hide cart */
    $('.cartbox-close,.body-overlay').click(function() {
        $('.cartbox-wrap').removeClass("is-visible");
    })

    /* show cart */
    $('#cart').click(function() {
        $('.cartbox-wrap').addClass("is-visible");
    })

    /*  */
    
</script>