<?php
require_once __DIR__ . '/../../application/utils/app_config.php';
?>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<style>
.dropdown-menu > li > a.text-primary {
	color: #0071DC !important;
}
.dropdown-menu > li > a.text-success {
	color: #00cc52 !important;
}
.dropdown-menu > li > a.text-danger {
	color: #ff0100 !important;
}
.dropdown-menu > li > a.text-info {
	color: #009efb !important;
}
.dropdown-menu > li > a.text-warning {
	color: #ffbc34 !important;
}
.dropdown-menu > li > a.text-purple {
	color: #7460ee !important;
}

.dropdown-menu {
    background-color: #fff;
    border: 1px solid rgba(0, 0, 0, 0.1);
    border-radius: 3px;
    box-shadow: inherit;
	font-size: 14px;
    transform-origin: left top 0;
    display: none;
}
.dropdown-item.active, .dropdown-item:active {
    background-color: #0071DC;
}
.dropdown-menu {
	border: 0;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	background-color: #fff;
}

.dropdown-menu {
	border: 0;
	box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
}
.dropdown-toggle::after {
	display: none;
}
.dropdown-menu::before {
	content: "";
	position: absolute;
	top: 2px;
	right: 0;
	border: 7px solid #fff;
	border-color: transparent transparent #ffffff #ffffff;
	transform-origin: 0 0;
	transform: rotate(135deg);
	box-shadow: -2px 2px 2px -1px rgba(0, 0, 0, 0.1);
}
.dropdown-menu .dropdown-item {
	border-top: 1px solid #f0f0f0;
	padding: 10px 15px;
}
.dropdown-menu .dropdown-item:first-child {
	border-top: 0;
	border-radius: 5px 5px 0 0;
}
.dropdown-menu .dropdown-item:last-child {
	border-radius: 0 0 5px 5px;
}

.dropdown-menu a:hover {
    color: #10DEFD;
	letter-spacing: 0.5px;
	padding-left: 20px;
	background-color: #fff;
}

.dropdown-menu {
    min-width: 200px;
    padding: 0;
	top: 100%;
    right: 0;
    left: auto;
}
.dropdown-menu .dropdown-item {
    padding: 7px 15px;
}
.dropdown-menu .dropdown-item {
	align-items: center;
	display: flex;
    border-top: 1px solid #e3e3e3;
    padding: 10px 15px;
}
.dropdown-menu .dropdown-item:hover {
    color: #09dca4;
}
.user-header {
	display: flex;
    padding: 10px 15px;
}
.user-header .user-text {
	margin-left: 10px;
}
.user-header .user-text h6 {
	font-size: 15px;
    margin-bottom: 2px;
}
.arrow-dropdown-toggle{
    transform: rotate(180deg);
    transition: all 0.15s ease-in-out;
}
</style>
<header>
    <div class="header-area header-transparent">
        <div class="main-header header-sticky">
            <div class="container-fluid" style="margin: 20px;">
                <div class="menu-wrapper d-flex align-items-center justify-content-between">
                    <div class="left-content d-flex align-items-center">
                        <div class="logo">
                            <a href="<?php echo $app_name; ?>/index.php">

                                <img style="width:120px" src="<?php echo $app_name; ?>/public/img/logo/saloon_logo1.png" alt="">
                            </a>
                        </div>
                    </div>

                    <form action="#" method="GET" class="form-box">
                        <input type="text" name="searchtxt" placeholder="Search Saloon" required>
                        <div class="search-icon">
                            <button type="submit" style="background: none;outline:none;border:none"><i class="fas fa-search"></i></button>
                        </div>
                    </form>


                    <div class="buttons" style="display:-webkit-inline-box;margin-top:15px">

                    
                        <a href="<?php echo $app_name; ?>/view/auth/register.php" class="btn header-btn2 mr-30" style="padding: 20px !important;">Sign Up</a>
                       
                        <!-- <div _ngcontent-osv-c105="" class="dropdown-menu dropdown-menu-end" style="right: 25px !important; " data-bs-popper="none">
                            <div _ngcontent-osv-c105="" class="user-header">
                                <div _ngcontent-osv-c105="" class="avatar avatar-sm"><i class="fas fa-user-circle" style="font-size: 25px;margin-right: 5px;"></i>
                                    
                                </div>
                                <div _ngcontent-osv-c105="" class="user-text">
                                    <h6 _ngcontent-osv-c105=""><?php //echo $sessionManager->get('logged_in_user')->firstName; ?></h6>
                                </div>
                            </div><a _ngcontent-osv-c105="" class="dropdown-item" style="cursor: pointer;" href="<?php //echo $app_name; ?>/view/profile.php"><i class="fa-solid fa-gear" style="margin-right: 5px;"></i>Profile Settings</a>
                        
                            <a _ngcontent-osv-c105="" class="dropdown-item" style="cursor: pointer;" href="<?php //echo $app_name; ?>/application/auth/logout.php"><i class="fas fa-sign-out-alt" style="margin-right: 5px;"></i></i>Logout</a>
                        </div> -->
                    </div>
                </div>

                <div class="col-12">
                    <div class="mobile_menu d-block d-lg-none"></div>
                </div>
            </div>
        </div>
    </div>
</header>
