<?php require_once __DIR__ .'/../../application/utils/app_config.php'; ?>
<footer>
    <div class="footer-wrapper gray-bg">
        <div class="footer-area footer-padding">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-8">
                        <div class="single-footer-caption mb-50">
                            <div class="single-footer-caption mb-20">

                                <div class="footer-logo mb-35">
                                    <a href="<?php echo $app_name; ?>/index.php"><img style="width:120px" src="<?php echo $app_name; ?>/public/img/logo/saloon_logo1.png" alt=""></a>
                                </div>
                                <div class="footer-tittle">
                                    <div class="footer-pera">
                                        <p>Saloon Hub aims to connect those who are passionate about looks and beauty with the best of holistic looks, beauty, and makeup artists with utmost ease and high customer delight.</p>
                                    </div>
                                </div>

                                <div class="footer-social">
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                    <a href="#"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="offset-xl-1 col-xl-2 col-lg-2 col-md-4 col-sm-6">
                        <div class="single-footer-caption mb-50">
                            <div class="footer-tittle">
                                <h4>CONTACT</h4>
                                <ul>
                                    <li><a href="<?php echo $app_name; ?>/view/contact_us.php">Contact Us</a></li>
                                    <li><a href="<?php echo $app_name; ?>/view/about_us.php">About Us</a></li>
                                    <li><a href="#">Partner With Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                   
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-8">
                        <div class="single-footer-caption mb-50">
                            <div class="footer-tittle mb-10">
                                <h4>Subscribe newsletter</h4>
                                <p>Subscribe our newsletter to get updates about our services and offers.</p>
                            </div>

                            <div class="footer-form mb-20">
                                <div id="mc_embed_signup">
                                    <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" class="subscribe_form relative mail_part">
                                        <input type="email" name="email" id="newsletter-form-email" placeholder="Enter your email" class="placeholder hide-on-focus">
                                        <div class="form-icon">
                                            <button type="submit" name="submit" id="newsletter-submit" class="email_icon newsletter-submit button-contactForm">
                                                <i class="fas fa-arrow-right"></i>
                                            </button>
                                        </div>
                                        <div class="mt-10 info"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-bottom-area">
            <div class="container">
                <div class="footer-border">
                    <div class="row">
                        <div class="col-xl-12 ">
                            <div class="footer-copy-right text-center">
                                <p>Copyright &copy;<script>
                                        document.write(new Date().getFullYear());
                                    </script> Salon Hub Web Services. All Rights Reserved</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>