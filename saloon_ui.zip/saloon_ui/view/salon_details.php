<?php
require_once __DIR__ . '/../application/utils/app_config.php';
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SalonHub | Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $app_name; ?>/public/img/icon/favicon.png">

    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/animate.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/slicknav.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/cart_style.css">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

    <script src="<?php echo $app_name; ?>/public/js/vendor/jquery-1.12.4.min.js"></script>
    <style>
        .width {
            width: 100%;
        }

        .add-cart {
            background: white;
            border: 1px solid #4DB7FE;
            color: #4DB7FE;
            padding: 10px 14px;
            border-radius: 50%;
            margin-top: 8px;
        }

        .add-cart:hover {
            background: #4DB7FE;
            color: white;
        }

        .product_name_a:hover {
            color: black;
        }

        .cartbox__items::-webkit-scrollbar {
            display: none;
        }

        .cartbox__buttons {
            position: fixed;
            bottom: 0;
            width: 86%;
        }

        .sloat_time ul label {
            padding: 7px;
            margin: 5px;
            border: 1px solid lightgray;
            border-radius: 5px;
            white-space: nowrap;
            cursor: pointer;
            /* inactive */
            /* background-color: #a3a3a3;  */
        }

        .active-slot {
            background-color: #4DB7FE;
        }

        .price {
            width: 30%;
            border: none;
            background: none;
            pointer-events: none;
        }

        .dropdown-menu>li>a.text-primary {
            color: #0071DC !important;
        }

        .dropdown-menu>li>a.text-success {
            color: #00cc52 !important;
        }

        .dropdown-menu>li>a.text-danger {
            color: #ff0100 !important;
        }

        .dropdown-menu>li>a.text-info {
            color: #009efb !important;
        }

        .dropdown-menu>li>a.text-warning {
            color: #ffbc34 !important;
        }

        .dropdown-menu>li>a.text-purple {
            color: #7460ee !important;
        }

        .dropdown-menu {
            background-color: #fff;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 3px;
            box-shadow: inherit;
            font-size: 14px;
            transform-origin: left top 0;
            display: none;
        }

        .dropdown-item.active,
        .dropdown-item:active {
            background-color: #0071DC;
        }

        .dropdown-menu {
            border: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        .dropdown-menu {
            border: 0;
            box-shadow: 0 0 3px rgba(0, 0, 0, 0.1);
        }

        .dropdown-toggle::after {
            display: none;
        }

        .dropdown-menu::before {
            content: "";
            position: absolute;
            top: 2px;
            right: 0;
            border: 7px solid #fff;
            border-color: transparent transparent #ffffff #ffffff;
            transform-origin: 0 0;
            transform: rotate(135deg);
            box-shadow: -2px 2px 2px -1px rgba(0, 0, 0, 0.1);
        }

        .dropdown-menu .dropdown-item {
            border-top: 1px solid #f0f0f0;
            padding: 10px 15px;
        }

        .dropdown-menu .dropdown-item:first-child {
            border-top: 0;
            border-radius: 5px 5px 0 0;
        }

        .dropdown-menu .dropdown-item:last-child {
            border-radius: 0 0 5px 5px;
        }

        .dropdown-menu a:hover {
            color: #10DEFD;
            letter-spacing: 0.5px;
            padding-left: 20px;
            background-color: #fff;
        }

        .dropdown-menu {
            min-width: 200px;
            padding: 0;
            top: 100%;
            right: 0;
            left: auto;
        }

        .dropdown-menu .dropdown-item {
            padding: 7px 15px;
        }

        .dropdown-menu .dropdown-item {
            align-items: center;
            display: flex;
            border-top: 1px solid #e3e3e3;
            padding: 10px 15px;
        }

        .dropdown-menu .dropdown-item:hover {
            color: #09dca4;
        }

        .user-header {
            display: flex;
            padding: 10px 15px;
        }

        .user-header .user-text {
            margin-left: 10px;
        }

        .user-header .user-text h6 {
            font-size: 15px;
            margin-bottom: 2px;
        }

        .arrow-dropdown-toggle {
            transform: rotate(180deg);
            transition: all 0.15s ease-in-out;
        }
    </style>
</head>

<body>
    <!-- header -->
    <?php require_once __DIR__ .'/partials/top_bar.php'; ?>

    <main>

        <div class="slider-area hero-bg1">
            <div class="single-slider hero-overly slider-height3 d-flex align-items-end">
                <div class="container">
                    <div class="directory-details-head pb-40">
                        <div class="wants-wrapper w-padding3">
                            <div class="row align-items-center justify-content-between">
                                <div class="col-xxl-8 col-xl-6 col-lg-6">
                                    <div class="details-cap d-flex">
                                        <div class="icon">
                                            <img src="<?php echo $app_name; ?>/public/img/icon/salon2.png">
                                        </div>
                                        <div class="properties__caption">
                                            <h3><a href="javascript:void(0)" id="salon_name">Raj Hair salon</a></h3>
                                            <p id="salon_address"><i class="fas fa-map-marker-alt"></i>&nbsp&nbspToronto, ON</p>
                                            <div class="img-text">
                                                <span class="open" style="font-weight:bold" id="salon_status">Open now</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xxl-4 col-xl-6 col-lg-6">
                                    <div class="double-btn f-right  d-flex flex-wrap">
                                        <a href="" id="email" class="border-btn w-btn wantToWork-btn"><i class="fas fa-envelope"></i>Email</a>
                                        <a href="" id="phone" class="btn w-btn wantToWork-btn  ml-20"><i class="fas fa-phone-alt"></i>Call Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="directory-details section-padding">
            <div class="container">
                <div class="row" id="salon_service">
                        <div style="width: 100%;background:#4DB7FE;height:50px;margin-bottom:15px;">
                            <h3 style="color:white;margin-top:10px;font-weight: 600 !important;">Hair cut</h3>
                        </div>
                                <!-- <script>
                                    var url = `<?php //echo $app_name; ?>/application/master/master_action_handler.php?action=check_cart_item&service_id=<?php echo $service['service_id']; ?>`;
                                    $.get(url, function(data) {
                                        var result = JSON.parse(data);
                                        var is_exist = result.responseContent.is_exist;
                                        var text = "";
                                        if (is_exist) {
                                            text = '<i class="fas fa-check"></i>'
                                        } else {
                                            text = '<i class="fas fa-cart-plus"></i>'
                                        }
                                        $('#btn_<?php //echo $service['service_id']; ?>').html(text);
                                    })
                                </script> -->
                                <div class="col-lg-2 col-md-2 col-sm-4 col-6 mb-4 item_div">
                                    <div class="single_product" style="background-color: white;box-shadow: 0 1px 3px rgb(0 0 0 / 11%);padding: 5px 0;border-radius: 5px;">
                                        <div class="product_content grid_content text-center" style="margin: 7px;">
                                            <form method="post" id="1">
                                                <h4 class="product_name">
                                                    <a class="product_name_a" href="#">Hair cut</a>
                                                </h4>
                                                <div class="price_box">
                                                    <span class="current_price">$ 20</span>

                                                </div>
                                                <input type="hidden" name="service_id" value="1">
                                                <button class="add-cart" type="submit" id="btn_1"><i class="fas fa-cart-plus"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                </div>
            </div>
        </div>

    </main>
    <!-- footer -->
    <?php require_once __DIR__ . '/partials/footer.php'; ?>

    <div id="back-top">
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>

    <!--**********************************
        cart box start
    ***********************************-->
    <div class="cartbox-wrap">
        <div class="body-overlay"></div>
        <div class="cartbox text-right">
            <button class="cartbox-close" style="color: black;"><i class="fas fa-times"></i></button>
            <form action="#" method="POST" id="booking_form">
                <div class="cartbox__inner text-left">
                    <div id="price-div">
                        <div class="d-flex" style="width: 100%;background:#4DB7FE;margin-bottom:15px;margin-top:15px;padding:5px">
                            <div class="cartbox__item__content">
                                <span class="text-white">Service</span>
                            </div>
                            <div class="cartbox__item__content">
                                <span class="text-white">Price</span>
                            </div>
                            <button class="cartbox__item__remove">

                            </button>
                        </div>
                        <div class="cartbox__items" id="Cart_item_div" style="max-height: 200px;overflow: auto;">
                            <!-- Cartbox Single Item -->
                        <div class="cartbox__item">
                        <div class="cartbox__item__thumb">
                            <a href="javascript:void(0)">
                                <img src="${appname}/public/img/gallery/directory4.jpg" alt="small thumbnail">
                            </a>
                        </div>
                        <div class="cartbox__item__content">
                            <h5><a href="javascript:void(0)" class="product-name">${getCartItem.service_name}</a></h5>
                            <span class="price">₹${getCartItem.price}</span>
                        </div>
                        <button class="cartbox__item__remove">
                            <i class="fa fa-trash"></i>
                        </button>
                         <!-- //Cartbox Single Item -->
                        </div>
                        <div class="cartbox__total">
                            <ul>
                                <li class="grandtotal">Total<input type="text" class="price" name="total" id="total_price" value="₹ 0.00">
                                    <p></p>
                                </li>
                            </ul>
                        </div>
                        <div class="cartbox__buttons">
                            <button type="button" class="btn header-btn2" id="bookin_btn" style="border-radius: 7px 7px 0px 0px;width:100%" href="javascript:void(0)"><span>
                                    Choose Date & Time</span></button>
                        </div>
                    </div>
                    <div id="date-time" style="display:none">
                        <div class="form-group">
                            <label>Choose slot Date</label>
                            <input class="form-control valid input-box" onchange="getSlotTime(this.value,salon_id)" min="<?= date('Y-m-d'); ?>" max="<?= date('Y-m-t'); ?>" name="sloat_date" id="date" type="date">
                            <p style="color: #ea4c62;margin-top:5px;display:none" id="sloat_date_error">*Please select date</p>
                        </div>
                        <div class="sloat_time" style="display: none;">
                            <label>Choose time slot</label>
                            <ul style="display: flex;overflow:auto" id="slot_time_div">

                            </ul>
                            <p style="color: #ea4c62;margin-top:5px;display:none" id="sloat_time_error">*Please select time</p>
                        </div>
                        <div class="specialist">
                            <label>Choose Specialist</label>
                            <?php
                            echo dropdown('specialist', null, $specialist, ['id' => 'specialist', 'class' => 'nice-select form-control']);
                            ?>
                            <p style="color: #ea4c62;margin-top:5px;display:none" id="specialist_error">*Please select Specialist</p>
                        </div>
                        <input type="hidden" name="salon_by_id" value="<?php echo $salon_id; ?>">
                        <div class="cartbox__buttons">
                            <button type="button" onclick="place_booking()" class="btn header-btn2" style="border-radius: 7px 7px 0px 0px;width:100%" id="booking_btn"><span>
                                    Make Booking Confirm</span></button>
                        </div>
                    </div>

                </div>

            </form>
        </div>

    </div>

    <!--**********************************
        cart box end
    ***********************************-->

    <script>
        var appname = "<?php echo $app_name; ?>";
        var salon_id = "<?php echo $salon_id; ?>";
    </script>

    <script src="<?php echo $app_name; ?>/public/js/vendor/modernizr-3.5.0.min.js"></script>

    <script src="<?php echo $app_name; ?>/public/js/popper.min.js+bootstrap.min.js.pagespeed.jc.rDz9KUXW0v.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/salon_booking.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/ajax-form-request.js"></script>


    <script>
        eval(mod_pagespeed_h6FSS0R5Nk);
    </script>
    <script>
        eval(mod_pagespeed_nAF17_H0Ki);
    </script>

    <script src="<?php echo $app_name; ?>/public/js/owl.carousel.min.js+slick.min.js.pagespeed.jc.Dccc_xx8PD.js"></script>
    <script>
        eval(mod_pagespeed_4EWkIIjjEL);
    </script>
    <script>
        eval(mod_pagespeed_b61UQMOxQz);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.slicknav.min.js+wow.min.js+jquery.magnific-popup.js+jquery.nice-select.min.js+jquery.counterup.min.js+waypoints.min.js+contact.js.pagespeed.jc.isQq4h3kta.js"></script>
    <script>
        eval(mod_pagespeed_u74TJ7b4ya);
    </script>

    <script>
        eval(mod_pagespeed_jkoDhHOz0u);
    </script>
    <script>
        eval(mod_pagespeed_LXmZQChS9I);
    </script>
    <script>
        eval(mod_pagespeed_weSlV7qHIh);
    </script>
    <script>
        eval(mod_pagespeed_5FaTDDR9BI);
    </script>
    <script>
        eval(mod_pagespeed_$E6h4J_eHl);
    </script>

    <script>
        eval(mod_pagespeed_3Bn1QXBxeT);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.form.js+jquery.validate.min.js+mail-script.js+jquery.ajaxchimp.min.js+plugins.js+main.js.pagespeed.jc.UiK9nRMxfh.js"></script>
    <script>
        eval(mod_pagespeed_wwngUhmEap);
    </script>
    <script>
        eval(mod_pagespeed_p1DPFKbsIO);
    </script>
    <script>
        eval(mod_pagespeed_qHuP$p3A$U);
    </script>
    <script>
        eval(mod_pagespeed_cha65DBll0);
    </script>
    <script>
        eval(mod_pagespeed__9GFzCTG35);
    </script>
    <script>
        eval(mod_pagespeed_3_hkYAdE2S);
    </script>
</body>

</html>

<script>
    /* toggle profile */
    $('#header_profile_part').click(function() {
        $('.fa-chevron-down').toggleClass("arrow-dropdown-toggle");
        $('.dropdown-menu').toggle(".dropdown-toggle");
    })

    /* get details */
    salon_details(salon_id);

    /* add to cart service */
    function handleAddToCartService(form_id, event) {
        handleAjaxFormRequest(form_id, event, successCallBack, errorCallBack);
    }
    const successCallBack = function(data) {
        getCartItems(salon_id);
    }

    const errorCallBack = function(data) {
        alert('Please LogIn First !');
        window.location.href = "<?php echo $app_name; ?>/view/auth/login.php";
    }



    /* hide cart */
    $('.cartbox-close,.body-overlay').click(function() {
        $('.cartbox-wrap').removeClass("is-visible");
    })

    /* show cart */
    $('#cart').click(function() {
        $('.cartbox-wrap').addClass("is-visible");
    })

    /* get cart item by salon */
    getCartItems(salon_id);

    $('.sloat_time ul').on('click', 'input[type=radio]', function() {
        if ($(this).is(':checked')) {
            $(this).prevAll().removeClass('active-slot');
            $(this).nextAll().removeClass('active-slot');
            $(this).next().addClass('active-slot');

            var slot_time = $(this).next().text();
        }
    })

    $('#bookin_btn').on('click', function() {
        $('#price-div').hide();
        $('#date-time').show();

    })
</script>