<?php require_once __DIR__ . '/../application/utils/app_config.php'; ?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SalonHub | Home</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $app_name; ?>/public/img/icon/favicon.png">

    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/animate.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/slicknav.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/style.css">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <style>
        .slick-arrow {
            background: none;
            border: none;
            color: rgba(26, 33, 61, 0.4);
            font-size: 23px;
        }

        .slick-arrow:hover {
            color: black;
        }

        .sitemap {
            color: black;
            font-size: 24px;
        }

        .sitemap:hover {
            color: #4DB7FE;
        }

        .properties-card {
            background: white;
        }
    </style>
</head>

<body>
    <!-- header -->
    <?php require_once __DIR__ .'/partials/top_bar.php'; ?>
    <main>

        <div class="slider-area">
            <div class="slider-height2 hero-bg2 hero-overly d-flex align-items-center">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-caption hero-caption2">
                                <h2>All Salons</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="listing-area section-padding">
            <div class="container">
                <div class="row justify-content-between">

                    <div class="col-xl-12 col-lg-12 col-md-12">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="count mb-25">
                                    <span id="salon_count"></span>
                                </div>
                            </div>
                        </div>

                       


                    </div>
                </div>
            </div>
        </div>

    </main>

    <!-- footer -->
    <?php require_once __DIR__ . '/partials/footer.php'; ?>

    <div id="back-top">
        <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
    </div>

    <script>
        var appname = "<?php echo $app_name; ?>";
    </script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/popper.min.js+bootstrap.min.js.pagespeed.jc.rDz9KUXW0v.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/salon_booking.js"></script>

    <script>
        eval(mod_pagespeed_h6FSS0R5Nk);
    </script>
    <script>
        eval(mod_pagespeed_nAF17_H0Ki);
    </script>

    <script src="<?php echo $app_name; ?>/public/js/owl.carousel.min.js+slick.min.js.pagespeed.jc.Dccc_xx8PD.js"></script>
    <script>
        eval(mod_pagespeed_4EWkIIjjEL);
    </script>
    <script>
        eval(mod_pagespeed_b61UQMOxQz);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.slicknav.min.js+wow.min.js+jquery.magnific-popup.js+jquery.nice-select.min.js+jquery.counterup.min.js+waypoints.min.js+contact.js.pagespeed.jc.isQq4h3kta.js"></script>
    <script>
        eval(mod_pagespeed_u74TJ7b4ya);
    </script>

    <script>
        eval(mod_pagespeed_jkoDhHOz0u);
    </script>
    <script>
        eval(mod_pagespeed_LXmZQChS9I);
    </script>
    <script>
        eval(mod_pagespeed_weSlV7qHIh);
    </script>
    <script>
        eval(mod_pagespeed_5FaTDDR9BI);
    </script>
    <script>
        eval(mod_pagespeed_$E6h4J_eHl);
    </script>

    <script>
        eval(mod_pagespeed_3Bn1QXBxeT);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.form.js+jquery.validate.min.js+mail-script.js+jquery.ajaxchimp.min.js+plugins.js+main.js.pagespeed.jc.UiK9nRMxfh.js"></script>
    <script>
        eval(mod_pagespeed_wwngUhmEap);
    </script>
    <script>
        eval(mod_pagespeed_p1DPFKbsIO);
    </script>
    <script>
        eval(mod_pagespeed_qHuP$p3A$U);
    </script>
    <script>
        eval(mod_pagespeed_cha65DBll0);
    </script>

    <script>
        eval(mod_pagespeed__9GFzCTG35);
    </script>
    <script>
        eval(mod_pagespeed_3_hkYAdE2S);
    </script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" -beacon='{"rayId":"6e3855f75f5c8575","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.12.0","si":100}' crossorigin="anonymous"></script>
</body>

</html>

<script>
    /* get all salon */
    getAllSalon();

    /* toggle profile */
    $('#header_profile_part').click(function() {
        $('.fa-chevron-down').toggleClass("arrow-dropdown-toggle");
        $('.dropdown-menu').toggle(".dropdown-toggle");
    })
</script>
