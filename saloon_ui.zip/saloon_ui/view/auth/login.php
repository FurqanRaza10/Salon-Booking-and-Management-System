<?php require_once __DIR__ . '/../../application/utils/app_config.php'; ?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SalonHub | Login</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $app_name; ?>/public/img/icon/xfavicon.png.pagespeed.ic.T_b7aM30ll.webp">

    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/animate.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/slicknav.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/style.css">
    <script nonce="7a331344-5e58-4e85-b67f-060320819682">
        (function(w, d) {
            ! function(a, e, t, r, z) {
                a.zarazData = a.zarazData || {}, a.zarazData.executed = [], a.zarazData.tracks = [], a.zaraz = {
                    deferred: []
                };
                var s = e.getElementsByTagName("title")[0];
                s && (a.zarazData.t = e.getElementsByTagName("title")[0].text), a.zarazData.w = a.screen.width, a.zarazData.h = a.screen.height, a.zarazData.j = a.innerHeight, a.zarazData.e = a.innerWidth, a.zarazData.l = a.location.href, a.zarazData.r = e.referrer, a.zarazData.k = a.screen.colorDepth, a.zarazData.n = e.characterSet, a.zarazData.o = (new Date).getTimezoneOffset(), a.dataLayer = a.dataLayer || [], a.zaraz.track = (e, t) => {
                    for (key in a.zarazData.tracks.push(e), t) a.zarazData["z_" + key] = t[key]
                }, a.zaraz._preSet = [], a.zaraz.set = (e, t, r) => {
                    a.zarazData["z_" + e] = t, a.zaraz._preSet.push([e, t, r])
                }, a.dataLayer.push({
                    "zaraz.start": (new Date).getTime()
                }), a.addEventListener("DOMContentLoaded", (() => {
                    var t = e.getElementsByTagName(r)[0],
                        z = e.createElement(r);
                    z.defer = !0, z.src = "/cdn-cgi/zaraz/s.js?z=" + btoa(encodeURIComponent(JSON.stringify(a.zarazData))), t.parentNode.insertBefore(z, t)
                }))
            }(w, d, 0, "script");
        })(window, document);
    </script>
    <style>
        .back-arrow {
            font-size: 20px;
            position: absolute;
            top: 35px;
            cursor: pointer;
        }

        .error {
            color: red !important;
            width: 100%;
            font-size: 17px !important;
            margin-bottom: 5px !important;
        }
    </style>
</head>

<body>
    <main class="login-bg">

        <div class="login-form-area">
            <div class="login-form">
                <!-- <div class="back-arrow">
                    <a href="<?php echo $app_name; ?>/index.php" style="color:black">
                        <svg class="bi bi-arrow-left" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"></path>
                        </svg>
                    </a>
                </div> -->
                <div class="login-heading">
                    <span>Login</span>
                    <p>Enter Login details to get access</p>
                    <span class="error" id="error_msg" style="display: none;"></span>
                </div>
                <form id="login_form" method="POST" onsubmit="handleLogin();">
                    <div class="input-box">
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Username or Email Address</label>
                            <input type="text" class="email" name="email" placeholder="Username / Email address">
                        </div>
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Password</label>
                            <input type="password" class="password" name="password" placeholder="Enter Password">
                        </div>
                        <div class="single-input-fields login-check">
                            <a href="<?php echo $app_name; ?>/view/auth/forgot_password.php">
                            <label for="fruit1">Forgot Password!</label></a>
                        </div>
                    </div>

                    <div class="login-footer">
                        <p>Don’t have an account? <a href="<?php echo $app_name; ?>/view/auth/register.php">Sign Up</a> here</p>
                        <button type="submit" class="submit-btn3">Login</button>
                    </div>
                </form>
            </div>
        </div>

    </main>


    <script src="<?php echo $app_name; ?>/public/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/popper.min.js+bootstrap.min.js.pagespeed.jc.rDz9KUXW0v.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/ajax-form-request.js"></script>

    <script>
        eval(mod_pagespeed_h6FSS0R5Nk);
    </script>
    <script>
        eval(mod_pagespeed_nAF17_H0Ki);
    </script>

    <script src="<?php echo $app_name; ?>/public/js/owl.carousel.min.js+slick.min.js.pagespeed.jc.Dccc_xx8PD.js"></script>
    <script>
        eval(mod_pagespeed_4EWkIIjjEL);
    </script>
    <script>
        eval(mod_pagespeed_b61UQMOxQz);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.slicknav.min.js+wow.min.js+jquery.magnific-popup.js+jquery.nice-select.min.js+jquery.counterup.min.js+waypoints.min.js+contact.js.pagespeed.jc.isQq4h3kta.js"></script>
    <script>
        eval(mod_pagespeed_u74TJ7b4ya);
    </script>

    <script>
        eval(mod_pagespeed_jkoDhHOz0u);
    </script>
    <script>
        eval(mod_pagespeed_LXmZQChS9I);
    </script>
    <script>
        eval(mod_pagespeed_weSlV7qHIh);
    </script>
    <script>
        eval(mod_pagespeed_5FaTDDR9BI);
    </script>
    <script>
        eval(mod_pagespeed_$E6h4J_eHl);
    </script>

    <script>
        eval(mod_pagespeed_3Bn1QXBxeT);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.form.js+jquery.validate.min.js+mail-script.js+jquery.ajaxchimp.min.js+plugins.js+main.js.pagespeed.jc.UiK9nRMxfh.js"></script>
    <script>
        eval(mod_pagespeed_wwngUhmEap);
    </script>
    <script>
        eval(mod_pagespeed_p1DPFKbsIO);
    </script>
    <script>
        eval(mod_pagespeed_qHuP$p3A$U);
    </script>
    <script>
        eval(mod_pagespeed_cha65DBll0);
    </script>

    <script>
        eval(mod_pagespeed__9GFzCTG35);
    </script>
    <script>
        eval(mod_pagespeed_3_hkYAdE2S);
    </script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6e50c5c119142e7c","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.12.0","si":100}' crossorigin="anonymous"></script>
</body>

</html>

<script>
    function handleLogin() {
        location.href='../../index.php';
    }
    const successLoginCallBack = function(data) {
        
    }
</script>