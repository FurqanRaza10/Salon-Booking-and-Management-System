<?php require_once __DIR__ . '/../../application/utils/app_config.php'; ?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>SalonHub | registration</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $app_name; ?>/public/img/icon/xfavicon.png.pagespeed.ic.T_b7aM30ll.webp">

    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/animate.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/fontawesome-all.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/slicknav.css" />
    <link rel="stylesheet" href="<?php echo $app_name; ?>/public/css/style.css">
    <style>
        .back-arrow {
            font-size: 20px;
            position: absolute;
            top: 35px;
            cursor: pointer;
        }

        .error {
            color: red !important;
            width: 100%;
            font-size: 17px !important;
            margin-bottom: 5px !important;
        }

        .dropDown_profile {
            max-width: 200px;
            height: 90px;
            background: #2c3e4e;
            position: absolute;
            right: 10px;
            top: 95px;
            opacity: .9;
            border-radius: 5px;
            -webkit-animation: slideTop .4s;
            animation: slideTop 0.4s;
        }
    </style>
</head>

<body>
    <main class="login-bg">

        <div class="register-form-area">
            <div class="register-form">
                <div class="back-arrow">
                    <a href="<?php echo $app_name; ?>/index.php" style="color:black">
                        <svg class="bi bi-arrow-left" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"></path>
                        </svg>
                    </a>
                </div>
                <div class="register-heading">
                    <span>Sign Up</span>
                    <p>Create your account to get full access</p>
                    
                    <span class="error" id="error_msg" style="display: none;"></span>
                </div>
                <form id="regi_form" method="POST" >
                    <div class="input-box">
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Full name</label>
                            <input type="text" class="name" name="name" placeholder="Enter full name">
                        </div>
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Mobile Number</label>
                            <input type="number" class="mobile" name="mobile" placeholder="Enter Mobile number" onkeypress="if(this.value.length == 10){return false;}">
                        </div>
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Email Address</label>
                            <input type="email" class="email" name="email" placeholder="Enter email address">
                        </div>
                        <div class="single-input-fields" style="max-width: 588px">
                            <label>Password</label>
                            <input type="password" class="password" name="password" id="password" placeholder="Enter Password">
                        </div>
                    </div>

                    <div class="register-footer">
                        <p> Already have an account? <a href="<?php echo $app_name; ?>/view/auth/login.php"> Login</a> here</p>
                        <button type="submit" class="submit-btn3" onclick="handleSignup()">Get OTP</button>
                    </div>
                </form>
            </div>
        </div>

    </main>


    <script src="<?php echo $app_name; ?>/public/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/popper.min.js+bootstrap.min.js.pagespeed.jc.rDz9KUXW0v.js"></script>
    <script src="<?php echo $app_name; ?>/public/js/ajax-form-request.js"></script>
    <script>
        eval(mod_pagespeed_h6FSS0R5Nk);
    </script>
    <script>
        eval(mod_pagespeed_nAF17_H0Ki);
    </script>

    <script src="<?php echo $app_name; ?>/public/js/owl.carousel.min.js+slick.min.js.pagespeed.jc.Dccc_xx8PD.js"></script>
    <script>
        eval(mod_pagespeed_4EWkIIjjEL);
    </script>
    <script>
        eval(mod_pagespeed_b61UQMOxQz);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.slicknav.min.js+wow.min.js+jquery.magnific-popup.js+jquery.nice-select.min.js+jquery.counterup.min.js+waypoints.min.js+contact.js.pagespeed.jc.isQq4h3kta.js"></script>
    <script>
        eval(mod_pagespeed_u74TJ7b4ya);
    </script>

    <script>
        eval(mod_pagespeed_jkoDhHOz0u);
    </script>
    <script>
        eval(mod_pagespeed_LXmZQChS9I);
    </script>
    <script>
        eval(mod_pagespeed_weSlV7qHIh);
    </script>
    <script>
        eval(mod_pagespeed_5FaTDDR9BI);
    </script>
    <script>
        eval(mod_pagespeed_$E6h4J_eHl);
    </script>

    <script>
        eval(mod_pagespeed_3Bn1QXBxeT);
    </script>
    <script src="<?php echo $app_name; ?>/public/js/jquery.form.js+jquery.validate.min.js+mail-script.js+jquery.ajaxchimp.min.js+plugins.js+main.js.pagespeed.jc.UiK9nRMxfh.js"></script>
    <script>
        eval(mod_pagespeed_wwngUhmEap);
    </script>
    <script>
        eval(mod_pagespeed_p1DPFKbsIO);
    </script>
    <script>
        eval(mod_pagespeed_qHuP$p3A$U);
    </script>
    <script>
        eval(mod_pagespeed_cha65DBll0);
    </script>

    <script>
        eval(mod_pagespeed__9GFzCTG35);
    </script>
    <script>
        eval(mod_pagespeed_3_hkYAdE2S);
    </script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');

        function handleSignup() {
            console.log("hello");
            
            location.href='otp_confirm.php';
        }
    </script>
    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"6e50989ec91e8590","token":"cd0b4b3a733644fc843ef0b185f98241","version":"2021.12.0","si":100}' crossorigin="anonymous"></script>
</body>

</html>