<?php
  date_default_timezone_set ( "America/Toronto" );
  $product_name = "Salon Hub";
  $app_name = "/saloon_ui";

  $app_path = 
  [
    'item_img_url'=>"https://res.cloudinary.com/hschaudhary/image/upload/v1644314667/",
    'item_img_server_url' => "https://inspiresoftware.co.in/inskart/restaurant_images/restaurant",
    'category_img_server_url' =>"https://inspiresoftware.co.in/inskart/restaurant_images/dishes"
  ];
  
?>
