function getPopularSalon() {
    var url = `${appname}/application/master/master_action_handler.php?action=getPopularSalon`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var PopularSalon = result.responseContent.popular_salon;

        var popularSalon_div = "";
        var status = "Open";

        for (let getsalon of PopularSalon) {
            if (getsalon.is_active != 1) {
                status = "Closed";
            }
        
            popularSalon_div += `<div class="properties pb-20 col-4">
                                    <div class="properties-card">
                                        <div class="properties-img overlay1">
                                            <a href="javascript:void(0)"><img src="${getsalon.img_path}" alt=""></a>
                                            <div class="img-text">
                                                <span>${status}</span>
                                            </div>
                                            <div class="icon">
                                                <i class="far fa-heart"></i>
                                            </div>
                                          
                                        </div>
                                        <div class="properties-caption">
                                            <h3>
                                                <a href="${appname}/view/salon_details.php?salon_id=${getsalon.salon_id}">${getsalon.saloon_name}</a>
                                                <img src="${appname}/public/img/gallery/varified.png">
                                            </h3>
                                            <p><i class="fas fa-map-marker-alt"></i>${getsalon.adress}</p>
                                        </div>
                                        <div class="properties-footer d-flex justify-content-between align-items-center flex-wrap">
                                            <div class="restaurant-name">
                                                <img src="${appname}/public/img/icon/salon.png" alt="">
                                                <h3><a href="#">Salon & Spa</a></h3>
                                            </div>
                                            <div class="contact">
                                                <ul>
                                                    <li><a href="tel:${getsalon.mobile_no}"><i class="fas fa-phone-alt"></i></a></li>
                                                    <li><a href="mailto:${getsalon.email_id}"><i class="far fa-envelope"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
        }

        $("#popular_salon_div").html(popularSalon_div);
    });
}

function topCategories() {
    var url = `${appname}/application/master/master_action_handler.php?action=getHomeCategories`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var getHomeCategories = result.responseContent.category_list;
        var CategoryList_div = "";


        for (let Categories of getHomeCategories) {
            CategoryList_div += `<div class="col-xl-2 col-lg-2 col-md-4 col-sm-4" style="padding:10px">
                                    <div class="single-location mb-30 text-center">
                                        <div class="location-img">
                                            <img src="${Categories.img_path}" alt="">
                                            <div class="location-details">
                                                <h4><a href="${appname}/view/salon_by_category.php?category_id=${Categories.category_id}">Explore<i class="fas fa-angle-right"></i></a></h4>
                                            </div>
                                        </div>
                                        <h3><a href="#">${Categories.category_name}</a></h3>
                                    </div>
                                </div>`;
        }
        $('#category_div').html(CategoryList_div);
    })
}

function getallCategories() {
    var url = `${appname}/application/master/master_action_handler.php?action=getAllCategories`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var getAllCategories = result.responseContent.all_category_list;
        var AllCategoryList_div = "";


        for (let Categories of getAllCategories) {
            AllCategoryList_div += `<div class="col-xl-2 col-lg-2 col-md-4 col-sm-4" style="padding:10px">
                                    <div class="single-location mb-30 text-center">
                                        <div class="location-img">
                                            <img src="${Categories.img_path}" alt="">
                                            <div class="location-details">
                                                <h4><a href="${appname}/view/salon_by_category.php?category_id=${Categories.category_id}">Explore<i class="fas fa-angle-right"></i></a></h4>
                                            </div>
                                        </div>
                                        <h3><a href="#">${Categories.category_name}</a></h3>
                                    </div>
                                </div>`;
        }
        $('#all_category_div').html(AllCategoryList_div);
    })
}

function getAllSalon() {
    var url = `${appname}/application/master/master_action_handler.php?action=getAllSalon`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var AllSalon = result.responseContent.AllSalon;
        var No_of_salon = result.responseContent.NoOfSalon;

        $('#salon_count').html(No_of_salon + ' Salons are available');

        var AllSalon_div = "";
        var status = "Open";

        for (let getsalon of AllSalon) {
            if (getsalon.is_active != 1) {
                status = "Closed";
            }
            AllSalon_div += `<div class="col-lg-4">
            <div class="properties properties2 pb-30">
                <div class="properties-card">
                    <div class="properties-img overlay1">
                        <a href="javascript:void(0)"><img src="${getsalon.img_path}"></a>
                        <div class="img-text">
                            <span>${status}</span>
                        </div>
                        <div class="icon">
                            <i class="far fa-heart"></i>
                        </div>
                        
                    </div>
                    <div class="properties-caption">
                        <h3>
                            <a href="${appname}/view/salon_details.php?salon_id=${getsalon.salon_id}">${getsalon.saloon_name}</a>
                            <img src="${appname}/public/img/gallery/varified.png">
                        </h3>
                        <p><i class="fas fa-map-marker-alt"></i>${getsalon.adress}</p>
                    </div>
                    <div class="properties-footer d-flex justify-content-between align-items-center flex-wrap">
                        <div class="restaurant-name">
                            <img src="${appname}/public/img/icon/restaurant-icon.svg" >
                            <h3><a href="#">Salon</a></h3>
                        </div>
                        <div class="contact">
                            <ul>
                                <li><i class="fas fa-phone-alt"></i></li>
                                <li><i class="far fa-envelope"></i></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;
        }

        $("#All_salon_div").html(AllSalon_div);
    });
}

function salon_details(salon_id) {
    var url = `${appname}/application/master/master_action_handler.php?action=getSalonById&salon_id=${salon_id}`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var salon_details = result.responseContent.salon_details[0];
        var status = "Close Now";

        $('#salon_name').html(salon_details.saloon_name);
        $('#salon_address').html('<i style="color:#4DB7FE" class="fas fa-map-marker-alt"></i>&nbsp;&nbsp' + salon_details.adress);

        if (salon_details.is_open_close == 1) {
            status = "Open Now";
            $('#salon_status').css('background', '#ABFF60');
            $('#salon_status').css('color', 'black');

        }

        $('#salon_status').html(status);
        $("#phone").attr("href", "tel:" + salon_details.mobile_no);
        $("#email").attr("href", "mailto:" + salon_details.email_id);

        console.log(result);
    })
}

function getCartItems(salon_id) {
    var url = `${appname}/application/master/master_action_handler.php?action=getCartItem&salon_id=${salon_id}`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        console.log(result.responseContent.cart_item);
        var CartItem = result.responseContent.cart_item;
        var No_of_cart_item = result.responseContent.cart_count;

        $('#counter').html(No_of_cart_item);

        var CartItem_div = "";
        var total_price = 0;
        for (let getCartItem of CartItem) {
            total_price += parseInt(getCartItem.price);
            CartItem_div += `<div class="cartbox__item cart_item_de" id="${getCartItem.service_id}">
                                
                                <div class="cartbox__item__content">
                                    <h5><a href="javascript:void(0)" class="product-name">${getCartItem.service_name}</a></h5>
                                </div>
                                <div class="cartbox__item__content">
                                    <span class="price">₹${getCartItem.price}</span>
                                </div>
                                <button type="button" class="cartbox__item__remove">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </div>`;
        }
        $("#total_price").val('₹' + total_price);
        $("#Cart_item_div").html(CartItem_div);
    });
}
function getSalonByCategory(category_id) {
    var url = `${appname}/application/master/master_action_handler.php?action=getSalonByCategory&category_id=${category_id}`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var AllSalon = result.responseContent.Category_wise_salon;
        var No_of_salon = result.responseContent.NoOfSalon;
        console.log(No_of_salon);
        $('#salon_count').html(No_of_salon + ' Salons are available');

        console.log(AllSalon);

        var AllSalon_div = "";
        var status = "Open";

        for (let getsalon of AllSalon) {
            if (getsalon.is_active != 1) {
                status = "Closed";
            }
            AllSalon_div += `<div class="col-lg-4">
            <div class="properties properties2 pb-30">
                <div class="properties-card">
                    <div class="properties-img overlay1">
                        <a href="javascript:void(0)"><img src="${getsalon.img_path}"></a>
                        <div class="img-text">
                            <span>${status}</span>
                        </div>
                        <div class="icon">
                            <i class="far fa-heart"></i>
                        </div>
                    </div>
                    <div class="properties-caption">
                        <h3>
                            <a href="${appname}/view/salon_details.php?salon_id=${getsalon.salon_id}">${getsalon.saloon_name}</a>
                            <img src="${appname}/public/img/gallery/varified.png">
                        </h3>
                        <p><i class="fas fa-map-marker-alt"></i>${getsalon.adress}</p>
                    </div>
                    <div class="properties-footer d-flex justify-content-between align-items-center flex-wrap">
                        <div class="restaurant-name">
                            <img src="${appname}/public/img/icon/restaurant-icon.svg" >
                            <h3><a href="#">Salon</a></h3>
                        </div>
                        <div class="contact">
                            <ul>
                                <li><i class="fas fa-phone-alt"></i></li>
                                <li><i class="far fa-envelope"></i></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;
        }

        $("#category_wise_salon").html(AllSalon_div);
    });
}

/* get slot time */
function getSlotTime(date, salon_id) {

    var url = `${appname}/application/master/master_action_handler.php?action=getSlotTime&date=${date}&salon_id=${salon_id}`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var slot_time = result.responseContent.slot_time;
        var slot_div = "";
        if (slot_time != "") {

            var i = 1;
            for (let time of slot_time) {
                slot_div += `<input type="radio" style="display:none" name="slot_time" id="slot_${i}" value="${time.sloat_start_time}"><label for="slot_${i}">${time.sloat_start_time}</label >`;

                i++;
            }
            $('#slot_time_div').html(slot_div);
            $('#bookin_btn').prop('disabled', false);
        }
        else {
            $('#bookin_btn').prop('disabled', true);
            $('#slot_time_div').html("<li><b>No slot available</b></li>");
        }
        $('.sloat_time').show();
    })

}

function place_booking() {
    var all_item = document.getElementsByClassName('cart_item_de');
    var service_id;

    var totalItem = 0;
    var saved_item = "";

    for (var i = 0; i < all_item.length; i++) {
        service_id = all_item[i].id;
        item_quntity = 1;
        saved_item += (saved_item == "") ? `${service_id} ${item_quntity}` : `,${service_id} ${item_quntity}`;
    }
    if ($("[name='sloat_date']").val() == "" || $("[name='sloat_time']").val() == "" || $("[name='specialist']").val() == "") {
        if ($("[name='sloat_date']").val() == "") {
            $("#sloat_date_error").css("display", "block");
            $("[name='sloat_date']").css("border-color", "red");
        }
        else {
            $("#sloat_date_error").css("display", "none");
            $("[name='sloat_date']").css("border-color", "#ced4da");
        }
        if ($("input[name='sloat_time']:checked").val()) {
            $("#sloat_time_error").css("display", "none");
        }
        else {
            $("#sloat_time_error").css("display", "block");
        }
        if ($("[name='specialist']").val() == "") {
            $("#specialist_error").css("display", "block");
            $("[name='specialist']").css("border-color", "red");
        }
        else {
            $("#specialist_error").css("display", "none");
            $("[name='specialist']").css("border-color", "#ced4da");
        }
    }
    else {
        if (saved_item != "") {
            $.ajax({
                type: "POST",
                url: `${appname}/application/master/master_action_handler.php`,
                data: {
                    "action": "confirm_booking",
                    "saved_item": saved_item,
                    "booking_data": $('#booking_form').serializeArray()
                },
                success: function (data) {
                    $('#booking_btn').css("pointer-events", "none");

                    // $.message({
                    //     type: "success",
                    //     text: "Order Successfully Placed",
                    //     positon: "top-right",
                    // });
                    setTimeout(() => {
                        window.location.href = `${appname}/index.php`;
                    }, 800);
                },
                error: function (data) {
                    alert("sorry");
                }
            })
        }
        else {
            alert("sorry your cart is empty");
        }
    }

}

function getUserProfile(customer_id){
    var url = `${appname}/application/master/master_action_handler.php?action=getProfileDetail&customer_id=${customer_id}`;
    $.get(url,function(data) {
        var result = JSON.parse(data);
        var user = result.responseContent.profile_detail;

        var user_profile = `<h2>${user.customer_name}</h2>
        <span>+91 ${user.mobile_no}</span></br>
        <span>${user.email_id}</span>`;

        $('#user_profile').html(user_profile);
    })    
}

function getBookings(customer_id){
    var url = `${appname}/application/master/master_action_handler.php?action=getBookings&customer_id=${customer_id}`;
    $.get(url,function(data) {
        var result = JSON.parse(data);
        var booking_detail = result.responseContent.booking_detail;
        var total_booking = result.responseContent.total_bookings;

        var booking_div = "";
        var color_icon = "warning-ps";
        var icon = "fa-info-circle";
        for (let booking of booking_detail){
            if (booking.booking_status == "Confirm") {
                color_icon = "";
                icon = "fa-check-circle";
            }
            else if(booking.booking_status == "Reject") {
                color_icon = "text-danger";
                icon = "fa-solid fa-circle-xmark";
            }
            booking_div += `<div class="booking row" style="margin-bottom:15px;border-radius:5px">
                                <div class="salon-img col-xl-4 col-lg-4 col-md-4"><img style="width: 100%;height: 100%;" src="${booking.img_path}"></div>
                                <div class="col-xl-4 col-lg-4 col-md-4">
                                    <h3>${booking.saloon_name}</h3>
                                    <span><i class="fas fa-map-marker-alt"></i>&nbsp ${booking.adress}</span></br>
                                    <span><i class="fas fa-calendar-check"></i>&nbsp Appointment on <b>${booking.slot_date} | ${booking.slot_time}</b></span>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4">
                                    <span>Booking Id:</span>
                                    <b>${booking.booking_no}</b>
                                    <hr style="margin: 0px;border-bottom:1px solid #333">
                                    <div class="booking_status">
                                        <ul class="Payment_status">
                                            <li><i class="fa fa-check-circle" aria-hidden="true"></i>
                                                Booking</li>
                                            <!-- <li>
                                                <i class="fa fa-info-circle warning-ps" aria-hidden="true"></i>
                                                Payment
                                            </li> -->
                                            <li>
                                                <i class="fa ${icon} ${color_icon}" aria-hidden="true"></i>
                                                ${booking.booking_status}
                                            </li>
                                        </ul>
    
                                    </div>
                                </div>
                            </div>`;
        }
        $('#booking_div').html(booking_div);
        $('#total_booking').html(total_booking);
        
    })  
}

