<?php

require_once __DIR__ . '/../application/utils/app_config.php';
require_once __DIR__ . '/../application/auth/check_auth_session.php';
$active = "";
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="format-detection" content="telephone=no">

	<!-- PAGE TITLE HERE -->
	<title>Saloon Hub Admin</title>

	<!-- FAVICONS ICON -->
	<!-- <link rel="shortcut icon" type="image/png" href="images/favicon.png" /> -->
	<link href="<?php echo $app_name; ?>/public/vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
	<link href="<?php echo $app_name; ?>/public/vendor/owl-carousel/owl.carousel.css" rel="stylesheet">

	<!-- Style css -->
	<link href="<?php echo $app_name; ?>/public/css/style.css" rel="stylesheet">

	<style>
		@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap');

		:root {
		--sz: 15px;  /* size */
		--on: rgba(249, 58, 11, 0.8); /* color on */
		--of: #68838d; /* color off */
		--tr: all 0.25s ease 0s;
		}	


		.toggle {
			position: relative;
			width: calc(var(--sz) * 4);
			height: calc(var(--sz) * 2);
			display: flex;
			align-items: center;
			justify-content: center;
			top:5px;
		}

		input {
			display: none;
		}

		label[for=btn] {
			position: absolute;
			width: calc(var(--sz) * 4);
			height: calc(var(--sz) * 2);
			background: linear-gradient(180deg, #888, #fff);
			border-radius: var(--sz);
			padding: calc(var(--sz) / 5);
			box-shadow: 0 0 calc(var(--sz) / 50) calc(var(--sz) / 50) #0002;
		}	

		#btn:checked + label[for=btn] {
			box-shadow: 
				0 calc(var(--sz) / 50) calc(var(--sz) / 5) #fff9, 
				0 0 calc(var(--sz) / 50) calc(var(--sz) / 50) #0002;
		}

		label[for=btn]:after {
			content: "";
			position: absolute;
			width: calc(100% - calc(calc(var(--sz) / 5) * 12));
			height: calc(100% - calc(calc(var(--sz) / 5) * 2));
			box-shadow: 0 0 calc(var(--sz) / 2) calc(var(--sz) / 10) var(--on), 0 0 calc(var(--sz) / 2) calc(var(--sz) / 10) #fff;
			border-radius: var(--sz);
			z-index: 0;
			opacity: 0;
			transition: var(--tr);
			animation: move-shadow 3s ease 0s 1;
		}

		#btn:checked + label[for=btn]:after {
			opacity: 1;
			width: calc(100% - calc(calc(var(--sz) / 5) * 4));
		}





		.track {
			position: absolute;
			width: calc(calc(var(--sz) * 4) - calc(var(--sz) / 2.5));
			height: calc(calc(var(--sz) * 2) - calc(var(--sz) / 2.5));
			border-radius: var(--sz);
			overflow: hidden;
		}

		.track:before {
			content: "";
			position: absolute;
			width: calc(200% - calc(calc(var(--sz) * 2) - calc(var(--sz) / 3)));
			height: 100%;
			left: -50%;
			transition: var(--tr);
			background: linear-gradient(90deg, var(--on) 50%, var(--of) 50%);
			animation: move-color 3s ease 0s 1;
		}

		.track:after {
			content: "";
			position: absolute;
			width: 100%;
			height: 100%;
			border-radius: var(--sz);
			box-shadow: 0 calc(var(--sz) / -10) calc(var(--sz) / 10) 0 #0005 inset, 0 calc(var(--sz) / 10) calc(var(--sz) / 10) 0 #0005 inset;
		}

		#btn:checked + label .track:before {
			left: 0%;
		}







		.thumb {
			position: absolute;
			width: calc(calc(var(--sz) * 2) - calc(var(--sz) / 3));
			height: calc(calc(var(--sz) * 2) - calc(var(--sz) / 3));
			top: calc(calc( var(--sz) / 10) + calc(var(--sz) / 15));
			left: calc(calc( var(--sz) / 10) + calc(var(--sz) / 15));
			background: linear-gradient(180deg, #fff, #afafaf);
			border-radius: var(--sz);
			box-shadow: 0 0 0 calc(var(--sz) / 50) #0002, 0 calc(var(--sz) / 10) calc(var(--sz) / 10) 0 #0008;
			cursor: pointer;
			font-size: calc(var(--sz) / 2);
			display: flex;
			align-items: center;
			justify-content: center;
			text-indent: calc(var(--sz) * -0.025);
			text-shadow: 
				calc(var(--sz) / -8000) calc(var(--sz) / -150) calc(var(--sz) / 50) #0008, 
				calc(var(--sz) / 150) calc(var(--sz) / 100) calc(var(--sz) / 50) #fff;
			color: #7d7c7c;
			z-index: 1;
			animation: move-thumb 3s ease 0s 1;
		}

		#btn:checked + label .thumb {
			left: calc(calc(100% - calc(calc(var(--sz) * 2) - calc(var(--sz) / 3))) - calc(calc( var(--sz) / 10) + calc(var(--sz) / 15)));
			color: var(--on);
			background: 
				radial-gradient(circle at 7% 50%, #fff calc(var(--sz) / 50), #fff0 calc(var(--sz) / 2)),
				radial-gradient(circle at 0 50%, var(--on) 10%, #fff0 60%), 
				linear-gradient(180deg, #fff, #afafaf);
			text-shadow: 
				0 0 calc(var(--sz) / 10) var(--on), 0 0 calc(var(--sz) / 5) #fff, 
				calc(var(--sz) / -8000) calc(var(--sz) / -150) calc(var(--sz) / 50) #0008, 
				calc(var(--sz) / 150) calc(var(--sz) / 100) calc(var(--sz) / 50) #fff;
		}

		.thumb:before {
			content: "";
			display: block;
			width: 70%;
			height: 70%;
			background: linear-gradient(180deg, #0008, #ccc, #fff);
			position: absolute;
			z-index: -1;
			border-radius: var(--sz);
			border: calc(var(--sz) / 50) solid #ddd;
		}





		.txt:before, 
		.txt:after {
			content: "";
			position: absolute;
			left: calc(var(--sz) / 2);
			top: 25%;
			content: "ON";
			transition: var(--tr);
			font-size: calc(var(--sz) / 1.5);
			color: #000;
			opacity: 0.4;
			text-shadow: 0px -1px 1px #000, 0px 1px 2px #fff;
		}

		.txt:after {
			content: "OFF";
			left: calc(100% - calc(var(--sz) / 0.625));
		}


		/* initial animation */
		/* @keyframes move-thumb {
		0%, 20%, 80%, 100% { 
			left: calc(calc( var(--sz) / 10) + calc(var(--sz) / 15));
			color: #7d7c7c;
			background: linear-gradient(180deg, #fff, #afafaf);
			text-shadow:  
			calc(var(--sz) / -8000) calc(var(--sz) / -150) calc(var(--sz) / 50) #0008, 
			calc(var(--sz) / 150) calc(var(--sz) / 100) calc(var(--sz) / 50) #fff;
		}
		30%, 70% {
			left: calc(calc(100% - calc(calc(var(--sz) * 2) - calc(var(--sz) / 3))) - calc(calc( var(--sz) / 10) + calc(var(--sz) / 15)));
			color: var(--on);
			background: 
			radial-gradient(circle at 7% 50%, #fff calc(var(--sz) / 50), #fff0 calc(var(--sz) / 2)),
			radial-gradient(circle at 0 50%, var(--on) 10%, #fff0 60%), 
			linear-gradient(180deg, #fff, #afafaf);
			text-shadow:
			0 0 calc(var(--sz) / 10) var(--on), 0 0 calc(var(--sz) / 5) #fff, 
			calc(var(--sz) / -8000) calc(var(--sz) / -150) calc(var(--sz) / 50) #0008, 
			calc(var(--sz) / 150) calc(var(--sz) / 100) calc(var(--sz) / 50) #fff;
		}
		}

		@keyframes move-color {
			0%, 20%, 80%, 100% { left: -50%; }
			30%, 70% { left: 0%; }
		}


		@keyframes move-shadow {
			0%, 20%, 80%, 100% { 
				opacity: 0;
				width: calc(100% - calc(calc(var(--sz) / 5) * 12));	
			}
			30%, 70% { 
				opacity: 1;
				width: calc(100% - calc(calc(var(--sz) / 5) * 4));
			}
		} */
	</style>

</head>

<body>

	<!--*******************
        Preloader start
    ********************-->
	<div id="preloader">
		<div class="lds-ripple">
			<div></div>
			<div></div>
		</div>
	</div>
	<!--*******************
        Preloader end
    ********************-->

	<!--**********************************
        Main wrapper start
    ***********************************-->
	<div id="main-wrapper">

		<!--**********************************
            Nav header start
        ***********************************-->
		<div class="nav-header">
			<a href="index.html" class="brand-logo">
				<img src="<?php echo $app_name; ?>/public/images/salon.png" style="width: 120px;">
			</a>
			<div class="nav-control">
				<div class="hamburger">
					<span class="line"></span><span class="line"></span><span class="line"></span>
				</div>
			</div>
		</div>
		<!--**********************************
            Nav header end
        ***********************************-->

		<!--**********************************
            Modal
        ***********************************-->

		<?php require_once __DIR__. '/partials/model.php'; ?>

		<!--**********************************
            Header start
        ***********************************-->
		<div class="header">
			<div class="header-content">
				<nav class="navbar navbar-expand">
					<div class="collapse navbar-collapse justify-content-between">
						<div class="header-left">
							<div class="dashboard_bar">
								Appointments
							</div>

						</div>

						<div class="toggle">
							<input type="checkbox" id="btn" value="1" onclick="salonStatus(this.value,event)">
							<label for="btn">
								<span class="track">
								<span class="txt"></span>
								</span>
								<span class="thumb">|||</span>
							</label>
						</div>

						<ul class="navbar-nav header-right">

							<li class="nav-item dropdown header-profile">
								<a class="nav-link" href="javascript:void(0);" role="button" data-bs-toggle="dropdown">
									<img src="<?php echo $app_name; ?>/public/images/profile.jpg" width="20" alt="">
								</a>
								<div class="dropdown-menu dropdown-menu-end">
									<a href="#" class="dropdown-item ai-icon">
										<svg xmlns="http://www.w3.org/2000/svg" class="text-primary" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
											<circle cx="12" cy="7" r="4"></circle>
										</svg>
										<span class="ms-2">Change password </span>
									</a>
									<a href="<?php echo $app_name; ?>/application/auth/logout.php" class="dropdown-item ai-icon">
										<svg xmlns="http://www.w3.org/2000/svg" class="text-danger" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
											<polyline points="16 17 21 12 16 7"></polyline>
											<line x1="21" y1="12" x2="9" y2="12"></line>
										</svg>
										<span class="ms-2">Logout </span>
									</a>
								</div>
							</li>
							<li class="nav-item">

							</li>
						</ul>

					</div>
				</nav>
			</div>
		</div>
		<!--**********************************
            Header end ti-comment-alt
        ***********************************-->

		<!--**********************************
            Sidebar start
        ***********************************-->
		<?php require_once __DIR__ . '/partials/side_bar.php'; ?>
		<!--**********************************
            Sidebar end
        ***********************************-->

		<!--**********************************
            Content body start
        ***********************************-->
		<div class="content-body">
			<!-- row -->
			<div class="container-fluid">
				<div class="d-sm-flex d-block justify-content-between align-items-center mb-4">
					<div class="card-action coin-tabs mt-3 mt-sm-0">
						<ul class="nav nav-tabs" role="tablist">
							<?php if (haveAccessWithRedirect('Pending')) : $active = "active"; ?>
								<li class="nav-item">
									<a class="nav-link active" data-bs-toggle="tab" href="#AllStatus">Pending</a>
								</li>
							<?php endif; ?>
							<?php if (haveAccessWithRedirect('Confirm')) : ?>
								<li class="nav-item">
									<a class="nav-link" data-bs-toggle="tab" href="#Pending">Confirm</a>
								</li>
							<?php endif; ?>
							<?php if (haveAccessWithRedirect('Cancel')) : ?>
								<li class="nav-item">
									<a class="nav-link" data-bs-toggle="tab" href="#cancle">Cancel</a>
								</li>
							<?php endif; ?>
						</ul>
					</div>
					<!-- <div class="d-flex mt-sm-0 mt-3">
						<select class="default-select dashboard-select">
							<option data-display="newest">newest</option>

							<option value="2">oldest</option>
						</select>
					</div> -->
				</div>
				<div class="row">
					<div class="col-xl-12">
						<div class="tab-content">
							<div class="tab-pane fade show <?php echo $active; ?>" id="AllStatus">
								<div class="table-responsive">
									<table class="table display mb-4 dataTablesCard order-table card-table text-black" id="application-tbl1">
										<thead>
											<tr class="text-center">
												<th>Booking No</th>
												<th>Date</th>
												<th>Name</th>
												<th>Contact</th>
												<th>Specialist</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody id="appointment_pending">

										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane fade" id="Pending">
								<div class="table-responsive">
									<table class="table display mb-4 dataTablesCard order-table card-table text-black" id="application-tbl1">
										<thead>
											<tr class="text-center">
												<th>Booking No</th>
												<th>Date</th>
												<th>Name</th>
												<th>Contact</th>
												<th>Specialist</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody id="appointment_success">

										</tbody>
									</table>
								</div>
							</div>
							<div class="tab-pane" id="cancle">
								<div class="table-responsive">
									<table class="table display mb-4 dataTablesCard order-table card-table text-black" id="application-tbl1">
										<thead>
											<tr class="text-center">
												<th>Booking No</th>
												<th>Date</th>
												<th>Name</th>
												<th>Contact</th>
												<th>Specialist</th>
												<th>Status</th>
												<th>Action</th>
											</tr>
										</thead>

										<tbody id="appointment_cancel">

										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
	<!--**********************************
            Content body end
        ***********************************-->



	<!--**********************************
            Footer start
        ***********************************-->
	<div class="footer">
		<div class="copyright">
			<p>Copyright © Designed &amp; Developed by <a href="inspiresoftware.co.in" target="_blank">Inspire
					Software</a> 2021</p>
		</div>
	</div>
	<!--**********************************
            Footer end
        ***********************************-->

	<!--**********************************
           Support ticket button start
        ***********************************-->

	<!--**********************************
           Support ticket button end
        ***********************************-->


	</div>
	<!--**********************************
        Main wrapper end
    ***********************************-->

	<!--**********************************
        Scripts
    ***********************************-->
	<!-- app name  -->
	<script>
		var appname = '<?php echo $app_name; ?>';
	</script>
	<!-- Required vendors -->
	<script src="<?php echo $app_name; ?>/public/vendor/global/global.min.js"></script>
	<script src="<?php echo $app_name; ?>/public/vendor/chart.js/Chart.bundle.min.js"></script>
	<script src="<?php echo $app_name; ?>/public/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

	<!-- Apex Chart -->
	<script src="<?php echo $app_name; ?>/public/vendor/apexchart/apexchart.js"></script>

	<script src="<?php echo $app_name; ?>/public/vendor/chart.js/Chart.bundle.min.js"></script>

	<!-- Chart piety plugin files -->
	<script src="<?php echo $app_name; ?>/public/vendor/peity/jquery.peity.min.js"></script>

	<!-- Dashboard 1 -->
	<script src="<?php echo $app_name; ?>/public/js/dashboard/dashboard-1.js"></script>

	<script src="<?php echo $app_name; ?>/public/vendor/owl-carousel/owl.carousel.js"></script>

	<script src="<?php echo $app_name; ?>/public/js/custom.min.js"></script>
	<script src="<?php echo $app_name; ?>/public/js/dlabnav-init.js"></script>
	<script src="<?php echo $app_name; ?>/public/js/demo.js"></script>
	<script src="<?php echo $app_name; ?>/public/js/styleSwitcher.js"></script>
	<script src="<?php echo $app_name; ?>/public/js/admin.js"></script>
	<script src="<?php echo $app_name; ?>/public/js/modal.js"></script>


	<script>
		function JobickCarousel() {

			/*  testimonial one function by = owl.carousel.js */
			jQuery('.front-view-slider').owlCarousel({
				loop: false,
				margin: 30,
				nav: true,
				autoplaySpeed: 3000,
				navSpeed: 3000,
				autoWidth: true,
				paginationSpeed: 3000,
				slideSpeed: 3000,
				smartSpeed: 3000,
				autoplay: false,
				animateOut: 'fadeOut',
				dots: true,
				navText: ['', ''],
				responsive: {
					0: {
						items: 1
					},

					480: {
						items: 1
					},

					767: {
						items: 3
					},
					1750: {
						items: 3
					}
				}
			})
		}

		jQuery(window).on('load', function() {
			setTimeout(function() {
				JobickCarousel();
			}, 1000);
		});

		setInterval(function() {
			getPendingAppointment();

			getConfirmAppointment();

			getCancelAppointment();
		}, 1000);
	</script>
	<script>
		/* accept Booking */
		function accept_booking(booking_no) {

			var url = `<?php echo $app_name; ?>/application/master/master_action_handler.php`;
			$.post(url, {
				action: "Accept_booking",
				booking_no: booking_no
			}, function() {

			});

		}
		/* cancel Booking */
		function cancel_booking(booking_id) {

			var url = `<?php echo $app_name; ?>/application/master/master_action_handler.php`;
			$.post(url, {
				action: "cancel_booking",
				booking_id: booking_id
			}, function() {

			});

		}

		


	</script>

</body>

</html>