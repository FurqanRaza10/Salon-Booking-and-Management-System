<?php require_once __DIR__.'/../../application/utils/app_config.php'; ?>
<?php require_once __DIR__.'/../../application/auth/check_auth_session.php';?>

<div class="dlabnav">
    <div class="dlabnav-scroll">

        <ul class="metismenu" id="menu">
            <?php if(haveAccessWithRedirect('Appointments')): ?>
            <li><a class="has-arrow" href="<?php echo $app_name; ?>/view/home.php" aria-expanded="false">
                    <i class="flaticon-025-dashboard"></i>
                    <span class="nav-text">Appointments</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if(haveAccessWithRedirect('Categories')): ?>
            <li><a class="has-arrow" href="<?php echo $app_name; ?>/view/master/categories.php" aria-expanded="false">
                    <i class="flaticon-017-clipboard"></i>
                    <span class="nav-text">Categories</span>
                </a>

            </li>
            <?php endif; ?>
            <?php if(haveAccessWithRedirect('Services')): ?>
            <li><a class="has-arrow" href="<?php echo $app_name; ?>/view/master/services.php" aria-expanded="false">
                    <i class="flaticon-381-list-1"></i>
                    <span class="nav-text">Services</span>
                </a>

            </li>
            <?php endif; ?>
            <?php if(haveAccessWithRedirect('Slot Create')): ?>
            <li><a class="has-arrow" href="<?php echo $app_name; ?>/view/master/create_sloat.php" aria-expanded="false">
                    <i class="flaticon-014-checkmark"></i>
                    <span class="nav-text">Slot Create</span>
                </a>

            </li>
            <?php endif; ?>
            <?php if(haveAccessWithRedirect('Users')): ?>
            <li><a class="has-arrow " href="<?php echo $app_name; ?>/view/master/user_master.php" aria-expanded="false">
                    <i class="flaticon-381-user-8"></i>
                    <span class="nav-text">Users</span>
                </a>

            </li>
            <?php endif; ?>
            <?php if(haveAccessWithRedirect('User Role')): ?>
            <li><a class="has-arrow " href="<?php echo $app_name; ?>/view/master/user_role.php" aria-expanded="false">
                    <i class="flaticon-381-lock-1"></i>
                    <span class="nav-text">User Role</span>
                </a>

            </li>
            <?php endif; ?> 
    </div>
</div>