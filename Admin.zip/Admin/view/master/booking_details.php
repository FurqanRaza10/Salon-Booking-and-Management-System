<?php
require_once __DIR__ . '/../../application/utils/app_config.php';

?>
<!-- Modal -->
<div class="modal-header border-bottom-0">
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body text-start text-black p-4">
    <h5 class="modal-title text-uppercase mb-5" id="exampleModalLabel"></h5>
    <h4 class="mb-5" style="color: #35558a;">Thanks for your order</h4>
    <p class="mb-0" style="color: #35558a;">Payment summary</p>
    <hr class="mt-2 mb-4" style="height: 0; background-color: transparent; opacity: .75; border-top: 2px dashed #9e9e9e;">
    <div id="service_div">
        <div class="d-flex justify-content-between">
            <p class="fw-bold mb-0">Ether Chair(Qty:1)</p>
            <p class="text-muted mb-0">$1750.00</p>
        </div>
    </div>


    <div class="d-flex justify-content-between">
        <p class="fw-bold">Total</p>
        <p class="fw-bold" style="color: #35558a;" id="total_amount">₹ 0.00</p>
    </div>

</div>>
<script>
    /* get booking detais */
    var booking_id = '<?php echo $_GET['booking_id']; ?>';

    function getBookingDetails(booking_id) {
        var url = `${appname}/application/master/master_action_handler.php?action=get_booking_details&booking_id=${booking_id}`;
        $.get(url, function(data) {
            var result = JSON.parse(data);
            var booking_data = result.responseContent.booking_detail;

            var service_div = "";
            var total_amount = 0;
            for (let i of booking_data) {
                total_amount += parseInt(i.price);
                service_div += `<div class="d-flex justify-content-between">
                                    <p class="fw-bold mb-0">${i.service_name}</p>
                                    <p class="text-muted mb-0">$ ${i.price}</p>
                                </div>`;
            }

            $('#service_div').html(service_div);
            $('#total_amount').html('$'+total_amount);
            $('#exampleModalLabel').html(booking_data[0].saloon_name);
        })
    }
    getBookingDetails(booking_id);
</script>