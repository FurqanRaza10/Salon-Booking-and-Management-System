<?php
require_once __DIR__ . '/../../application/master/add_service_controller.php';
require_once __DIR__ . '/../../application/utils/app_config.php';
require_once __DIR__ . '/../../application/utils/form_functions.php';

?>

<div class="modal-header">
    <?php if ($service_id == 0) : ?>
        <h5 class="modal-title">Add Service </h5>
    <?php else : ?>
        <h5 class="modal-title">Edit Service </h5>
    <?php endif; ?>

    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<div class="modal-body">
    <div class="card">
        <form id="service_form" method="POST" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" onsubmit="serviceFormsubmitHandler('service_form',event)">
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Category Name<span class="text-danger scale5 ms-2">*</span></label>
                        <?php
                            $selected = 0;
                            if (isset($service_data['category_id'])) {
                                $selected = $service_data['category_id'];
                            }
                            echo dropdown('category_name', $selected, $category_list, ['id' => 'category', 'class' => 'form-control input-rounded category_name', 'data-placeholder' => '--Select Category--']);
                        ?>
                    </div>
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Service Name<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="text" class="form-control input-rounded service_name" placeholder="Service Name" value="<?php echo (isset($service_data['service_name']) ? $service_data['service_name'] : '') ?>" name="service_name">
                    </div>
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Price<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="text" class="form-control input-rounded price" placeholder="Price" value="<?php echo (isset($service_data['price']) ? $service_data['price'] : '') ?>" name="price">
                    </div>
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Status<span class="text-danger scale5 ms-2">*</span></label>
                        <div class="mb-3 mb-0 d-flex ">
                            <div>
                                <input type="radio" value="1" <?php echo (isset($service_data['status']) && $service_data['status'] == 1)? "checked" : ""; ?> class="form-check-input status" name="status">
                                <label class="form-check-label">
                                    Active
                                </label>
                            </div>
                            <div style="margin-left:25px">
                                <input type="radio" value="0" <?php echo (isset($service_data['status']) && $service_data['status'] == 0)? "checked" : ""; ?> class="form-check-input" name="status">
                                <label class="form-check-label">
                                    Inactive
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" class="form-control input-rounded" name="service_id" value="<?php echo (isset($service_data['service_id']) ? $service_data['service_id'] : 0) ?>">
            <div class="card-footer text-end">
                <div>
                    <button class="btn btn-primary me-3" data-bs-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>
        </form>
    </div>
</div>