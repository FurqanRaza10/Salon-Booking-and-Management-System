<?php
require_once __DIR__ . '/../../application/master/add_sloat_controller.php';
require_once __DIR__ . '/../../application/utils/app_config.php';
require_once __DIR__ . '/../../application/utils/form_functions.php';

?>

<div class="modal-header">
    <?php if ($sloat_id == 0) : ?>
        <h5 class="modal-title">Crete Sloat </h5>
    <?php else : ?>
        <h5 class="modal-title">Edit Sloat </h5>
    <?php endif; ?>

    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<div class="modal-body">
    <div class="card">
        <form id="sloat_form" method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>" onsubmit="sloatFormsubmitHandler('sloat_form',event)">
            <?php if ($sloat_id != 0) : ?>
                <div class="alert" style="background-color: #cce5ff;border-color:#b8daff;color:#004085;font-size:14px;font-weight:500;text-align:center" role="alert">
                    You can Change only Status!
                </div>
            <?php endif; ?>
            <div class="card-body">

                <div class="row">

                    <div class="col-xl-6  col-md-6 mb-4">
                        <label class="form-label font-w600">Sloat Date<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="date" min="<?= date('Y-m-d'); ?>" class="form-control input-rounded sloat_date" placeholder="Sloat date" value="<?php echo (isset($sloat_data['sloat_date']) ? $sloat_data['sloat_date'] : '') ?>" name="sloat_date" <?php echo ($sloat_id != 0) ? "readonly" : ""; ?>>
                    </div>
                    <div class="col-xl-6  col-md-6 mb-4" style="display: flex;flex-direction: column;">
                        <label class="form-label font-w600">Sloat Duration<span class="text-danger scale5 ms-2">*</span></label>
                        <select class="nice-select default-select form-control mb-3 input-rounded sloat_duration" name="sloat_duration">
                            <option value="" hidden>--Select Gap--</option>
                            <option value="30" <?php echo (isset($sloat_data['sloat_duration']) && $sloat_data['sloat_duration'] == "30") ? "selected" : ""; ?> <?php echo ($sloat_id != 0) ? "style='display:none'" : ""; ?>>30 Minute</option>
                            <option value="60" <?php echo (isset($sloat_data['sloat_duration']) && $sloat_data['sloat_duration'] == "60") ? "selected" : ""; ?> <?php echo ($sloat_id != 0) ? "style='display:none'" : ""; ?>>60 Minute</option>
                        </select>

                    </div>
                    <div class="col-xl-6  col-md-6 mb-4">
                        <label class="form-label font-w600">Start Time<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="time" class="form-control input-rounded start_time" placeholder="Start time" value="<?php echo (isset($sloat_data['sloat_start_time']) ? $sloat_data['sloat_start_time'] : '') ?>" name="start_time" <?php echo ($sloat_id != 0) ? "readonly" : ""; ?>>
                    </div>
                    <div class="col-xl-6  col-md-6 mb-4">
                        <label class="form-label font-w600">End Time<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="time" class="form-control input-rounded end_time" placeholder="End time" value="<?php echo (isset($sloat_data['sloat_end_time']) ? $sloat_data['sloat_end_time'] : '') ?>" name="end_time" <?php echo ($sloat_id != 0) ? "readonly" : ""; ?>>
                    </div>
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Status<span class="text-danger scale5 ms-2">*</span></label>
                        <div class="mb-3 mb-0 d-flex ">
                            <div>
                                <input type="radio" value="1" <?php echo (isset($sloat_data['is_active']) && $sloat_data['is_active'] == 1) ? "checked" : ""; ?> class="form-check-input status" name="status">
                                <label class="form-check-label">
                                    Active
                                </label>
                            </div>
                            <div style="margin-left:25px">
                                <input type="radio" value="0" <?php echo (isset($sloat_data['is_active']) && $sloat_data['is_active'] == 0) ? "checked" : ""; ?> class="form-check-input" name="status">
                                <label class="form-check-label">
                                    Inactive
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <input type="hidden" class="form-control input-rounded" name="sloat_id" value="<?php echo (isset($sloat_data['sloat_id']) ? $sloat_data['sloat_id'] : 0) ?>">
            <div class="card-footer text-end">
                <div>
                    <button class="btn btn-primary me-3" data-bs-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>
        </form>
    </div>
</div>
<!--
function getServiceScheduleSlots($duration, $start,$end)
{
        $start = new DateTime($start);
        $end = new DateTime($end);
        $start_time = $start->format('h:i A');
        $end_time = $end->format('h:i A');
        $i=0;
        while(strtotime($start_time) <= strtotime($end_time)){
            $start = $start_time;
            $end = date('H:i',strtotime('+'.$duration.' minutes',strtotime($start_time)));
            $start_time = date('h:i A',strtotime('+'.$duration.' minutes',strtotime($start_time)));
            $i++;
            if(strtotime($start_time) <= strtotime($end_time)){
                $time[$i]['start'] = $start;
            }
        }
        return $time;
  }
$slopt = getServiceScheduleSlots(30, '08:30AM', '07:00PM');
print_r($slopt);
-->