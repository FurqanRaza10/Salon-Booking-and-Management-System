<?php
require_once __DIR__ . '/../../application/master/add_category_controller.php';
require_once __DIR__ . '/../../application/utils/app_config.php';
require_once __DIR__ . '/../../application/utils/form_functions.php';

?>

<div class="modal-header">
    <?php if ($category_id == 0) : ?>
        <h5 class="modal-title">Add Category </h5>
    <?php else : ?>
        <h5 class="modal-title">Edit Category </h5>
    <?php endif; ?>

    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<div class="modal-body">
    <div class="card">
        <form id="category_form" method="POST" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" onsubmit="categoryFormsubmitHandler('category_form',event)">
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Category Name<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="text" class="form-control input-rounded category_name" placeholder="Category Name" value="<?php echo (isset($category_data['category_name']) ? $category_data['category_name'] : '') ?>" name="category_name">
                    </div>
                    <div class="col-xl-12  col-md-12 mb-4">
                        <label class="form-label font-w600">Upload Image<span class="text-danger scale5 ms-2">*</span></label>
                        <input type="file" class="form-control input-rounded" name="category_img">
                    </div>
                </div>
            </div>
            <input type="hidden" class="form-control input-rounded" name="category_id" value="<?php echo (isset($category_data['category_id']) ? $category_data['category_id'] : 0) ?>">
            <div class="card-footer text-end">
                <div>
                    <button class="btn btn-primary me-3" data-bs-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-secondary" value="Submit" />
                </div>
            </div>
        </form>
    </div>
</div>