<?php include_once __DIR__ . '/../../application/utils/app_config.php'; ?>
<?php include_once __DIR__ . '/../../application/utils/form_functions.php'; ?>
<?php include_once __DIR__ . '/../../application/master/add_user_role_controller.php'; ?>
<?php
include_once __DIR__ . '/../../application/utils/auth/Role.php';

use Inspire\Ahms\Application\Utils\Auth\Role;

$roleObject = new Role([

    'roleId' => $role['role_id'],

    'role' => $role['role_name'],

    'permissions' => $role['permissions'],

    'isSuper' => $role['is_super']

]);


?>
<div class="modal-header">
    <h5 class="font-medium text-base mr-auto"><?php echo $role['role_name']; ?> Permission</h5>

    <button type="button" class="btn-close" data-bs-dismiss="modal">
    </button>
</div>
<div class="modal-body">
    <div class="card">
        <form id="permission_form" action="<?php echo $app_name; ?>/application/master/add_user_role_controller.php" method="POST" onsubmit="PermissionFormhendler('permission_form',event)">
            <div class="modal-body">
                <?php foreach ($permission_group_list as $permission_group) : ?>
                    <h3 style="margin-top:10px;font-weight: 600 !important;"><?php echo $permission_group['group_name']; ?> Permission</h3>
                    <hr style="margin-bottom:10px">
                    <div class="row">



                        <?php
                        foreach ($inventory_premission_list as $permission) :

                            if ($permission['group_name'] == $permission_group['group_name']) :
                        ?>

                                <div class="col-4">
                                    <label style="white-space: none;" class="form-label font-w600">
                                        <input type="checkbox" name="role_permissions[]" value='<?php echo $permission['permission_name']; ?>' <?php if ($roleObject->hasAccess($permission['permission_name'])) echo "checked"; ?> /> <?php echo $permission['permission_name']; ?>
                                    </label>
                                </div>

                        <?php endif;
                        endforeach; ?>
                    </div>

                <?php endforeach; ?>
            </div>
            <input type="hidden" name="role_id" value="<?php echo (isset($role['role_id']) ? $role['role_id'] : 0) ?>">
            <input type="hidden" name="action" value="save_permission">
            <!-- END: Modal Body -->
            <!-- BEGIN: Modal Footer -->
            <div class="modal-footer text-right">
                <button class="btn btn-primary me-3" data-bs-dismiss="modal">Close</button>
                <input type="submit" class="btn btn-secondary" value="Submit" />
            </div>
        </form>
    </div>
</div>