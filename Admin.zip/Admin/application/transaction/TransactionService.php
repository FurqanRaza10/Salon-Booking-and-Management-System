<?php 
      namespace TransactionService;

	
	  include_once __DIR__ . '/../utils/app_config.php';
	  include_once __DIR__ . '/../utils/CoreDataService.php';
      include_once  __DIR__ .'/../utils/auth/AuthManager.php';
	  include_once __DIR__ . '/TransactionCommand.php';
	  include_once __DIR__. '/../master/MasterService.php';
	  include_once __DIR__ . '/../utils/SessionManager.php';
 
	  use Inspire\Ahms\Application\Utils\CoreDataService;
	  use TransactionCommand\TransactionCommand;
	  use Inspire\Ahms\Application\Utils\Auth\AuthManager;
      use Inspire\Ahms\Application\Utils\SessionManager; 
	  use MasterService\MasterService;

     class TransactionService extends CoreDataService
     {
		    private $SessionManager;
			private $MasterService;
		
			
			const  InvoiceNo_query ="SELECT (Max(Invoice_No)+1) as InvoiceNo From sale_master";
			const  select_addedItem_query = "SELECT * FROM table_cart as tc INNER JOIN item_master as im ON tc.Item_Id=im.Item_Id WHERE tc.Customer_Id=:user_id";
			const  select_cartItem_query = "SELECT COUNT(*) as totalitem FROM table_cart as tc INNER JOIN item_master as im ON tc.Item_Id=im.Item_Id WHERE tc.Customer_Id=:user_id";
			const  allInvoice_relatedParty_query = "SELECT sale_master.Invoice_No,DATE_FORMAT(sale_master.Invoice_Date,'%d %b %Y') as Invoice_Date,SUM((sale_item_detail.Item_Price * sale_item_detail.Quantity))as netTotal,sale_master.Payment_Status FROM `sale_master` INNER JOIN sale_item_detail ON sale_master.Invoice_No=sale_item_detail.Invoice_No where sale_master.Party_Id =:partyId and sale_master.Is_Deleted=:deleted GROUP BY sale_item_detail.Invoice_No ORDER BY sale_master.Invoice_No DESC";
			const  InvoiceBill_query = "SELECT sm.Invoice_No,DATE_FORMAT(sm.Invoice_Date,'%d-%m-%Y') as Invoice_date,pm.Party_Name,pm.Contact_Number,im.Item_Name,sid.Item_Price,sid.Quantity FROM sale_master as sm INNER JOIN party_master as pm ON sm.Party_Id=pm.Party_Id INNER JOIN sale_item_detail as sid ON sm.Invoice_No=sid.Invoice_No INNER JOIN item_master as im ON sid.Item_Id=im.Item_Id where sm.Invoice_No=:invoiceno and sm.Is_Deleted=:deleted";

			public function __construct()
			{
				  parent::__construct();
				  $this->SessionManager =new SessionManager();
				  $this->MasterService  = new MasterService();
				

			}


             public function get_cart_Item()
			 {
				if($this->SessionManager->get('admin_user')==null)
				{
					  return false;
				}
				$customer_id = $this->SessionManager->get('admin_user')->Id;
				return  $this->executeSQL(SELF::select_addedItem_query,["user_id" => $customer_id]);
				
				 

			 }
			 public function get_cart_Item_count()
			 {
				$product_count = 0;
				if($this->SessionManager->get('admin_user')==null)
				{
					  return false;
				}
				
				$customer_id = $this->SessionManager->get('admin_user')->Id;
		
				$cart_item = $this->executeSQL(SELF::select_cartItem_query,["user_id" => $customer_id]);
				if ($cart_item) {
					$product_count =  $cart_item[0]['totalitem'];
				} 
			
				return $product_count;
			 }	 
			 
            
          
     }
?>