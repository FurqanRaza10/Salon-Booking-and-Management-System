<?php
     namespace TransactionCommand;
     include_once __DIR__ . '/../utils/app_config.php';
     include_once __DIR__ . '/../utils/CoreDataService.php';
     include_once  __DIR__ .'/../utils/auth/AuthManager.php';
     include_once __DIR__ . '/TransactionService.php';
     include_once __DIR__ . '/../utils/SessionManager.php';
     include_once __DIR__.'/../master/MasterService.php';
  

     use Inspire\Ahms\Application\Utils\CoreDataService;
     use TransactionService\TransactionService;
     use MasterService\MasterService;
     use Inspire\Ahms\Application\Utils\Auth\AuthManager;
     use Inspire\Ahms\Application\Utils\SessionManager; 

     class TransactionCommand extends CoreDataService
     {    
          
          private $sessionManager;
          private $masterService;
          
          const update_quantity_savedItem = "UPDATE table_cart set Quantity=:quantity where Item_Id=:ItemId and Customer_Id=:user_id";
          const confirm_order_query = "INSERT INTO `order_master`(`CustomerNo`, `OrderId`, `ReferenceId`, `OrderStatus`, `Name`, `MobileNo`, `Item_name`, `Price`, `Quantity`, `Address1`) VALUES (:customer_id,:order_id,:reference_id,:order_status,:name,:mobile_no,:item_name,:price,:quantity,:address)";
          const Delete_addedItem_query_particular_ItemId = "DELETE FROM table_cart WHERE Item_Id=:itemId AND Customer_Id=:user_id";


          public function __construct()
          {
               parent::__construct();
               $this->sessionManager = new SessionManager();
               $this->masterService = new MasterService();
            
          }
           
     	 public function ConfirmOrder($allItems_detail)
           {
                 
               $allItems;
               $queryParameter;
               $response;
                    
                 if($this->sessionManager->get('admin_user')==null)
                 {
                       return false;
                 }

                 $customber_id = $this->sessionManager->get('admin_user')->Id;

               //max order id
               $order_max_sql = "SELECT Max(OrderId) As OrderId FROM order_master";
               $max_order_id = $this->getSingleValue($order_max_sql,'OrderId');
               if($max_order_id > 0){ $max_order_id = $max_order_id + 1;  
               }else{ $max_order_id = 1;}

               //max reference id
               $order_refer_max_sql= "SELECT Max(ReferenceId) As ReferenceId FROM order_master";
               $max_reference_id = $this->getSingleValue($order_refer_max_sql,'ReferenceId');
               if($max_reference_id > 0){ $max_reference_id = $max_reference_id + 1;  
               }else{ $max_reference_id = 101;}

               $customber_details = $this->executeSQL("SELECT * FROM customer_master WHERE Customer_Id=:customer_id",["customer_id"=>$customber_id]); 
               if(strpos($allItems_detail,',')>1)          // if item was greater than 1
               {
                         
                    $allItems = explode(',',$allItems_detail);

                    foreach($allItems as $items)
                    {

                         $item_seperated = explode(' ',$items);
                         $item_name_sql = "SELECT * FROM item_master WHERE Item_Id=:item_id";
                         $item_name = $this->executeSQL($item_name_sql,['item_id'=>$item_seperated[0]]);
                         $queryParameter_insert =
                         [
                              'customer_id' => $customber_id,
                              'order_id'    => $max_order_id,
                              'reference_id' => $max_reference_id,
                              'order_status' => 'Pending',
                              'name'        => $customber_details[0]['name'].' '.$customber_details[0]['Last_Name'],
                              'mobile_no'   => $customber_details[0]['Mobile_No'],
                              'item_name'     => $item_name[0]['Item_name'],
                              'price'       => '0.00',
                              'quantity'    => $item_seperated[1],
                              'address'     => $customber_details[0]['Address']

                         ];
                         $response = $this->performDBUpdate(SELF::confirm_order_query,$queryParameter_insert);
                         $this->performDBUpdate("DELETE FROM table_cart WHERE Customer_Id=:customber_id",["customber_id"=>$customber_id]);     
                    }
               }                                                // item have only 1
               else
               {
                    $items = explode(' ',$allItems_detail);
                    $queryParameter_insert =
                    [
                         'customer_id' => $customber_id,
                         'order_id'    => $max_order_id,
                         'reference_id' => $max_reference_id,
                         'order_status' => 'Pending',
                         'name'        => $customber_details[0]['name'].' '.$customber_details[0]['Last_Name'],
                         'mobile_no'   => $customber_details[0]['Mobile_No'],
                         'item_name'     => $items[0],
                         'price'       => '0.00',
                         'quantity'    => $items[1],
                         'address'     => $customber_details[0]['Address']

                    ];
                    $response = $this->performDBUpdate(SELF::confirm_order_query,$queryParameter_insert);
                    $this->performDBUpdate("DELETE FROM table_cart WHERE Customer_Id=:customber_id",["customber_id"=>$customber_id]);     

                    
               }

                    
               return $response;
                         
          
           
           }

           public function updateCartQuantity($itemId,$sign,$quantity)
           {
                   $response = 
                   [
                        'is_updated' => false,
                        'is_deleted' => false
                   ];
                   if($this->sessionManager->get('admin_user')==null)
                   {
                         return false;
                   }
  
                   $customber_id = $this->sessionManager->get('admin_user')->Id;

                    $finalQuantity;
                    if($sign=='+')
                    {
                          $finalQuantity = ++$quantity;
                    }
                    else if($sign=='-')
                    {
                         $finalQuantity = --$quantity;
                    }
                    else
                    {
                         $finalQuantity = $quantity;
                    }
                    

                    if($finalQuantity == 0)
                    {
                         $delete_cart_item = $this->performDBUpdate(SELF::Delete_addedItem_query_particular_ItemId,['itemId'=>$itemId,'user_id'=>$customber_id]);
                         $response = 
                         [
                              'is_updated' => false,
                              'is_deleted' => $delete_cart_item,
                              'quntity'    => $finalQuantity
                         ];
                    }
                    else{
                         $update_cart_item= $this->performDBUpdate(SELF::update_quantity_savedItem,['quantity'=>$finalQuantity,'ItemId'=>$itemId,'user_id'=>$customber_id]);
                         $response = 
                         [
                              'is_updated' => $update_cart_item,
                              'is_deleted' => false,
                              'quntity'    => $finalQuantity
                         ];
                    }
               return $response;
                   
           }


           public function removeItem($itemId)
           {
               if($this->sessionManager->get('admin_user')==null)
               {
                     return false;
               }

               $customber_id = $this->sessionManager->get('admin_user')->Id;
               return $this->performDBUpdate(SELF::Delete_addedItem_query_particular_ItemId,['user_id'=>$customber_id,'itemId'=>$itemId]);
           }
           
           
     }
?>