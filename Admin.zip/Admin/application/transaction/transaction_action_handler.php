<?php

include_once __DIR__.'/TransactionCommand.php';
include_once __DIR__.'/TransactionService.php';
include_once __DIR__.'/../utils/Response.php';


use TransactionCommand\TransactionCommand;
use TransactionService\TransactionService;
use Inspire\Ahms\Application\Utils\Response;

$transactionCommand = new TransactionCommand();
$transactionService = new TransactionService();



if($_SERVER['REQUEST_METHOD']=="POST")
{

      if($_POST['action']=="confirm_order")
      {
            
            $response = $transactionCommand->ConfirmOrder($_POST['savedItems']);
            if($response)
            {
                echo Response::generateJSONResponse(200,["isError"=>false,"successMsg"=>"Thank You, We received your Order."],"");
                exit;
            }
             echo Response::generateJSONResponse(500,["isError"=>true,"failedMsg"=>"Sorry, We did not receive your Order."],"");
             exit;
      }


      else if($_POST['action']=="updateCartQuantity")
      {
             $itemId = $_POST['ItemId'];
             $sign = $_POST['sign'];
             $quantity = $_POST['quantity'];
            
             $result = $transactionCommand->updateCartQuantity($itemId,$sign,$quantity);
             if($result['is_updated'])
             {
                   echo Response::generateJSONResponse(200,'quantity update succesfully',array("quntity"=>$result['quntity']));
                   exit;
             }
             else if($result['is_deleted']){
                  echo Response::generateJSONResponse(200,'item delete succesfully',array("quntity"=>$result['quntity']));
                  exit;
             }

             echo Response::generateJSONResponse(500,'some error was generated',"");
             exit;
      }   
      else if($_POST['action']=="removeItem")
      {
             $itemId = $_POST['itemId'];
             $response = $transactionCommand->removeItem($itemId);
             if($response)
             {
                   echo Response::generateJSONResponse(200,'Item Delete succesfully',"");
                   exit;
             }

             echo Response::generateJSONResponse(500,'some error was generated',"");
             exit;
      }


     
   
}


if($_SERVER['REQUEST_METHOD']=="GET")
{
     if($_GET['action']=="getaddedItem")
    {
              $response = $transactionService->get_addedItem();
              echo Response::generateJSONResponse(200,["isError"=>false,"successMsg"=>"item fetched succesfully"],$response);
              exit;
             
    }
    if($_GET['action'] == "count_cart_item")
    {
            $response = $transactionService->get_cart_Item_count();
            echo Response::generateJSONResponse(200,["isError"=>false,"successMsg"=>"count_cart_item"],$response);
            exit;
    }

}





?>