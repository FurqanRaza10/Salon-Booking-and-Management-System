<?php
  date_default_timezone_set ( "Asia/Kolkata" );
  $product_name = "Salon Hub";
  $app_name = "/salon_booking/Admin";
  
  
?>
