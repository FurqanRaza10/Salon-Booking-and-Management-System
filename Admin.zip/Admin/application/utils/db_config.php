<?php
# ---------------------------------------------------------------
# MySql
define('DB_NAME', 'salon_booking');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_DRIVER', 'mysql');


// Databae for server
// define('DB_NAME', 'ezyro_37784199_salon_booking');
// define('DB_USER', 'ezyro_37784199');
// define('DB_PASSWORD', '1cf9ae7aaa');
// define('DB_HOST', 'sql212.ezyro.com');
// define('DB_DRIVER', 'mysql');

?>
