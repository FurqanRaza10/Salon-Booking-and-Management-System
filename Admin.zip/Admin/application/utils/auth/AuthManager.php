<?php

namespace Inspire\Ahms\Application\Utils\Auth;



include_once __DIR__ . '/../CoreDataService.php';

include_once __DIR__ . '/../SessionManager.php';

include_once __DIR__ . '/User.php';

include_once __DIR__ . '/../app_config.php';



use Inspire\Ahms\Application\Utils\CoreDataService;

use Inspire\Ahms\Application\Utils\SessionManager;

use Inspire\Ahms\Application\Utils\Auth\User;

use stdClass;



class AuthManager extends CoreDataService

{

	/**

	 * holds logged in user object

	 * @var User

	 */

	private $user;



	private $sessionManager;



	public function __construct()

	{

		parent::__construct();



		$this->sessionManager = new SessionManager();

		$this->user = null;

	}

	

	public static function getInstance()

	{

		static $authManager;

		

		if(is_null($authManager))

			$authManager = new AuthManager();

		return  $authManager;

	}

	public function registerUser($user_detail)
	{
		// $user = [
		// 	"new_user" => false,
		// 	"exist_user" => false
		// ];
		// $Check_user_sql = "SELECT * FROM customer_master WHERE Mobile_No=:mobile_no";

		// $user_check = $this->executeSQL($Check_user_sql,
		// [
		// 	"mobile_no" => $user_detail['mobile'],
		// ]);

		// if(empty($user_check))
		// {
		// 	$new_password = password_hash($user_detail['mobile'],PASSWORD_BCRYPT);

		// 	$add_user_sql = "INSERT INTO `customer_master`(`name`, `Last_Name`, `Mobile_No`, `Password`, `Address`, `Delivery_Address`) VALUES (:name,:last_name,:mobile_no,:password,:address,:delivery_address)";
		// 	$add_user_parameter = 
		// 	[
		// 		'name'  => $user_detail['fname'],
		// 		'last_name'   => $user_detail['lname'],
		// 		'mobile_no'   => $user_detail['mobile'],
		// 		'password'    => $new_password,
		// 		'address'	  => $user_detail['address'],
		// 		'delivery_address' => $user_detail['delivery_address']

		// 	];

		// 	$add_user = $this->performDBUpdate($add_user_sql,$add_user_parameter);

		// 	$user = [
		// 		"new_user" => $add_user,
		// 		"exist_user" => false
		// 	];
		// }
		// else{
		// 	$user = [
		// 		"new_user" => false,
		// 		"exist_user" => true
		// 	];
		// }	


		// return $user;
	}

	/**

	 * Perform authentication based on credential supplied

	 * if user found set User object in session or as of now simply set user_id in session

	 * @param  string $user_id   

	 * @param  string $password  

	 * @return boolean           

	 */

	public function performAuth($user_name,$password)

	{

		global $app_name;

		$auth_sql = 'SELECT * FROM users_view WHERE user_name=:user_name AND status=:status';

		$user = $this->executeSQL($auth_sql,['user_name' => $user_name,'status' => 1],true);

		if(is_null($user) || !empty($user))

		{

			if (password_verify($password, $user['password'])) 

			{

				//User is successfully logged in all auth params are right

				//store user object inside session

				

				// prepare user object

				 $this->user = new stdClass();

				 $this->user->Id  =  $user['user_id'];

				 $this->user->firstName = $user['name'];

				 $this->user->Mobile_No = $user['mobile_no'];

				 $this->user->password = $user['password'];

				 $this->user->userRoleId = $user['role_id'];

				 $this->user->SalonId = $user['salon_id'];

				 $this->user->isSuper = $user['is_super'];

                

				//store user object

				$this->sessionManager->store('admin_user',$this->user);

				$this->sessionManager->store('app_name',$app_name);

				return true;

			}else{

				return false;

			}

		}

		return false;			 

	}

	/**

	 * fetch logged in user object from session object

	 * @return User

	 */

	public function getLoggedInUser()

	{	

		$admin_user_obj = (array) $this->sessionManager->get('admin_user');

		$admin_user = new User($admin_user_obj);

		return $admin_user;

	}

	/**

	*  Get logged in user role

	* @return Role

	*/	

	public function getLoggedInUserRole()

	{

		$admin_user = $this->getLoggedInUser();

		return $admin_user->getRole();

	}

	/**

	 * check session manager for logged in user bject

	 * @return boolean 

	 */

	public function isUserLoggedIn()

	{

		global $app_name;

		return ( $this->sessionManager->has('admin_user') && ($this->sessionManager->get('app_name') == $app_name));		

	}



	/**

	 * Logout user 

	 * Remove logged in user object from session

	 * @return

	 */

	public function logout()

	{

		$this->sessionManager->removeAll();

	}

	public function changePassword($new_password)

	{

		$admin_user = $this->getLoggedInUser();

		

		$new_password = password_hash($new_password,PASSWORD_BCRYPT);

		$change_password_sql = 'Update admin_login SET Password=:new_password WHERE Id=:User_Id';

		return $this->performDBUpdate($change_password_sql,['new_password'=>$new_password,'User_Id'=>$admin_user->Id]);

		

	}

}