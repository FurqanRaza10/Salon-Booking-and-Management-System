<?php

namespace Inspire\Ahms\Application\Utils\Notification;



// include_once __DIR__ .'/../../../vendor/autoload.php';

include_once __DIR__ . '/../Logger.php';

include_once __DIR__.'/../../../application/utils/app_config.php';



use Inspire\Ahms\Application\Utils\Logger;

// use PHPMailer;

/**

* This class will help to send email with gievn data

*/

class EmailNotifier

{

	/**

	 * PHPMailer type

	 * @var PHPMailer

	 */

	private  $mail;



	public function __construct()

	{

		$this->init();

	}

	public  function init()

	{

		global $report_config;



		// $this->mail = new PHPMailer;

		$this->mail->isSMTP();                                      // Set mailer to use SMTP

		$this->mail->Host = 'md-in-48.webhostbox.net';  // Specify main and backup SMTP servers

		$this->mail->SMTPAuth = true;                               // Enable SMTP authentication

		$this->mail->Username = 'no-reply@inspiresoftware.in';                 // SMTP username

		$this->mail->Password = 'inspire@2009';                           // SMTP password

		$this->mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted

		$this->mail->Port = 587;                                    // TCP port to connect to

		$this->mail->setFrom('no-reply@inspiresoftware.in',$report_config['hotel_name'],FALSE);

		$this->mail->isHTML(true);                                  // Set email format to HTML

	}



	public  function send($to = [], $subject,$message_body, $attachments = [])

	{	

		//set receipants

		foreach ($to as $key => $receiver_address) {

			$this->mail->addAddress($receiver_address);     // Add a recipient

		}



		//set attachements

		foreach ($attachments as $key => $attachment) {

			$this->mail->addAttachment($attachment);         // Add attachments

		}



		$this->mail->Subject = $subject;

		$this->mail->Body    = $message_body;



		return $this->mail->send();

	}
	public static function sendOtpEmail($email,$otp)
	{   
		$subject="OTP Verification";
		$body = $otp.' is your OTP for user registration at Salon Hub.';
		$header= "From: hschaudhary06@gmail.com";

		if (mail($email,$subject,$body,$header)) {
           return true;
		}else{
			return false;
		}
	}

	public static function sendConfirmBooking($email){
		$subject="Booking Confirmation";
		$body = 'Your Booking is confirmed, Thank you for booking';
		$header= "From: hschaudhary06@gmail.com";

		if (mail($email,$subject,$body,$header)) {
           return true;
		}else{
			return false;
		}
	}

}