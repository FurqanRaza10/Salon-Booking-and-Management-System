<?php
namespace Inspire\Ahms\Application\Utils\Notification;

include_once __DIR__ . '/../Logger.php';

use Inspire\Ahms\Application\Utils\Logger;
/**
* Use queue to notify via sms
* so queue will process in background to send sms notification
*/
class SMSNotifier
{
   /**
    *  base URL for each Transaction SMS API
    */
    private  static $TSMSAPI_BASE_URL = "http://tsms.krishsoftweb.in/";
    // username to access API
    private static $MOBILE = "9662087437";
    // password to access API
    private static $TSMSPASSWORD = "DEMOT_USERNAME";
    // senderid to access API
    private static $SENDERID = "DEMOT_PASSWORD";

    /**
    *  base URL for each Promotional SMS API OF 
    */

    private static $PSMSAPI_BASE_URL = "http://psms.krishsoftweb.in/";

    private static $PSMSPASSWORD = "DEMOP_USERNAME";

    const SHOULD_SEND_SMS = false;

     /**
    * Notify user via sms for checkin
    * @param $receive_mobile unique value to identify this user in SMS system
    * @param $guest_of_message number of user to activate for same username and password
    * @param Chechin Template Hello % , Welcome to Hotel Salute, Your room no is : % Thanks, Hotel Salute.
    * @param ChechOut Template Hello % customer_name %, Thanks for visit to Hotel Salute, Thanks, Hotel Salute.
    * @param Auto Template Hey % auto driver name %, We appreciate your support to Hotel Salute. Thanks for cooperation. Thanks, Hotel Salute
    */

    public static function wishForCheckinURL($room_no,array $guest_detail)
    {
        $sent_checkin_msg = urlencode("Hello  ".$guest_detail['person_name'].", Welcome to Hotel Salute, Your room no is : ".$room_no.". Thanks, Hotel Salute.");

        $checkin_api_url = self::$TSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$TSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$guest_detail['mobile_no']."&msg=".$sent_checkin_msg;
       
        return $checkin_api_url;

    }
    
     /**
    * Notify user via sms for checkout
    */
    public static function wishForCheckoutURL(array $checkin_details)
    {
        $sent_checkout_msg = urlencode("Hello  ".$checkin_details['Guest_Name']." ,Thanks for visit to Hotel Salute. Thanks, Hotel Salute.");

        $checkout_api_url = self::$TSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$TSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$checkin_details['Mobile']."&msg=".$sent_checkout_msg;

        return $checkout_api_url;
    }
    /**
    * This will cover all room services like laundry,food,misc and taxi
    */
    public static function wishForAutoURL(array $autocomission_detail)
    {
        $sent_auto_msg = urlencode("Hey ".$autocomission_detail['driver_name']." , We appreciate your support to Hotel Salute. Thanks for cooperation. Thanks, Hotel Salute.");

        $auto_api_url = self::$TSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$TSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$autocomission_detail['driver_mobile_number']."&msg=".$sent_auto_msg;
        
        return $auto_api_url;
    }

    public static function wishForRoomTransferURL(array $checkin_details,$previous_room,$new_room_no)
    {
        $sent_room_transfer_msg = urlencode("Dear  ".$checkin_details['Guest_Name']." , Your room no has be transfer From : ".$previous_room." to ".$new_room_no." . Thanks, Hotel Salute.");

        $checkin_room_transfer_url = self::$TSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$TSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$checkin_details['Mobile']."&msg=".$sent_room_transfer_msg;

       // Logger::log($checkin_room_transfer_url);
        return $checkin_room_transfer_url;
    }

    public static function sendFoodBillSMS(array $checkin_details,$current_food_bill)
    {
        $sent_room_transfer_msg = urlencode("Dear ".$checkin_details['Guest_Name'].", You have order food of amount ".$current_food_bill.". Thanks, Hotel Salute.");

        $checkin_room_transfer_url = self::$TSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$TSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$checkin_details['Mobile']."&msg=".$sent_room_transfer_msg;

       // Logger::log($checkin_room_transfer_url);
        return $checkin_room_transfer_url;
    }

    public static function wishForPromotionalSms(array $promotional_details)
        {
            $guest_mobile = implode(",",$promotional_details['guest_mobile']);

            $promotional_sms_url = self::$PSMSAPI_BASE_URL."sendsms.aspx?mobile=".self::$MOBILE."&pass=".self::$PSMSPASSWORD."&senderid=".self::$SENDERID."&to=".$guest_mobile."&msg=".urlencode($promotional_details['message']);

            //Logger::log($promotional_sms_url);
            return self::executeAPI($promotional_sms_url);
        }


    //private methods

    /**
    *  Call API
    *
    *  @param $api_url
    *
    * @return API response 
    */
    private static function executeAPI( $api_url )
    {   
        if (self::SHOULD_SEND_SMS){
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,$api_url);
            curl_setopt ( $ch ,CURLOPT_RETURNTRANSFER,1 );
            $output = curl_exec($ch);
            curl_close($ch);
            //Logger::log($api_url);
            return $output;
        }else
         {
            return null;
        }    
    }
   
}
