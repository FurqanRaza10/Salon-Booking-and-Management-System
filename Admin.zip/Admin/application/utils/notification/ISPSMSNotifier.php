<?php
namespace Inspire\Ahms\Application\Utils\Notification;

include_once __DIR__ . '/../Logger.php';

use Inspire\Ahms\Application\Utils\Logger;

/**
* This class will be used to send SMS for wifi username and password from
* internet service provider for example fasttrack.
*/
class ISPSMSNotifier
{
    /**
    *  base URL for each API
    */
    private  static $API_BASE_URL = "http://api.janitorradius.com";
    // api_key
    private static $API_KEY = "G94LK8X37";
    // id
    private static $ID = 20;
    
    
     /**
    * Notify user via sms for checkin
    * @param $unique_value unique value to identify this user in ISP system
    * @param $register_no 
    * @param $room_no 
    * @param $number_of_user number of user to activate for same username and id
    * @param $guest_detail array - which holds guest detail
    */
    public static function notifyForCheckinURL($register_no,$room_no,$number_of_user,array $guest_detail, $action_by)
    {
        $checkin_api_url = self::$API_BASE_URL."/".self::$API_KEY."/".self::$ID."/checkin/".urlencode($action_by)."/".$room_no."/".$register_no."/".$number_of_user."/".urlencode($guest_detail['person_name'])."//".$guest_detail['mobile_no'];
        // Logger::log("Checkin Wifi API URl");
        // Logger::log($checkin_api_url);
        return $checkin_api_url;
    }
    
     /**
    * Notify user via sms for checkout
    */
    public static function notifyForCheckoutURL($room_no,$action_by)
    {
        $checkout_api_url = self::$API_BASE_URL."/".self::$API_KEY."/".self::$ID."/checkout/".urlencode($action_by)."/".$room_no;

        return $checkout_api_url;
    }
    /**
    * This will cover all room services like laundry,food,misc and taxi
    */
    public static function notifyForRoomTransferURL($old_room_no,$new_room_no,$action_by)
    {
        $room_transfer_api_url = self::$API_BASE_URL."/".self::$API_KEY."/".self::$ID."/transfer/".urlencode($action_by)."/".$old_room_no."/".$new_room_no;

        return $room_transfer_api_url;
    }

    public static function notifyForCheckinEditURL($room_no,$person_name,$number_of_user, $action_by)
    {
        $checkin_api_url = self::$API_BASE_URL."/".self::$API_KEY."/".self::$ID."/edit/".urlencode($action_by)."/".$room_no."/".urlencode($person_name)."/".$number_of_user;
        
        return $checkin_api_url;
    }
    /**
    *  Grant more users to access same wifi internet
    */    
    public static function grantMoreUser($room_no,$number_of_user)
    {
         $more_user_grant_api_url = self::$API_BASE_URL."/".self::$API_KEY."/".self::$ID."&newsim_user=".$number_of_user."&roomno=".$room_no;

        return $more_user_grant_api_url;
    }
    
    
}
