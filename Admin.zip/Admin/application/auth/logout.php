<?php

include_once __DIR__.'/../utils/app_config.php';

include_once __DIR__.'/../utils/auth/AuthManager.php';



use Inspire\Ahms\Application\Utils\Auth\AuthManager;



$authManager = AuthManager::getInstance();

$authManager->logout();

// setcookie('user_id','',time() - (86400));
// setcookie('password','',time() - (86400));

header('Location: '.$app_name.'/index.php');

exit;

?>
