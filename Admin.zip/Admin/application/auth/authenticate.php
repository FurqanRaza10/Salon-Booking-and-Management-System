<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

include_once __DIR__ . '/../utils/auth/AuthManager.php';
include_once __DIR__ . '/../utils/Response.php';
include_once __DIR__ . '/../utils/Validator.php';
include_once __DIR__ . '/../libraries/collection/Collection.php';



use Inspire\Ahms\Application\Utils\Auth\AuthManager;

use Inspire\Ahms\Application\Utils\Response;

use Inspire\Ahms\Application\Utils\Validator;

use PHPR\Collection;



 if(isset($_POST['user_name']) && isset($_POST['password']))
 {


     
       $user=$_POST['user_name'];
       $pass=$_POST['password'];
   

       $error_collection= new collection([]);

       $rules=[

          'user_name'=>['required'],
          'password'=>['required','min_length:6']

       ];

          
       $validator= Validator::makeValidator($_POST,$rules,true);
       
       
       if($validator->isValidationFailed())
       {
            $error_collection= new Collection($validator->getErrorMessages());

            $error_collection->set('message_tittle','Please correct below errors');

            echo Response::generateJSONResponse(400, "Auth Failed due to invalid data", $error_collection->values());

            exit;


       }
  
        
       $authManager= AuthManager::getInstance();
        
      
       $authenticated=$authManager->performAuth($user,$pass);
        
       if($authenticated)
       {
             echo Response::generateJSONResponse(200, "Succesfully logged In","");
       }
       else
       {
             $error_collection->set("message_tittle",'Either Username or Password is in correct..');
             echo Response::generateJSONResponse(500, "Auth Failed due to incorrct auth data",$error_collection->values());
       }

 }





?>