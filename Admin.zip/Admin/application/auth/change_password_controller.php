<?php

include_once __DIR__ . '/../auth/check_auth_session.php';

include_once __DIR__ . '/../utils/Validator.php';

include_once __DIR__ . '/../libraries/collection/Collection.php';

include_once __DIR__ . '/../utils/Response.php';



use Inspire\Ahms\Application\Utils\Response;

use Inspire\Ahms\Application\Utils\Validator;

use PHPR\Collection;



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Hanlde post request for Login

    $error_messages = new Collection([]);

    $rules = [

        'old_password' => ['required', 'min_length:5'],

        'new_password' => ['required', 'min_length:5'],

    ];

    $validator_instance = Validator::makeValidator($_POST, $rules, true);

    if ($validator_instance->isValidationFailed()) {

        //Preparing collection for error messages

        $error_messages = new Collection($validator_instance->getErrorMessages());

        $error_messages->set('message_title', 'Please correct below errors');



        echo Response::generateJSONResponse(400, "Auth Failed due to invalid data", $error_messages->values());

        exit;

    } 

    $admin_user = $authManager->getLoggedInUser();

    // verify old password
   // print_r($admin_user->password);
    if (password_verify($_POST['old_password'], $admin_user->password) === FALSE) {

        $error_messages->set('message_title', 'Old Password is incorrect.');

        echo Response::generateJSONResponse(400, " Old Password is incorrect", $error_messages->values());

        exit;

    }

    // confirm password login



    if ($_POST['new_password'] !== $_POST['con_password']) {

        $error_messages->set('message_title', 'New Password and confirm password does not match.');

        echo Response::generateJSONResponse(400, " New Password and confirm password does not match", $error_messages->values());

        exit;

    }

    $change_password = $authManager->changePassword($_POST['new_password']);

    if ($change_password) {
        
        echo Response::generateJSONResponse(200, " Change Password Successfully in", array("change_password" => $change_password));

        exit;

    }

    $error_messages->set('message_title', 'Error while changing password.');

    echo Response::generateJSONResponse(500, "Auth Failed due to incorrect auth data", $error_messages->values());

    exit;

} //if($_SERVER['REQUEST_METHOD']==....

