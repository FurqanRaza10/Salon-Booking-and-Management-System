<?php

require_once __DIR__ . '/../utils/Validator.php';
require_once __DIR__ . '/../libraries/collection/Collection.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/MasterCommand.php';
require_once __DIR__ . '/MasterService.php';
require_once __DIR__ . '/../auth/check_auth_session.php';


use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use MasterCommand\MasterCommand;
use MasterService\MasterService;

$collection   = new Collection([]);
$MasterCommand = new MasterCommand();
$MasterService = new MasterService();

$sloat_id = isset($_GET['sloat_id']) ? $_GET['sloat_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

      $sloat_data=$MasterService->getSloatById($sloat_id);
      
}


// POST request block

if ($_SERVER['REQUEST_METHOD'] == "POST") {

      $collection = new Collection([]);
      $rules = [

            'sloat_date' => ['required'],
            'sloat_duration' => ['required'],
            'start_time' => ['required'],
            'end_time' => ['required'],
            'status' => ['required'],
      ];

      $validator = Validator::makeValidator($_POST, $rules, true);


      if ($validator->isValidationFailed()) {
            $error_collection = new Collection($validator->getErrorMessages());
            $error_collection->set("message_tittle", "Please correct below errors");
            echo Response::generateJSONResponse(400, 'Required all fields', $error_collection->values());
            exit;
      }



      $check = $MasterCommand->CreateSloat($_POST);

      if ($check['is_added']) {
            echo Response::generateJSONResponse(200, 'Sloat succesfully Created.', ['is_added' => $check['is_added']]);
            exit;
      } else if ($check['is_update']) {
            echo Response::generateJSONResponse(200, 'Sloat succesfully Updated.', ['is_updated' => $check['is_update']]);
            exit;
      } elseif ($check['is_exist']) {
            echo Response::generateJSONResponse(200, 'You have already created a Slot.', ['is_exist' => $check['is_exist']]);
            exit;
      }

      $collection->set("message_tittle", "Sloat is not Create.", "");
      echo Response::generateJSONResponse(500, 'Unable to Create Sloat due to some reasons', $collection->values());
      exit;
}
