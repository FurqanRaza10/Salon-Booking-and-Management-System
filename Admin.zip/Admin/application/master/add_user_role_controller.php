<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once __DIR__ . '/../utils/Validator.php';
require_once __DIR__ . '/../libraries/collection/Collection.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/MasterCommand.php';
require_once __DIR__ . '/MasterService.php';
require_once __DIR__ . '/../auth/check_auth_session.php';

use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use MasterCommand\MasterCommand;
use masterservice\MasterService;

$MasterCommand= new MasterCommand();
$MasterService= new MasterService();

$role_id = isset($_GET['role_id']) ? $_GET['role_id'] : 0;

if($_SERVER['REQUEST_METHOD'] == "GET")
{
    $permission_group_list = $MasterService->getGroupPermission();

    $permission_list = $MasterService->getPermissions();

    $inventory_premission_list = array_filter($permission_list, function ($permission_item) {

        if ($permission_item['permission_for'] == "Inventory") {

            return $permission_item;
        }
    });

    $role = $MasterService->getRoleById($role_id);
}

if($_SERVER['REQUEST_METHOD'] == "POST" && $_POST['action'] == "save_role")
{
    $collection= new Collection([]);

    $rules = [
        'roleName' => ['required'],
    ];

    $validator=Validator::makeValidator($_POST,$rules,true);
     

    if($validator->isValidationFailed())
    {
         $error_collection= new Collection($validator->getErrorMessages());
         $error_collection->set("message_tittle","Please correct below errors");
         echo Response::generateJSONResponse(400,'Required all fields',$error_collection->values());
         exit;
    }

    $add_role = $MasterCommand->SaveRole($_POST);
    

    if($add_role['is_added']){
        echo Response::generateJSONResponse(200,'Role succesfully saved..',['is_added' => $add_role['is_added']]);
        exit;
    }
    elseif ($add_role['is_updeted']) {
        echo Response::generateJSONResponse(200,'Role succesfully Update..',['is_updated' => $add_role['is_updeted']]);
        exit;
    }

    $collection->set("message_tittle","Role is not saved..","");
    echo Response::generateJSONResponse(500,'Unable to saved Role due to some reasons',$collection->values());
    exit;
}

if($_SERVER['REQUEST_METHOD'] == "POST" && $_POST['action'] == "save_permission")
{
    $is_permission_saved = $MasterCommand->saveRolePermission($_POST);

    if ($is_permission_saved) {

        echo Response::generateJSONResponse(200, "Permision successfully saved.", array("is_permission_saved" => $is_permission_saved));
        exit;
    }

    $error_messages->set('message_title', 'Permision is not saved.');
    echo Response::generateJSONResponse(500, "Unable to saved Permision  due to incorrect  data", $error_messages->values());
    exit;
}

?>
