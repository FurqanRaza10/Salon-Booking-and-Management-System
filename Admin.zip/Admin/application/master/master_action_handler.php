<?php


require_once __DIR__ . '/MasterCommand.php';
require_once __DIR__ . '/MasterService.php';
require_once __DIR__ . '/../utils/app_config.php';
require_once __DIR__ . '/../utils/Response.php';

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Auth\AuthManager;
use Inspire\Ahms\Application\Utils\Response;
use MasterCommand\MasterCommand;
use MasterService\MasterService;

$MasterService = new MasterService();
$MasterCommand = new MasterCommand();

// Handle GET request
if ($_SERVER['REQUEST_METHOD'] == 'GET') {

	$action = $_GET['action'];
	if ($action == "getAppointment") {
		$appointment_result = $MasterService->GetAppointment($_GET['status']);
		echo Response::generateJSONResponse(200, 'Appointment Data', ['appointment_data' => $appointment_result]);
	} elseif ($action == "get_category_list") {
		$category_list = $MasterService->GetCategoryList();
		echo Response::generateJSONResponse(200, 'Category List', ['category_list' => $category_list]);
	} elseif ($action == "get_service_list") {
		$service_list = $MasterService->GetServiceList();
		echo Response::generateJSONResponse(200, 'Service List', ['service_list' => $service_list]);
	} elseif ($action == "get_sloat_list") {
		$sloat_list = $MasterService->GetSloatList();
		echo Response::generateJSONResponse(200, 'Sloat List', ['sloat_list' => $sloat_list]);
	} elseif ($action == "get_user_list") {
		$user_list = $MasterService->GetUserList();
		echo Response::generateJSONResponse(200, 'User List', ['user_list' => $user_list]);
	} elseif ($_GET['action'] == "get_role_list") {
		$role_list =  $MasterService->getRoleList();
		echo Response::generateJSONResponse(200, "success", ["RoleList" => $role_list]);
	}
	elseif ($_GET['action'] == "get_booking_details") {
		$booking_details =  $MasterService->getBookingDetails($_GET['booking_id']);
		echo Response::generateJSONResponse(200, "Booking Details", ["booking_detail" => $booking_details]);
	}
}

// Handle Post request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$action = $_POST['action'];
	if ($action == "delete_service") {
		$delete_service = $MasterCommand->DeleteService($_POST['service_id']);
		echo Response::generateJSONResponse(200, 'Service Delete', ['is_delete' => $delete_service]);
	}
	elseif ($action == "Accept_booking") {
		$accept_booking = $MasterCommand->Accept_Booking($_POST['booking_no']);
		echo Response::generateJSONResponse(200, 'Accept Booking', ['is_book' => $accept_booking]);
	}
	elseif ($action == "cancel_booking") {
		$cancel_booking = $MasterCommand->Cancel_Booking($_POST['booking_id']);
		echo Response::generateJSONResponse(200, 'Cancel Booking', ['is_cancel' => $cancel_booking]);
	}
	elseif ($action == "Salon_status_change") {
		$Salon_status_changes = $MasterCommand->Salon_status_change($_POST['status']);
		if ($_POST['status'] == "true")
			echo Response::generateJSONResponse(200, 'Now Salon is open.', ['is_open' => $Salon_status_changes]);
		else
			echo Response::generateJSONResponse(200, 'Now Salon is close.', ['is_close' => $Salon_status_changes]);
		
	}
	elseif ($action == "delete_user") {
		$delete_user = $MasterCommand->DeleteUser($_POST['user_id']);
		echo Response::generateJSONResponse(200, 'User Deleted', ['is_delete' => $delete_user]);
	}
	elseif ($action == "delete_categary") {
		$delete_categary = $MasterCommand->DeleteCategary($_POST['categary_id']);
		echo Response::generateJSONResponse(200, 'Categary Deleted', ['is_delete' => $delete_categary]);
	}
}
