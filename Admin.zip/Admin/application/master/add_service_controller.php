<?php

require_once __DIR__ . '/../utils/Validator.php';
require_once __DIR__ . '/../libraries/collection/Collection.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/MasterCommand.php';
require_once __DIR__ . '/MasterService.php';
require_once __DIR__ . '/../auth/check_auth_session.php';


use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use MasterCommand\MasterCommand;
use MasterService\MasterService;

$collection   = new Collection([]);
$MasterCommand = new MasterCommand();
$MasterService = new MasterService();

$service_id = isset($_GET['service_id']) ? $_GET['service_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

      $service_data=$MasterService->getServiceById($service_id);
      $category_list = ['' => '--Select Category--'] + $MasterService->getDropDownOptions('SELECT * FROM category_master WHERE salon_id=' . $userDetail->SalonId . ' AND status=1 ORDER BY category_name ASC');
      
}


// POST request block

if ($_SERVER['REQUEST_METHOD'] == "POST") {

      $collection = new Collection([]);
      $rules = [

            'category_name' => ['required'],
            'service_name' => ['required'],
            'price' => ['required'],
            'status' => ['required'],


      ];

      $validator = Validator::makeValidator($_POST, $rules, true);


      if ($validator->isValidationFailed()) {
            $error_collection = new Collection($validator->getErrorMessages());
            $error_collection->set("message_tittle", "Please correct below errors");
            echo Response::generateJSONResponse(400, 'Required all fields', $error_collection->values());
            exit;
      }



      $check = $MasterCommand->SaveService($_POST);

      if ($check['is_added']) {
            echo Response::generateJSONResponse(200, 'Service succesfully saved.', ['is_added' => $check['is_added']]);
            exit;
      } else if ($check['is_updated']) {
            echo Response::generateJSONResponse(200, 'Service succesfully Updated.', ['is_updated' => $check['is_updated']]);
            exit;
      }

      $collection->set("message_tittle", "Service is not saved.", "");
      echo Response::generateJSONResponse(500, 'Unable to saved Service due to some reasons', $collection->values());
      exit;
}
