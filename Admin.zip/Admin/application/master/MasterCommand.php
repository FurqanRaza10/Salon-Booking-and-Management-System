<?php

namespace MasterCommand;


// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once __DIR__ . '/../utils/CoreDataService.php';
require_once __DIR__ . '/MasterService.php';
require_once __DIR__ . '/../utils/SessionManager.php';
require_once __DIR__ . '/../utils/notification/EmailNotifier.php';
require_once __DIR__ . '/../../public/cloudinary/vendor/autoload.php';
require_once __DIR__ . '/../../public/cloudinary/config_cloudinary.php';

use \DateTime;
use Inspire\Ahms\Application\Utils\Notification\EmailNotifier;
use Inspire\Ahms\Application\Utils\CoreDataService;
use MasterService\MasterService;
use Inspire\Ahms\Application\Utils\SessionManager;

class MasterCommand extends CoreDataService
{
    const CATEGORY_SAVE_SQL = "INSERT INTO `category_master`(`category_name`, `img_path`, `salon_id`, `created_by`) VALUES (:category_name,:img_path,:salon_id,:created_by)";
    const CATEGORY_UPDATE_SQL = "UPDATE `category_master` SET `category_name`=:category_name,`salon_id`=:salon_id,`updated_date`=:updated_date,`updated_by`=:updated_by WHERE category_id=:category_id";
    const CATEGORY_UPDATE_WITH_IMG_SQL = "UPDATE `category_master` SET `category_name`=:category_name,`img_path`=:img_path,`salon_id`=:salon_id,`updated_date`=:updated_date,`updated_by`=:updated_by WHERE category_id=:category_id";
    const DELETE_CATEGARY_SQL = "DELETE FROM `category_master` WHERE `category_id`=:categary_id";
    const SERVICE_SAVE_SQL = "INSERT INTO `service_master`(`category_id`, `service_name`, `price`, `created_by`, `salon_id`, `status`) VALUES (:category_id,:service_name,:price,:created_by,:salon_id,:status)";
    const SERVICE_UPDATE_SQL = "UPDATE `service_master` SET `category_id`=:category_id,`service_name`=:service_name,`price`=:price,`updated_date`=:updated_date,`updated_by`=:updated_by,`salon_id`=:salon_id,`status`=:status WHERE `service_id`=:service_id";
    const DELETE_SERVICE_SQL = "DELETE FROM `service_master` WHERE `service_id`=:service_id";
    const DELETE_USER_SQL = "DELETE FROM `user_master` WHERE `user_id`=:user_id";
    const SLOAT_SAVE_SQL = "INSERT INTO `sloat_master`(`sloat_date`, `sloat_start_time`, `sloat_end_time`, `sloat_duration`, `specialist_id`, `salon_id`, `is_active`) 
                            VALUES (:sloat_date,:sloat_start_time,:sloat_end_time,:sloat_duration,:specialist_id,:salon_id,:is_active)";
    const SLOAT_UPDATE_SQL = "UPDATE `sloat_master` SET `is_active`=:is_active WHERE `sloat_id`=:sloat_id";
    const SALON_OPEN_CLOSE = "UPDATE `salon_master` SET `is_open_close`=:is_open_close WHERE `salon_id`=:salon_id";

    function __construct()
    {
        parent::__construct();
        $this->masterService = new MasterService();
        $this->SessionManager = new SessionManager;
    }

    public function SaveCategory($category_details)
    {
        $check = [
            'is_added' => false,
            'is_update' => false
        ];

        if (isset($_FILES['category_img']['name'])) {
            $img = $_FILES['category_img']['name'];
            $img_temp = isset($_FILES['category_img']['tmp_name']) ? $_FILES['category_img']['tmp_name'] : '';
            $img_path = explode('.', $img);
            $category_img = uniqid(rand(00000, 99999)) . $img_path[0];
        } else {
            $img = "";
            $category_img = "";
        }

        $category_parem = [

            'category_name' => $category_details['category_name'],
            'salon_id'      => $this->SessionManager->get('admin_user')->SalonId,

        ];
        if ($category_details['category_id'] == 0) {
            $category_parem['created_by'] = $this->SessionManager->get('admin_user')->Id;
            $category_parem['img_path'] = $category_img;
            if ($img != "") {
                \Cloudinary\Uploader::upload($img_temp,   array("folder" => folder_dir . "categories/", "public_id" => (string)$category_img));
            }

            $category_add = $this->performDBUpdate(SELF::CATEGORY_SAVE_SQL, $category_parem);
            $check = [
                'is_added' => $category_add,
                'is_update' => false
            ];
        } else {
            $category_parem['category_id'] = $category_details['category_id'];
            $category_parem['updated_date'] = date("Y-m-d H:i:s");
            $category_parem['updated_by']   = $this->SessionManager->get('admin_user')->Id;

            if ($img == "") {
                $category_update = $this->performDBUpdate(SELF::CATEGORY_UPDATE_SQL, $category_parem);
            } else {
                $category_parem['img_path'] = $category_img;

                /* add img on cloudinary */
                $img_category_list_sql = "SELECT img_path FROM `category_master` WHERE category_id=:category_id";
                $img_category = $this->executeSQL($img_category_list_sql, ['category_id' => $category_details['category_id']]);

                foreach ($img_category as $key => $img_category_list) {
                    $img_category_list['img_path'];
                    \Cloudinary\Uploader::destroy(folder_dir . "categories/" . (string)$img_category_list['img_path']);
                }


                $category_update = $this->performDBUpdate(SELF::CATEGORY_UPDATE_WITH_IMG_SQL, $category_parem);
                \Cloudinary\Uploader::upload($img_temp,   array("folder" => folder_dir . "categories/", "public_id" => (string)$category_img));
            }

            $check = [
                'is_added' => false,
                'is_updated' => $category_update
            ];
        }


        return $check;
    }

    public function SaveService($service_details)
    {
        $check = [
            'is_added' => false,
            'is_update' => false
        ];

        $service_parem = [

            'category_id' => $service_details['category_name'],
            'service_name'  => $service_details['service_name'],
            'price'         => $service_details['price'],
            'salon_id'      => $this->SessionManager->get('admin_user')->SalonId,
            'status'        => $service_details['status'],

        ];
        if ($service_details['service_id'] == 0) {
            $service_parem['created_by'] = $this->SessionManager->get('admin_user')->Id;

            $service_add = $this->performDBUpdate(SELF::SERVICE_SAVE_SQL, $service_parem);
            $check = [
                'is_added' => $service_add,
                'is_update' => false
            ];
        } else {
            $service_parem['service_id'] = $service_details['service_id'];
            $service_parem['updated_date'] = date("Y-m-d H:i:s");
            $service_parem['updated_by']   = $this->SessionManager->get('admin_user')->Id;

            $service_update = $this->performDBUpdate(SELF::SERVICE_UPDATE_SQL, $service_parem);
            $check = [
                'is_added' => false,
                'is_updated' => $service_update
            ];
        }


        return $check;
    }

    public function DeleteCategary($categary_id)
    {

        $delete_categary = $this->performDBUpdate(SELF::DELETE_CATEGARY_SQL, ['categary_id' => $categary_id]);

        return $delete_categary;
    }

    public function DeleteService($service_id)
    {

        $delete_service = $this->performDBUpdate(SELF::DELETE_SERVICE_SQL, ['service_id' => $service_id]);

        return $delete_service;
    }

    public function DeleteUser($user_id)
    {

        $delete_user = $this->performDBUpdate(SELF::DELETE_USER_SQL, ['user_id' => $user_id]);

        return $delete_user;
    }

    public function CreateSloat($sloat_details)
    {
        $salon_id = $this->SessionManager->get('admin_user')->SalonId;
        /* delete past slot */
        $today_date = date('Y-m-d');
        $select_sql = "SELECT * FROM sloat_master WHERE salon_id=:salon_id";
        $select_slot = $this->executeSQL($select_sql, ['salon_id' => $salon_id]);

        if (!is_null($select_slot) && !empty($select_slot)) {
            if ($select_slot[0]['sloat_date'] < $today_date) {
                $delete_sql = "DELETE FROM sloat_master WHERE sloat_date=:sloat_date AND salon_id=:salon_id AND specialist_id=:specialist_id";
                $delete_param = [
                    'sloat_date' => $select_slot[0]['sloat_date'],
                    'salon_id'   => $salon_id,
                    'specialist_id' => $this->SessionManager->get('admin_user')->Id
                ];
                $this->performDBUpdate($delete_sql, $delete_param);
            }
        }
        $check = [
            'is_added' => false,
            'is_update' => false,
            'is_exist'  => false
        ];

        $sloat_parem = [

            'sloat_date'        => $sloat_details['sloat_date'],
            'sloat_start_time'  => $sloat_details['start_time'],
            'sloat_end_time'    => $sloat_details['end_time'],
            'sloat_duration'    => $sloat_details['sloat_duration'],
            'specialist_id'     => $this->SessionManager->get('admin_user')->Id,
            'salon_id'          => $salon_id,
            'is_active'         => $sloat_details['status'],


        ];
        if ($sloat_details['sloat_id'] == 0) {
            $check_isExist_sql = "SELECT * FROM sloat_master WHERE sloat_date=:sloat_date AND specialist_id=:specialist_id";
            $check_isExist = $this->executeSQL($check_isExist_sql, ['sloat_date' => $sloat_details['sloat_date'], 'specialist_id' => $this->SessionManager->get('admin_user')->Id]);
            if (!is_null($check_isExist) && !empty($check_isExist)) {
                $check = [
                    'is_added' => false,
                    'is_update' => false,
                    'is_exist'  => true
                ];
            } else {
                $start = new DateTime($sloat_details['start_time']);
                $end = new DateTime($sloat_details['end_time']);
                $duration = $sloat_details['sloat_duration'];
                $start_time = $start->format('H:i');
                $end_time = $end->format('H:i');
                $i = 0;
                while (strtotime($start_time) <= strtotime($end_time)) {
                    $start = $start_time;
                    $end = date('H:i', strtotime('+' . $duration . ' minutes', strtotime($start_time)));
                    $start_time = date('H:i', strtotime('+' . $duration . ' minutes', strtotime($start_time)));
                    $i++;
                    if (strtotime($start_time) <= strtotime($end_time)) {

                        $sloat_add = $this->performDBUpdate(SELF::SLOAT_SAVE_SQL, [
                            'sloat_date'        => $sloat_details['sloat_date'],
                            'sloat_start_time'  => $start,
                            'sloat_end_time'    => $end,
                            'sloat_duration'    => $sloat_details['sloat_duration'],
                            'specialist_id'     => $this->SessionManager->get('admin_user')->Id,
                            'salon_id'          => $salon_id,
                            'is_active'         => $sloat_details['status'],
                        ]);
                    }
                }
                // $sloat_add = $this->performDBUpdate(SELF::SLOAT_SAVE_SQL, $sloat_parem);
                $check = [
                    'is_added' => $sloat_add,
                    'is_update' => false,
                    'is_exist'  => false
                ];
            }
        } else {

            $sloat_parem_update = [
                'sloat_id'    => $sloat_details['sloat_id'],
                'is_active'   => $sloat_details['status'],
            ];

            $sloat_update = $this->performDBUpdate(SELF::SLOAT_UPDATE_SQL, $sloat_parem_update);

            $check = [
                'is_added' => false,
                'is_update' => $sloat_update,
                'is_exist'  => false
            ];
        }


        return $check;
    }
    public function SaveNewUser($userDetails)
    {

        global $userDetail;

        $response = [
            'is_added' => false,
            'is_updeted' => false
        ];
        $user_perams = [

            'name' => $userDetails['name'],
            'user_name' => $userDetails['user_name'],
            'mobile_no' => $userDetails['mobile'],
            'user_role' => $userDetails['role_name'],
            'salon_id' => $userDetail->SalonId,
            'status'    => $userDetails['status'],

        ];

        $user_add_sql = "INSERT INTO `user_master`(`name`, `user_name`, `password`, `mobile_no`, `role_id`, `salon_id`,`created_by`, `status`) 
                        VALUES (:name,:user_name,:password,:mobile_no,:user_role,:salon_id,:created_by,:status)";
        $user_update_sql = "UPDATE `user_master` SET `name`=:name,`user_name`=:user_name,`password`=:password,mobile_no=:mobile_no,`role_id`=:user_role,`salon_id`=:salon_id,`status`=:status WHERE user_id=:user_id";

        $user_update_without_password_sql = "UPDATE `user_master` SET `name`=:name,`user_name`=:user_name,mobile_no=:mobile_no,`role_id`=:user_role,`salon_id`=:salon_id,`status`=:status WHERE user_id=:user_id";
        if ($userDetails['user_id'] == 0) {
            $user_perams['password'] = password_hash($userDetails['password'], PASSWORD_DEFAULT);
            $user_perams['created_by'] = $userDetail->Id;
            $add_user = $this->performDBUpdate($user_add_sql, $user_perams);

            $response = [
                'is_added' => $add_user,
                'is_updeted' => false
            ];
        } else {
            $user_perams['user_id'] = $userDetails['user_id'];

            if (!empty($userDetails['password'])) {
                $user_perams['password'] = password_hash($userDetails['password'], PASSWORD_DEFAULT);
                $update_user = $this->performDBUpdate($user_update_sql, $user_perams);
            } else {
                $update_user = $this->performDBUpdate($user_update_without_password_sql, $user_perams);
            }
            $response = [
                'is_added' => false,
                'is_updeted' => $update_user
            ];
        }

        return $response;
    }
    public function SaveRole($RoleDetails)
    {
        global $userDetail;

        $response = [
            'is_added' => false,
            'is_updeted' => false
        ];
        $role_perams = [
            'role_name' => $RoleDetails['roleName'],
            'salon_id' => $userDetail->SalonId,
            // 'is_super' => $RoleDetails['isSuper']
        ];

        $role_add_sql = "INSERT INTO `role_master`(`role_name`, `salon_id`, `created_by`) VALUES (:role_name,:salon_id,:logged_id)";
        $role_update_sql = "UPDATE `role_master` SET `role_name`=:role_name,`salon_id`=:salon_id WHERE role_id=:role_id";
        if ($RoleDetails['role_id'] == 0) {
            $role_perams['logged_id'] = $userDetail->Id;
            $add_role = $this->performDBUpdate($role_add_sql, $role_perams);

            $response = [

                'is_added' => $add_role,
                'is_updeted' => false
            ];
        } else {
            $role_perams['role_id'] = $RoleDetails['role_id'];
            $update_role = $this->performDBUpdate($role_update_sql, $role_perams);
            $response = [
                'is_added' => false,
                'is_updeted' => $update_role
            ];
        }
        return $response;
    }

    public function saveRolePermission($role_permission_data)
    {

        $role_permission = implode(",", $role_permission_data['role_permissions']);
        $permission_sql  = 'UPDATE role_master SET permissions=:role_permission WHERE role_id=:role_id';
        $permission_perams = [
            'role_permission' => $role_permission,
            'role_id'         => $role_permission_data['role_id']
        ];

        $permission_done = $this->performDBUpdate($permission_sql, $permission_perams);

        return $permission_done;
    }

    public function Accept_Booking($booking_no)
    {
        $accept_booking_sql = "UPDATE booking_master SET booking_status=:booking_status WHERE booking_no=:booking_no";
        $accept_booking = $this->performDBUpdate(
            $accept_booking_sql,
            [
                'booking_status'  => 'Confirm',
                'booking_no'      => $booking_no
            ]
        );
        $sql = "SELECT * FROM booking_master as bm INNER JOIN customer_master as cm ON bm.customer_id=cm.customer_id WHERE bm.booking_no =:booking_no GROUP BY booking_no";
        $get_email = $this->executeSQL($sql,['booking_no' => $booking_no],true);

        EmailNotifier::sendConfirmBooking($get_email['email_id']);
        return $accept_booking;
    }

    public function Cancel_Booking($booking_id)
    {
        $accept_booking_sql = "UPDATE booking_master SET booking_status=:booking_status WHERE booking_id=:booking_id";
        $accept_booking = $this->performDBUpdate(
            $accept_booking_sql,
            [
                'booking_status'  => 'Reject',
                'booking_id'      => $booking_id
            ]
        );

        return $accept_booking;
    }

    public function Salon_status_change($status)
    {
        $open_or_close = (($status=='true')? 1 : 0);
       
        $change_salon_status = $this->performDBUpdate(
            SELF::SALON_OPEN_CLOSE,
            [
                'is_open_close'  => $open_or_close,
                'salon_id'      => $this->SessionManager->get('admin_user')->SalonId
            ]
        );

        return $change_salon_status;
    }
}
