<?php

namespace MasterService;

require_once __DIR__ . '/../utils/CoreDataService.php';
require_once __DIR__ . '/../utils/SessionManager.php';
require_once __DIR__ . '/../libraries/collection/Collection.php';

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\SessionManager;
use PHPR\Collection;

class MasterService extends CoreDataService
{
    const USER_ROLE_LIST_SQL    = "SELECT role_id,role_name FROM role_master WHERE salon_id:=salon_id ORDER BY role_name ASC";

    public function __construct()
    {
        parent::__construct();
        $this->SessionManager = new SessionManager;
    }

    public function GetAppointment($status)
    {
        $appointment_sql = "SELECT bm.booking_id,bm.booking_no,DATE_FORMAT(bm.sloat_date, '%b %D %Y') as sloat_date,DATE_FORMAT(bm.sloat_time, '%h:%i %p') as sloat_time,cm.customer_name,cm.mobile_no as customer_contect,um.name,bm.payment_type,bm.booking_status,sm.service_name,sm.price,slm.saloon_name,slm.is_open_close FROM booking_master as bm INNER JOIN user_master as um ON bm.specialist_id=um.user_id INNER JOIN service_master as sm ON bm.service_id=sm.service_id INNER JOIN customer_master as cm ON bm.customer_id=cm.customer_id INNER JOIN salon_master as slm ON bm.salon_id=slm.salon_id WHERE bm.booking_status=:booking_status AND bm.salon_id=:salon_id GROUP BY bm.booking_no";
        $appointments = $this->executeSQL($appointment_sql, ['booking_status' => $status,'salon_id' => $this->SessionManager->get('admin_user')->SalonId]);
        return $appointments;
    }
    public function GetCategoryList()
    {

        $category_list_sql = "SELECT  @a:=@a+1 sr_no,category_id,category_name,img_path,status FROM `category_master`,(SELECT @a:= 0) AS a WHERE salon_id=:salon_id AND status=:status";
        $category_list_details = $this->executeSQL($category_list_sql, ['salon_id' => $this->SessionManager->get('admin_user')->SalonId, 'status' => '1']);

        return $category_list_details;
    }
    public function getCategoryById($category_id)
    {
        $category_by_id_sql = "SELECT * FROM `category_master` WHERE category_id=:category_id AND salon_id=:salon_id";
        $category = $this->executeSQL(
            $category_by_id_sql,
            [
                'category_id' => $category_id,
                'salon_id' => $this->SessionManager->get('admin_user')->SalonId
            ],
            true
        );

        return $category;
    }
    public function GetServiceList()
    {

        $category_list_sql = "SELECT  @a:=@a+1 sr_no,service_id,category_id,service_name,price,img_path,description,salon_id,status FROM `service_master`,(SELECT @a:= 0) AS a WHERE salon_id=:salon_id";
        $category_list_details = $this->executeSQL($category_list_sql, ['salon_id' => $this->SessionManager->get('admin_user')->SalonId]);

        return $category_list_details;
    }
    public function getServiceById($service_id)
    {
        $service_by_id_sql = "SELECT * FROM `service_master` WHERE service_id=:service_id AND salon_id=:salon_id";
        $service = $this->executeSQL(
            $service_by_id_sql,
            [
                'service_id' => $service_id,
                'salon_id' => $this->SessionManager->get('admin_user')->SalonId
            ],
            true
        );

        return $service;
    }

    public function getSloatById($sloat_id)
    {
        $sloat_list_sql = "SELECT  @a:=@a+1 sr_no,sm.sloat_id,sm.sloat_date,sm.sloat_start_time,sm.sloat_end_time, sloat_duration,CONCAT(um.name) as specialist_name,sm.is_active FROM `sloat_master` as sm INNER JOIN user_master as um ON sm.specialist_id=um.user_id,(SELECT @a:= 0) as a WHERE sm.sloat_id=:sloat_id AND sm.salon_id=:salon_id;";
        $sloat_list_details = $this->executeSQL(
                    $sloat_list_sql, 
                    [
                        'sloat_id' => $sloat_id, 
                        'salon_id' => $this->SessionManager->get('admin_user')->SalonId
                    ],true
        );

        return $sloat_list_details;
    }

    public function GetSloatList()
    {
        $salon_id = $this->SessionManager->get('admin_user')->SalonId;
        /* delete past slot */
        $today_date = date('Y-m-d');
        $select_sql = "SELECT * FROM sloat_master WHERE salon_id=:salon_id";
        $select_slot = $this->executeSQL($select_sql, ['salon_id' => $salon_id]);

        if (!is_null($select_slot) && !empty($select_slot)) {
            if ($select_slot[0]['sloat_date'] < $today_date) {
                $delete_sql = "DELETE FROM sloat_master WHERE sloat_date=:sloat_date AND salon_id=:salon_id AND specialist_id=:specialist_id";
                $delete_param = [
                    'sloat_date' => $select_slot[0]['sloat_date'],
                    'salon_id'   => $salon_id,
                    'specialist_id' => $this->SessionManager->get('admin_user')->Id
                ];
                $this->performDBUpdate($delete_sql, $delete_param);
            }
        }
        $sloat_list_sql = "SELECT  @a:=@a+1 sr_no,sm.sloat_id,DATE_FORMAT(sm.sloat_date, '%b %D %Y') as sloat_date,DATE_FORMAT(sm.sloat_start_time, '%h:%i %p') as sloat_start_time,DATE_FORMAT(sm.sloat_end_time, '%h:%i %p') as sloat_end_time,CONCAT(sm.sloat_duration,' ','Minute') as sloat_duration,CONCAT(um.name) as specialist_name,sm.is_active FROM `sloat_master` as sm INNER JOIN user_master as um ON sm.specialist_id=um.user_id,(SELECT @a:= 0) as a WHERE sm.salon_id=:salon_id;";
        $sloat_list_details = $this->executeSQL($sloat_list_sql, ['salon_id' => $this->SessionManager->get('admin_user')->SalonId]);

        return $sloat_list_details;
    }
    public function GetUserList(){

        $user_list_sql = "SELECT  @a:=@a+1 sr_no,um.user_id,um.name,um.user_name,um.password,um.mobile_no,um.role_id,um.salon_id,um.status,rm.role_name FROM `user_master` as um,`role_master` as rm,(SELECT @a:= 0) AS a WHERE um.role_id=rm.role_id AND um.salon_id=:salon_id";
        $user_list = $this->executeSQL($user_list_sql, ['salon_id' => $this->SessionManager->get('admin_user')->SalonId]);

        return $user_list;
    }

    public function getUserById($user_id)
    {
        $user_list_sql = "SELECT  @a:=@a+1 sr_no,um.user_id,um.name,um.user_name,um.password,um.mobile_no,um.role_id,um.salon_id,um.status,rm.role_name FROM `user_master` as um,`role_master` as rm,(SELECT @a:= 0) AS a WHERE um.role_id=rm.role_id AND um.user_id=:user_id AND um.salon_id=:salon_id";
        $user_list_details = $this->executeSQL(
                    $user_list_sql, 
                    [
                        'user_id' => $user_id, 
                        'salon_id' => $this->SessionManager->get('admin_user')->SalonId
                    ],true
        );

        return $user_list_details;
    }
    public function getRoleList()
    {
        $role_list_sql = "SELECT  @a:=@a+1 sr_no,role_id,role_name FROM role_master,(SELECT @a:= 0) AS a WHERE salon_id=:salon_id AND status=:status";
        $role_list = $this->executeSQL($role_list_sql,['salon_id' => $this->SessionManager->get('admin_user')->SalonId,'status' => 1]);

        return $role_list;
    }
    public function getRoleById($role_id)
    {
        $role_by_id_sql = "SELECT * FROM `role_master` WHERE role_id =:role_id AND salon_id=:salon_id";
        $role_by_id_perams = [
            'role_id' => $role_id,
            'salon_id' => $this->SessionManager->get('admin_user')->SalonId
        ];
        $role = $this->executeSQL($role_by_id_sql, $role_by_id_perams, true);
        if (is_null($role) || empty($role)) {
            $role = new Collection([]);
        }
        return $role;
    }
    public function getGroupPermission()
    {
        $group_permission_sql = "SELECT DISTINCT(group_name) AS group_name FROM permissions";
        $group_permission = $this->executeSQL($group_permission_sql);

        return $group_permission;
    }
    public function getPermissions()
    {
        $permission_list_sql = 'SELECT id, permission_name,permission_for,group_name FROM permissions ORDER BY id ';
        $permission_list = $this->executeSQL($permission_list_sql);
        if (is_null($permission_list) || empty($permission_list)) {
            $permission_list = new Collection([]);
        }
        return $permission_list;
    }

    public function getBookingDetails($booking_id){

        $get_booking_details_sql = "SELECT * FROM booking_master as bm INNER JOIN service_master as sm ON bm.service_id=sm.service_id INNER JOIN salon_master as slm ON bm.salon_id=slm.salon_id WHERE bm.booking_no=:booking_id";
        $get_booking_details = $this->executeSQL($get_booking_details_sql,[
            'booking_id' => $booking_id,
        ]);

        return $get_booking_details;

    }
    
}
