<?php

require_once __DIR__ . '/../utils/Validator.php';
require_once __DIR__ . '/../libraries/collection/Collection.php';
require_once __DIR__ . '/../utils/Response.php';
require_once __DIR__ . '/MasterCommand.php';
require_once __DIR__ . '/MasterService.php';

use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use MasterCommand\MasterCommand;
use MasterService\MasterService;

$collection   = new Collection([]);
$MasterCommand = new MasterCommand();
$MasterService = new MasterService();

$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

      $category_data=$MasterService->getCategoryById($category_id);
      
}


// POST request block

if ($_SERVER['REQUEST_METHOD'] == "POST") {

      
      $rules = [

            'category_name' => ['required'],

      ];

      $validator = Validator::makeValidator($_POST, $rules, true);


      if ($validator->isValidationFailed()) {
            $error_collection = new Collection($validator->getErrorMessages());
            $error_collection->set("message_tittle", "Please correct below errors");
            echo Response::generateJSONResponse(400, 'Required all fields', $error_collection->values());
            exit;
      }



      $check = $MasterCommand->SaveCategory($_POST);

      if ($check['is_added']) {
            echo Response::generateJSONResponse(200, 'Category succesfully saved.', ['is_added' => $check['is_added']]);
            exit;
      } else if ($check['is_updated']) {
            echo Response::generateJSONResponse(200, 'Category succesfully Updated.', ['is_updated' => $check['is_updated']]);
            exit;
      }
      $collection = new Collection([]);
      $collection->set("message_tittle", "Category is not saved.", "");
      echo Response::generateJSONResponse(500, 'Unable to saved Category due to some reasons', $collection->values());
      exit;
}
