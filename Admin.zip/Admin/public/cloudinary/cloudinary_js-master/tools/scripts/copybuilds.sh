for pkg in core jquery jquery-file-upload; do pkg/copy_deployment ${pkg}; done
