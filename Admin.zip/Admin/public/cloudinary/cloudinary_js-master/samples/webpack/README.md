# Webpack sample

This example demonstrate the use of the Cloudinary JavaScript library in webpack.

## Instructions
1. Install webpack
    ```
    npm install -g webpack
    ```
1. Install dependencies
   ```
   npm install
   ```
2. Compile bundle
    ```
    webpack
    ```

3. Open `index.html` in your browser
