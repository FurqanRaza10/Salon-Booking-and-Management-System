<?php
\Cloudinary::config(array( 
  "cloud_name" => "hschaudhary", 
  "api_key" => "289984554998812", 
  "api_secret" => "q0_80rbtDs7Lh8GWjjIaNWN-tTQ", 
  "secure" => true
));

$CloudinaryPath = "https://res.cloudinary.com/hschaudhary/image/upload/v1644314667/";
define("folder_dir","Saloon Booking/");

?>