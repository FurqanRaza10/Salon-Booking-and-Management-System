function getPendingAppointment() {
    var url = `${appname}/application/master/master_action_handler.php?action=getAppointment&status=Pending`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var appointment_details = result.responseContent.appointment_data;
        var appointment_div = '';
        if (appointment_details != "") {

            for (let appointment_data of appointment_details) {
                appointment_div += `<tr class="text-center">
                                    <td>#${appointment_data.booking_no}</td>
                                    <td class="wspace-no">${appointment_data.sloat_date} ${appointment_data.sloat_time}</td>
                                    <td class="wspace-no">
                                        <span class="fs-16">
                                            ${appointment_data.customer_name}
                                        </span>
                                    </td>
                                    <td><span class="text-secoundry fs-14 font-w600">
                                            <i class="fas fa-phone-alt me-2"></i>
                                            ${appointment_data.customer_contect}
                                        </span></td>
                                    <td>${appointment_data.name}</td>

                                    <td><span class="btn btn-warning  btn-sm btn-rounded">${appointment_data.booking_status}</span></td>
                                    <td class="action-btn wspace-no">
											<span>
												<a href="javascript:void(0);" onclick="accept_booking(${appointment_data.booking_no})"><i class="fas fa-check text-success"></i>&nbspAccept</a>
											</span>
											<span>
												<a href="javascript:void(0);" onclick="cancel_booking(${appointment_data.booking_id})"><i class="fas fa-times text-danger"></i>&nbspReject</a>
											</span>
                                            <span>
												<a href="${appname}/view/master/booking_details.php?booking_id=${appointment_data.booking_no}" data-bs-toggle="modal" data-bs-target="#basicModal"><i class="fas fa-eye"></i></a>
											</span>
										</td>
                                </tr>`;
            }
            if (appointment_details[0].is_open_close == 1)
                $('#btn').prop('checked', true);
            else
                $('#btn').prop('checked', false);
            
            

        }
        else {
            appointment_div = `<tr><td colspan="8" class="text-center"><span class="text-secoundry fs-18 font-w600">No Result Found</span></td></tr>`;
        }
        $('#appointment_pending').html(appointment_div);
    })
}

/* get confirm appointment */

function getConfirmAppointment() {
    var url = `${appname}/application/master/master_action_handler.php?action=getAppointment&status=Confirm`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var appointment_details = result.responseContent.appointment_data;
        var appointment_div = '';
        if (appointment_details != "") {
            for (let appointment_data of appointment_details) {
                appointment_div += `<tr class="text-center">
                                    <td>#${appointment_data.booking_no}</td>
                                    <td class="wspace-no">${appointment_data.sloat_date} ${appointment_data.sloat_time}</td>
                                    <td class="wspace-no">
                                        <span class="fs-16">
                                            ${appointment_data.customer_name}
                                        </span>
                                    </td>
                                    <td><span class="text-secoundry fs-14 font-w600">
                                            <i class="fas fa-phone-alt me-2"></i>
                                            ${appointment_data.customer_contect}
                                        </span></td>
                                    <td>${appointment_data.name}</td>

                                    <td><span class="btn btn-success  btn-sm btn-rounded">${appointment_data.booking_status}</span></td>
                                    <td class="action-btn wspace-no">
                                            <span>
												<a href="${appname}/view/master/booking_details.php?booking_id=${appointment_data.booking_no}" data-bs-toggle="modal" data-bs-target="#basicModal"><i class="fas fa-eye"></i></a>
											</span>
										</td>
                                    </tr>`;
            }
            if (appointment_details[0].is_open_close == 1)
                $('#btn').prop('checked', true);
            else
                $('#btn').prop('checked', false);
            
        }
        else {
            appointment_div = `<tr><td colspan="7" class="text-center"><span class="text-secoundry fs-18 font-w600">No Result Found</span></td></tr>`;
        }
        $('#appointment_success').html(appointment_div);
    })
}

function getCancelAppointment() {
    var url = `${appname}/application/master/master_action_handler.php?action=getAppointment&status=Reject`;
    $.get(url, function (data) {
        var result = JSON.parse(data);
        var appointment_details = result.responseContent.appointment_data;
        var appointment_div = '';
        if (appointment_details != "") {

            for (let appointment_data of appointment_details) {
                appointment_div += `<tr class="text-center">
                                    <td>#${appointment_data.booking_no}</td>
                                    <td class="wspace-no">${appointment_data.sloat_date} ${appointment_data.sloat_time}</td>
                                    <td class="wspace-no">
                                        <span class="fs-16">
                                            ${appointment_data.customer_name}
                                        </span>
                                    </td>
                                    <td><span class="text-secoundry fs-14 font-w600">
                                            <i class="fas fa-phone-alt me-2"></i>
                                            ${appointment_data.customer_contect}
                                        </span></td>
                                    <td>${appointment_data.name}</td>

                                    <td><span class="btn btn-danger  btn-sm btn-rounded">${appointment_data.booking_status}</span></td>
                                    <td class="action-btn wspace-no">
											
                                            <span>
												<a href="${appname}/view/master/booking_details.php?booking_id=${appointment_data.booking_no}" data-bs-toggle="modal" data-bs-target="#basicModal"><i class="fas fa-eye"></i></a>
											</span>
										</td>
                                    </tr>`;
            }
            if (appointment_details[0].is_open_close == 1)
                $('#btn').prop('checked', true);
            else
                $('#btn').prop('checked', false);
            
        }
        else {
            appointment_div = `<tr><td colspan="7" class="text-center"><span class="text-secoundry fs-18 font-w600">No Result Found</span></td></tr>`;
        }
        $('#appointment_cancel').html(appointment_div);
    })
}

/* salon status change */

function salonStatus(value,event){

    var checkbox = document.getElementById("btn");
    var status;
    // Check if it is checked
    if (checkbox.checked)
        status = true;
    else
        status = false;

    var url = `${appname}/application/master/master_action_handler.php`;
    $.post(url, {
        action: "Salon_status_change",
        status: status
    }, function(data) {

    });
    
}