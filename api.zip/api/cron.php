<?php
date_default_timezone_set('Australia/NSW');
$timestamp = date("Y-m-d H:i:s");

include_once __DIR__.'/class/app_config.php';
include_once __DIR__.'/class/Validator.php';
include_once __DIR__.'/class/Response.php';
include_once __DIR__.'/class/ApiCommand.php';
include_once __DIR__.'/class/ApiService.php';
include_once __DIR__.'/lib/collection/Collection.php';
include_once __DIR__.'/class/CoreDataService.php';
include_once __DIR__.'/class/PushNotification.php';
include_once __DIR__.'/class/EmailNotifier.php';

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use Inspire\Api\ApiCommand;
use Inspire\Api\ApiService;
use Inspire\Ahms\Application\Utils\Notification\EmailNotifier;


$error_messages = new Collection([]);
$apiCommand = new ApiCommand();
$apiService = new ApiService();
$coreDataService = new CoreDataService();

//EmailNotifier::sendOtpEmail('bhoraniyaakbarali@gmail.com',123456);

function getPriceByItemId($item_id){

	$coreDataService = new CoreDataService();
	$item_sql = 'SELECT Price_Text,ItemName_Text,OfferPrice_Text as OfferPrice,PromotionStartDate,PromotionEndDate,IsPromotion 
	    FROM item_master 
	    WHERE ItemNo=:item_id';
    $item = $coreDataService->executeSQL($item_sql,['item_id' => $item_id],true);
     
    if(!is_null($item) || !empty($item)){
      return $item;
    }
    return 0;
}
function getFirbaseTokenByUserId($user_id){
	$coreDataService = new CoreDataService();
	$user_sql = 'SELECT DeviceFirebaseToken FROM customer WHERE CustomerNo=:user_id';
    $user = $coreDataService->executeSQL($user_sql,['user_id' => $user_id],true);
     
    if(!is_null($user) || !empty($user)){
      return $user;
    }
    return 0;
}
function deletePushNotificationDetailItem($id)
{	
	$coreDataService = new CoreDataService();
	$is_notification_sql ="DELETE FROM notification_detail WHERE id=".$id;
	$coreDataService->performDBUpdate($is_notification_sql,[]);
	return true;
}
function getStockDetailByItemId($item_id){
	$coreDataService = new CoreDataService();
	$item_sql = 'SELECT ItemName_Text,ItemNo,IsOutOfStock FROM item_master WHERE ItemNo=:item_id';
    $item = $coreDataService->executeSQL($item_sql,['item_id' => $item_id],true);
     
    if(!is_null($item) || !empty($item)){
      return $item;
    }
    return 0;
}
function getCustomerByUserId($user_id){
	$coreDataService = new CoreDataService();
	$user_sql = 'SELECT * FROM customer WHERE CustomerNo=:user_id';
    $user = $coreDataService->executeSQL($user_sql,['user_id' => $user_id],true);
     
    if(!is_null($user) || !empty($user)){
      return $user;
    }
    return 0;
}

// -================START push notification for price change =====================//
$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform !=:platform';
$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Price",'platform'=>'Web']);

if(!is_null($notification_list) || !empty($notification_list)){
	foreach ($notification_list as $key => $value) {
		$item_detail =  getPriceByItemId($value['Product_id']);
		$price = $item_detail['Price_Text'];
		$item_name = $item_detail['ItemName_Text'];
		
		if($price > $value['Item_Price'] || $price < $value['Item_Price']){
			$user_detail  = getFirbaseTokenByUserId($value['User_Id']);

			if(isset($user_detail['DeviceFirebaseToken'])){
				if($user_detail['DeviceFirebaseToken'] != '')
				{
					$device_token = $user_detail['DeviceFirebaseToken'];
					$is_notified =  PushNotification($value['Platform'],$device_token,"Item Price Update",$item_name." Price Change is : ".$price);

					if($is_notified == true){
						deletePushNotificationDetailItem($value['id']);
					}
				}
			}
		}
	}
}
// -================ END push notification for Price Change =====================//

// -================START push notification for Stock Available =====================//
$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform !=:platform';
$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Stock",'platform'=>'Web']);

if(!is_null($notification_list) || !empty($notification_list)){
	foreach ($notification_list as $key => $value) {
		$stock = getStockDetailByItemId($value['Product_id']);
		$is_out_of_stock = $stock['IsOutOfStock'];
		$item_name 		 = $stock['ItemName_Text'];
		if($is_out_of_stock == 0)
		{
			$user_detail  = getFirbaseTokenByUserId($value['User_Id']);
			if(isset($user_detail['DeviceFirebaseToken'])){
				if($user_detail['DeviceFirebaseToken'] != '')
				{
					$device_token = $user_detail['DeviceFirebaseToken'];
					$is_notified =  PushNotification($value['Platform'],$device_token,"Item Stock Available ",$item_name." is available.");
					if($is_notified == true){
						deletePushNotificationDetailItem($value['id']);
					}
				}
			}
		}
	}
}
// -================ END push notification for Stock Available =====================//   

// -================START push notification for Promotion Price Change =====================//


	$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform !=:platform';
	$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Promotion",'platform'=>'Web']);

	if(!is_null($notification_list) || !empty($notification_list))
	{
		foreach ($notification_list as $key => $value) 
		{
			$item_detail 			=  getPriceByItemId($value['Product_id']);
			$price 		 			= $item_detail['Price_Text'];
			$item_name   			= $item_detail['ItemName_Text'];
			$promotion_start_date   = $item_detail['PromotionStartDate'];
			$promotion_end_date   	= $item_detail['PromotionEndDate'];
			$offer_price   			= $item_detail['OfferPrice'];
			
			 if($offer_price > $value['Item_Price'] || $offer_price < $value['Item_Price'])
			  {
	            	$user_detail  = getFirbaseTokenByUserId($value['User_Id']);
					if(isset($user_detail['DeviceFirebaseToken'])){
						if($user_detail['DeviceFirebaseToken'] != ''){
							$device_token = $user_detail['DeviceFirebaseToken'];
							$is_notified =  PushNotification($value['Platform'],$device_token,"Item Price Update",$item_name." Price Change is : ".$offer_price);
							if($is_notified == true){
								deletePushNotificationDetailItem($value['id']);
							}
						}
					}
              } 
		}
	}


// -================ END push notification for Promotion Price Change =====================// 

// -================START EMAIL OR SMS (WEB) notification for Promotion Price Change =====================//
	

	$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform =:platform';
	$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Promotion",'platform'=>'Web']);
	
	if(!is_null($notification_list) || !empty($notification_list))
	{
		foreach ($notification_list as $key => $value) 
		{
          
			$item_detail 			=  getPriceByItemId($value['Product_id']);
			$price 		 			= $item_detail['Price_Text'];
			$item_name   			= $item_detail['ItemName_Text'];
			$promotion_start_date   = $item_detail['PromotionStartDate'];
			$promotion_end_date   	= $item_detail['PromotionEndDate'];
			$offer_price   			= $item_detail['OfferPrice'];
			
    		if($offer_price > $value['Item_Price'] || $offer_price < $value['Item_Price'])
    		{
            	$user_detail  = getCustomerByUserId($value['User_Id']);
               
				if(isset($user_detail['Email']))
                {
					if($user_detail['Email'] != '' || $user_detail['Email'] != NULL)
                    {
                      	
						$message = $item_name." Item Price Change is : ".$offer_price;
						$email =  $user_detail['Email'];
						EmailNotifier::sendNotificationEmail($email,$message);
						deletePushNotificationDetailItem($value['id']);
                      	//echo '<pre>';print_r($user_detail);die();
					}
				}
				if(isset($user_detail['MobileNo']))
                {
					if($user_detail['MobileNo'] != '' || $user_detail['MobileNo'] != NULL)
                    {
						$message = $item_name." Item Price Change is : ".$offer_price;
						$mobile = ltrim($user_detail['MobileNo'], "+61");
						$mobile = ltrim($mobile, "0");
						SMSNotifier::sendOwnerSMS($mobile,$message);
						deletePushNotificationDetailItem($value['id']);
					}
				}
            }
		}
	}

// -================ END EMAIL OR SMS (WEB) notification for Promotion Price Change =====================// 

// -================START EMAIL OR SMS (WEB) notification for Stock Available =====================//
$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform =:platform';
$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Stock",'platform'=>'Web']);

if(!is_null($notification_list) || !empty($notification_list)){
	foreach ($notification_list as $key => $value) {
		$stock = getStockDetailByItemId($value['Product_id']);
		$is_out_of_stock = $stock['IsOutOfStock'];
		$item_name 		 = $stock['ItemName_Text'];
		if($is_out_of_stock == 0)
		{
		    $user_detail  = getCustomerByUserId($value['User_Id']);
			if(isset($user_detail['Email']))
			{
				if($user_detail['Email'] != '' || $user_detail['Email'] != NULL){
					$message = "Item Stock Available ".$item_name." is available";
					$email =  $user_detail['Email'];
					EmailNotifier::sendNotificationEmail($email,$message);
					deletePushNotificationDetailItem($value['id']);
				}
				if(isset($user_detail['MobileNo'])){
					if($user_detail['MobileNo'] != '' || $user_detail['MobileNo'] != NULL){
					    $message = "Item Stock Available ".$item_name." is available";
						$mobile = ltrim($user_detail['MobileNo'], "+61");
						$mobile = ltrim($mobile, "0");
						SMSNotifier::sendOwnerSMS($mobile,$message);
						deletePushNotificationDetailItem($value['id']);
					}
				}
			}
		}
	}
}
// -================ END EMAIL OR SMS (WEB) notification for Stock Available =====================//  

// -================START EMAIL OR SMS (WEB) notification for price change =====================//
$notification_sql = 'SELECT * FROM notification_detail WHERE Type=:Type AND Platform =:platform';
$notification_list = $coreDataService->executeSQL($notification_sql,['Type' => "Price",'platform'=>'Web']);

if(!is_null($notification_list) || !empty($notification_list))
{
	foreach ($notification_list as $key => $value) 
    {
		$item_detail =  getPriceByItemId($value['Product_id']);
		$price = $item_detail['Price_Text'];
		$item_name = $item_detail['ItemName_Text'];
		
		if($price > $value['Item_Price'] || $price < $value['Item_Price'])
        {
			
            $user_detail  = getCustomerByUserId($value['User_Id']);
			if(isset($user_detail['Email']))
			{
				if($user_detail['Email'] != '' || $user_detail['Email'] != NULL){
					$message = $item_name." Item Price Change is : ".$price;
					$email =  $user_detail['Email'];
					EmailNotifier::sendNotificationEmail($email,$message);
					deletePushNotificationDetailItem($value['id']);
				}
				if(isset($user_detail['MobileNo'])){
					if($user_detail['MobileNo'] != '' || $user_detail['MobileNo'] != NULL){
						$message = $item_name." Item Price Change is : ".$price;
						$mobile = ltrim($user_detail['MobileNo'], "+61");
						$mobile = ltrim($mobile, "0");
						SMSNotifier::sendOwnerSMS($mobile,$message);
						deletePushNotificationDetailItem($value['id']);
					}
				}
			}
		}
	}
}


// -================ END EMAIL OR SMS (WEB) notification for Price Change =====================//

$date = date("Y-m-d");
$promotion_sql = "SELECT * FROM item_master WHERE PromotionEndDate < '".$date."' AND IsPromotion=1";
$promotion_list = $coreDataService->executeSQL($promotion_sql,[]);

if(!is_null($promotion_list) || !empty($promotion_list))
{
  	foreach($promotion_list as $value)
    {
        $change_promotion_sql = 'Update item_master SET IsPromotion=:IsPromotion,OfferPrice_Text=:OfferPrice_Text,PromotionStartDate=:PromotionStartDate,PromotionEndDate=:PromotionEndDate WHERE ItemNo=:item_no';
        
      	$coreDataService->performDBUpdate($change_promotion_sql,['IsPromotion'=>0,'OfferPrice_Text'=>'0.00','PromotionStartDate'=>'0000-00-00','PromotionEndDate'=>'0000-00-00','item_no'=>$value["ItemNo"]]);
    }
}

?>