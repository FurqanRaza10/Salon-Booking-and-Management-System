<?php
date_default_timezone_set('Australia/NSW');
$timestamp = date("Y-m-d H:i:s");

header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

include_once __DIR__.'/class/app_config.php';
include_once __DIR__.'/class/Validator.php';
include_once __DIR__.'/class/Response.php';
include_once __DIR__.'/class/ApiCommand_cart.php';
include_once __DIR__.'/class/ApiService_cart.php';
include_once __DIR__.'/lib/collection/Collection.php';
include_once __DIR__.'/class/class_stripe_pay.php';

use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use Inspire\Api\ApiCommand;
use Inspire\Api\ApiService;

$error_messages = new Collection([]);
$apiCommand = new ApiCommand();
$apiService = new ApiService();


$rules = 
[
	'' => ['required'],
];

if(isset($_GET["action"]))
{
	
	
	
	if($_GET["action"] == "confirm_order")
	{
		if(isset($_POST['delivery_type']))
		{
			if($_POST['delivery_type'] == 'Collect'){
				$rules = [
					'user_id'   				=> ['required'],
					'item_details'   			=> ['required'],
					'delivery_type'   			=> ['required'],
					'is_delivery_charge'   		=> ['required'],
					'platform_type'   			=> ['required'],
					'reference_id'   			=> ['required'],
					'online_payment_confirm'   	=> ['required'],
				];
			}else{
				$rules = [
					'address_id'    			=> ['required'],
					'user_id'   				=> ['required'],
					'item_details'   			=> ['required'],
					'delivery_type'   			=> ['required'],
					'is_delivery_charge'   		=> ['required'],
					'platform_type'   			=> ['required'],
					'reference_id'   			=> ['required'],
					'online_payment_confirm'   	=> ['required'],
				];
			}
		}else
		{
			$error_messages->set('message_title','unable to add order');
	        echo Response::generateJSONResponse(500,'unable to add order',[]);
	        exit;
		}
		
		

		$validator_instance = Validator::makeValidator($_POST,$rules,true);
		if($validator_instance->isValidationFailed()){
		    //Preparing collection for error messages
		    $error_messages = new Collection($validator_instance->getErrorMessages());
		    $error_messages->set('message_title','Please correct below errors');
		    echo Response::generateJSONResponse(400,"Unable to add Order due to incorrect data",$error_messages->values());
		    exit;
		}else 
		{
		    $order_response = $apiCommand->confirmOrder($_POST);
		  	if($order_response['is_order_added']){
	          echo Response::generateJSONResponse(200,$order_response['is_order_message'],array("is_order_added" => $order_response['is_order_added'],'Orderid'=>$order_response['Orderid']));
	          exit;
	        }
	        $error_messages->set('message_title',$order_response['is_order_message']);
	        echo Response::generateJSONResponse(500,$order_response['is_order_message'],$error_messages->values());
	        exit;
	       
		   
		}
	}

    else if($_GET["action"] == "online_payment_transaction_confirmation")
	{
		$rules = [
           'order_id'                => ['required'],
           'online_payment_confirm'  => ['required'],
           'pay_transaction_id'      => ['required'],
		];

		$validator_instance = Validator::makeValidator($_POST,$rules,true);
		if($validator_instance->isValidationFailed()){
		    //Preparing collection for error messages
		    $error_messages = new Collection($validator_instance->getErrorMessages());
		    $error_messages->set('message_title','Please correct below errors');
		    echo Response::generateJSONResponse(400,"Unable to update due to incorrect data",$error_messages->values());
		    exit;
		}else 
		{
		    $response = $apiCommand->updateOrderTransaction($_POST);
		  	if(isset($response['is_updated']) && $response['is_updated']){
	          echo Response::generateJSONResponse(200,"Sunrise Fresh has received your order.",[]);
	          exit;
	        }
	        $error_messages->set('message_title','order is not updated.');
	        echo Response::generateJSONResponse(500,"Unable to update order due to incorrect  data",$error_messages->values());
	        exit;
		}
	}
	//[start] change by haidar on 12/09/2021 9:45am
	else if($_GET["action"] == "store_cart" )
	{
      header('Content-Type:application/json');
		if (isset($_GET["sub_action"])) {
			if($_GET["sub_action"] == "add_update_cart" )
			{
				
				$rules = [

					'product_id'	=> ['required'],
					'customer_id'	=> ['required'],
					'quantity'		=> ['required'],

				];
				$validator_instance = Validator::makeValidator($_POST,$rules,true);
				if($validator_instance->isValidationFailed()){
					//Preparing collection for error messages
					$error_messages = new Collection($validator_instance->getErrorMessages());
					$error_messages->set('message_title','Please correct below errors');
					echo Response::generateJSONResponse(400,"Unable to add due to incorrect data",$error_messages->values());
					exit;
				}else 
				{
					$add_response = $apiCommand->addCartItems($_POST);
						
					if($add_response['is_added']){
					echo Response::generateJSONResponse(200,"Product Added To Your Cart.",array('is_added' =>$add_response['is_added']));	
					exit;
					}
					else if($add_response['is_updated']){
						echo Response::generateJSONResponse(200,"Product Updated Successfully.",array('is_updated' =>$add_response['is_updated']));	
						exit;
					}
					else if ($add_response['is_deleted']) {
						echo Response::generateJSONResponse(200,"Product Deleted Successfully.",array('is_deleted' =>$add_response['is_deleted']));	
						exit;	
					}
					else if ($add_response['is_exist']){
						echo Response::generateJSONResponse(500,"In ".$_POST['pincode']." post code, we do not deliver. Sorry!",array("is_exist" => false));
					}
					$error_messages->set('message_title','Unable to add.');
					echo Response::generateJSONResponse(500,"Unable to add due to incorrect  data",$error_messages->values());
					exit;

				}
			}
			else if ($_GET["sub_action"] == "get_cartlist") {
				
				$cart_list = $apiService->getCartList($_GET['customer_id']);
				if(!is_null($cart_list) && !empty($cart_list)){
					echo Response::generateJSONResponse(200,"cart_list",array("CartList" => $cart_list));
					exit;
				}else{
					echo Response::generateJSONResponse(200,"cart_list",array("CartList" => []));
					exit;
				}
			}
			else
			{	
		
				$validator_instance = Validator::makeValidator($_POST,$rules,true);
				$error_messages = new Collection($validator_instance->getErrorMessages());
				$error_messages->set('message_title','Wrong Request');
				echo Response::generateJSONResponse(500,"Wrong Request",$error_messages->values());
				exit;
			}
		
		}

	}
	//[end] change by haidar on 12/09/2021 12:04pm	
    else
    {	
    
        $validator_instance = Validator::makeValidator($_POST,$rules,true);
			$error_messages = new Collection($validator_instance->getErrorMessages());
			$error_messages->set('message_title','Wrong Request');
	          echo Response::generateJSONResponse(500,"Wrong Request",$error_messages->values());
	        exit;
    }
 }

?>