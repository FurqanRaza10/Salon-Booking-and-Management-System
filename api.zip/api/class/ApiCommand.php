<?php

namespace Inspire\Api;

include_once __DIR__ . '/CoreDataService.php';
include_once __DIR__ . '/SMSNotifier.php';
include_once __DIR__ . '/EmailNotifier.php';
include_once __DIR__ . '/PushNotification.php';
include_once __DIR__ . '/PushNotifier.php';

date_default_timezone_set('Australia/NSW');

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Notification\SMSNotifier;
use Inspire\Ahms\Application\Utils\Notification\EmailNotifier;
use Inspire\Ahms\Application\Utils\Notification\PushNotifier;
use stdClass;

/**
 */
class ApiCommand extends CoreDataService
{
	const ADD_SIGNUP_WITH_SOCIAL_SQL = 'INSERT INTO customer(CustomerNo,CustomerName,Email,Token,OtpCode,RegisterBy) VALUES (NULL,:name,:email,:token,:mobile_otp,:type)';

	const ADD_SIGNUP_SQL = 'INSERT INTO `customer_master`(`customer_name`, `mobile_no`, `email_id`, `password`, `otp`, `tokan`) VALUES (:name,:mobile,:email,:password,:mobile_otp,:token)';

	const ADD_SIGNUP_WITH_MOBILE_SQL = 'INSERT INTO customer(CustomerNo,MobileNo,Gender,Token,OtpCode) VALUES (NULL,:mobile,:gender,:token,:mobile_otp)';

	const UPDATE_PROFILE_SQL = 'UPDATE customer SET CustomerName=:name,Email=:email,Gender=:gender,MobileNo=:mobile,Address=:address,BirthDay=:birthday 
		WHERE CustomerNo=:user_id';


	/*
	const ADD_CUSTOMER_ADDRESS_SQL = 'INSERT INTO address_book(AddressId,Name,Address1,Address2,LandMark,Pincode,MobileNo,AddressType,Latitude,Longitude,CustomerNo,DefaultStatus) VALUES (NULL,:name,:address1,:address2,:landmark,:pincode,:mobile_no,:address_type,:user_lat,:user_long,:user_id,1)';*/

	const ADD_CUSTOMER_ADDRESS_SQL = 'INSERT INTO address_book(AddressId,Name,Pincode,Address1,UnitNo,CustomerNo,DefaultStatus,Latitude,Longitude) VALUES (NULL,:apartment,:postcode,:address,:unitno,:user_id,1,:latitude,:longitude)';

	const UPDATE_SET_ADDRESS_SQL = 'UPDATE address_book SET DefaultStatus=:status WHERE CustomerNo=:user_id AND AddressId=:address_id';

	const UPDATE_ADDRESS_SQL = 'UPDATE address_book 
		SET Name=:apartment,Address1=:address,UnitNo=:unitno,Pincode=:postcode,Latitude=:latitude,
		Longitude=:longitude WHERE CustomerNo=:user_id AND AddressId=:address_id';

	const ADD_FAVOURITE_SQL = 'INSERT INTO favourite(SrNo,Item_Id,CustomerNo) VALUES (NULL,:product_id,:user_id)';

	const ADD_ORDER_SQL = 'INSERT INTO order_master(`OrderNo`, `CustomerNo`, `AddressId`, `ItemNo`,`Price`, `Quantity`, `Date`, `OrderId`,`Gst`,`DeliveryCharge`,`Name`,`Address1`,`Pincode`,`AddressType`,`Latitude`,`Longitude`,`MobileNo`,`CouponCode`,`CouponAmount`,`PaymentType`,`DeliveryType`,`PayTransactionId`,`Status`,`RestaurantId`,`RestaurantName`,`RestaurantAddress`,`PlatformType`,`Instruction`,`CN_amount_use`,`ReferenceId`,`OnlinePaymentConfirm`,`Pickup_Slot`,`OrderStatus`) 

	VALUES (NULL,:user_id,:address_id,:item_no,:price,:quantity,:dates,:max_order_id,:gst,:delivery_charge,:name,:address1,:pincode,:address_type,:latitude,:longitude,:mobile_no,:coupon_code,:coupon_amount,:payment_type,:delivery_type,:transaction_id,:status,:restaurant_id,:shop_name,:shop_address,:platform_type,:instruction,:credit_amount_use,:reference_id,:payment_confirm,:pickup_slot,:order_status)'; // change by haidar

	const UPDATE_DEVICE_TOKEN_SQL = 'UPDATE customer SET DeviceFirebaseToken=:device_firebase_token,Platform=:platform WHERE CustomerNo=:user_id';

	const UPDATE_OTP_SQL = 'UPDATE customer SET OtpCode=:otp WHERE CustomerNo=:user_id';

	const ADD_CONTACT_SQL = 'INSERT INTO contact_us_master(CNo,Name,ContactNo,Email,Comment,Platform,Status,Purpose) VALUES (NULL,:name,:contact_number,:email,:comment,:platform,1,:purpose)';

	const ADD_NOTIFICAION_SQL = 'INSERT INTO notification_detail(id,Product_id,User_Id,Type,Item_Price,Platform) VALUES (NULL,:product_id,:user_id,:type,:item_price,:platform)';

	const UPDATE_OTP_EMAIL_SQL = 'UPDATE customer SET OtpCode=:otp WHERE Email=:email_or_mobile';
	const UPDATE_OTP_MOBILE_SQL = 'UPDATE customer SET OtpCode=:otp WHERE MobileNo=:email_or_mobile';

	const ADD_SEARCH_SQL = 'INSERT INTO product_category_search(`ID`, `Date`, `CategoryID`, `ItemID`,`UserID`)
	VALUES (NULL,:dates,:category_id,:item_id,:user_id)';

	const ADD_USER_LOG_SQL = 'INSERT INTO log_master(id,user_id,user_type,platform_type,login_via,device_id,ip_address) VALUES (NULL,:user_id,:user_type,:platform_type,:login_via,:device_id,:ip_address)';

	const UPDATE_ORDER_CONFIRM_SQL = "UPDATE order_master SET OrderStatus=:status,OnlinePaymentConfirm=:online_payment_confirm,PayTransactionId=:pay_transaction_id
                                              WHERE OrderId=:order_id AND OrderStatus='Pending'";
	public function __construct()
	{
		parent::__construct();
	}

	public function addSignup(array $details)
	{

		$response = [
			'is_user_saved'   => false,
			'user_id' 		  => 0,
			'is_email_exist'  => false,
			'otp'			  => 0
		];
		$is_user_saved     = false;
		$user_id 		   = 0;
		$signup_parameters = [];
		$otp 			   = rand(1000, 9999);
		$signup_parameters['name']   	 		= $this->sanitize_xss($details['name']);
		$signup_parameters['mobile']			= $this->sanitize_xss($details['mobile']);
		$signup_parameters['email']			= $this->sanitize_xss($details['email']);
		$signup_parameters['password'] 	        = $this->sanitize_xss(password_hash($details['password'], PASSWORD_BCRYPT));
		$signup_parameters['token']   	        = md5(rand());
		$signup_parameters['mobile_otp']        = $otp;

		$user_detail_sql = "SELECT email_id,customer_id,otp	 FROM customer_master WHERE email_id=:email AND is_verifid=:email_verify";
		$get_user_detail = $this->executeSQL($user_detail_sql, ['email' => $this->sanitize_xss($details['email']), 'email_verify' => 0], true);

		if (!is_null($get_user_detail) && !empty($get_user_detail)) {
			EmailNotifier::sendOtpEmail($this->sanitize_xss($details['email']), $get_user_detail['otp']);

			$this->performDBUpdate(
				"UPDATE customer_master SET customer_name =:customer_name,mobile_no=:mobile,password=:password WHERE customer_id=:customer_id",
				[
					'customer_id' 		=>  $get_user_detail['customer_id'],
					'customer_name'	=>	$this->sanitize_xss($details['name']),
					'mobile'		=>  $this->sanitize_xss($details['mobile']),
					'password'		=>  $this->sanitize_xss(password_hash($details['password'], PASSWORD_BCRYPT))
				]
			);

			$response = [
				'is_user_saved'   => true,
				'user_id' 		  => $get_user_detail['customer_id'],
				'is_email_exist'  => false,
				'otp'			  => $get_user_detail['otp']
			];
			return $response;
		}

		$user_detail_sql = "SELECT email_id,customer_id,otp	 FROM customer_master WHERE email_id=:email AND is_verifid=:email_verify";
		$get_user_detail = $this->executeSQL($user_detail_sql, ['email' => $this->sanitize_xss($details['email']), 'email_verify' => 1], true);

		if (!is_null($get_user_detail) && !empty($get_user_detail)) {
			$response = [
				'is_user_saved'   => false,
				'user_id' 		  => 0,
				'is_email_exist'  => true,
				'otp'			  => 0
			];
			return $response;
		}

		$this->beginTxn();

		$is_user_saved = $this->performDBUpdate(self::ADD_SIGNUP_SQL, $signup_parameters);
		$user_id = $this->getLastInsertedId();
		if ($is_user_saved) {
			$this->commitTxn();
			EmailNotifier::sendOtpEmail($this->sanitize_xss($details['email']), $otp);
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_user_saved'   => $is_user_saved,
			'user_id' 		  => $user_id,
			'is_email_exist'  => false,
			'otp'			  => $otp
		];
		return $response;
	}
	public function login($user_detail)
	{
		$response = [
			'is_login' => false,
		];
		$check_user_sql = "SELECT * FROM customer_master WHERE email_id=:username";
		$check_user = $this->executeSQL($check_user_sql, ['username' => $user_detail['username']], true);
		if (!is_null($check_user) && !empty($check_user)) {
			if (password_verify($user_detail['password'],$check_user['password'])) {
				$response = [
					'is_login' => true,
				];
			}
		}

		return $response;
	}
	public function addSignupWithMobile(array $details)
	{

		$response = [
			'is_user_saved'   => false,
			'user_id' 		  => 0,
			'is_mobile_exist' => false,
			'otp'			  => 0
		];
		$is_user_saved     = false;
		$user_id 		   = 0;
		$signup_parameters = [];
		$otp 			   = rand(1000, 9999);

		$signup_parameters['mobile']  	 	= $this->sanitize_xss($details['mobile']);
		$signup_parameters['gender']   		= $this->sanitize_xss($details['gender']);
		$signup_parameters['token']   	 	= md5(rand());
		$signup_parameters['mobile_otp']   	= $otp;

		$user_detail_sql = "SELECT MobileNo FROM customer WHERE MobileNo=:mobile";
		$get_user_detail = $this->executeSQL($user_detail_sql, ['mobile' => $this->sanitize_xss($details['mobile'])], true);

		if (!is_null($get_user_detail) && !empty($get_user_detail)) {
			$response = [
				'is_user_saved'   => false,
				'user_id' 		  => 0,
				'is_mobile_exist' => true,
				'otp'			  => 0
			];
			return $response;
		}

		$this->beginTxn();
		$is_user_saved = $this->performDBUpdate(self::ADD_SIGNUP_WITH_MOBILE_SQL, $signup_parameters);
		$user_id = $this->getLastInsertedId();
		if ($is_user_saved) {
			$this->commitTxn();
			SMSNotifier::sendOtpSms($this->sanitize_xss($details['mobile']), $otp);
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_user_saved'   => $is_user_saved,
			'user_id' 		  => $user_id,
			'is_mobile_exist' => false,
			'otp'			  => $otp
		];
		return $response;
	}
	public function verifyEmailOTP($details)
	{
		$return_data        = ['is_verify' => false];
		$verification_sql = 'SELECT * FROM customer_master WHERE otp=:otp_code AND customer_id=:user_id';
		$user = $this->executeSQL($verification_sql, ['otp_code' => $this->sanitize_xss($details['otp']), 'user_id' => $this->sanitize_xss($details['user_id'])], true);
		if (!empty($user)) {
			$return_data  = ['is_verify' => true];

			$this->performDBUpdate("UPDATE customer_master SET is_verifid = 1 WHERE customer_id=:user_id", ['user_id' => $this->sanitize_xss($details['user_id'])]);
			return $return_data;
		}
		return $return_data;
	}

	public function customerLogin(array $details)
	{

		$response =
			[
				'user_id' 				=> 0,
				'token'   				=> '',
				'is_profile_verified'   => false,
				'otp_verify'   		    => false,
				'fire_base_token'       => '',
				'is_password'   		=> false,
			];
		$is_profile_verified = false;

		$verified = '';
		$mobile = '';
		if ($details['type_login'] == 'Mobile') {
			$verified = 'OTP_Verify';
			$sql = 'MobileNo=:mobile';
			$mobile = $this->sanitize_xss($details['email_or_mobile']);
		}
		if ($details['type_login'] == 'Email') {
			$verified = 'Email_Verify';
			$sql = 'Email=:mobile';
			$mobile = $this->sanitize_xss($details['email_or_mobile']);
		}
		$auth_sql = 'SELECT CustomerNo,CustomerName,MobileNo,Email,Token,DeviceFirebaseToken,Password 
			FROM customer 
			WHERE  ' . $sql . ' 
			AND(Status=:status AND ' . $verified . '=:otp_verify)';

		$user = $this->executeSQL($auth_sql, ['mobile' => $mobile, 'status' => 1, 'otp_verify' => 1], true);

		if (is_null($user) || empty($user)) {
			$response = [
				'user_id' 				=> 0,
				'token'   				=> '',
				'fire_base_token'   	=> '',
				'is_profile_verified'   => false,
				'otp_verify'   		    => false,
				'is_password'   		=> false,
			];
			return $response;
		}
		if (!is_null($user) || !empty($user)) {
			if ($user['CustomerName'] != "") {
				$is_profile_verified = true;
			}
			if ($user['DeviceFirebaseToken'] == NULL) {
				$tokan = '';
			} else {
				$tokan = $user['DeviceFirebaseToken'];
			}
			if (password_verify($this->sanitize_xss($details['password']), $user['Password'])) {

				$response = [
					'user_id' 				=> $user['CustomerNo'],
					'token'   				=> $user['Token'],
					'fire_base_token'   	=> $tokan,
					'is_profile_verified'   => $is_profile_verified,
					'otp_verify'   		    => true,
					'is_password'   		=> true,
				];
				return $response;
			} else {
				$response = [
					'user_id' 				=> $user['CustomerNo'],
					'token'   				=> $user['Token'],
					'fire_base_token'   	=> $tokan,
					'is_profile_verified'   => $is_profile_verified,
					'otp_verify'   		    => true,
					'is_password'   		=> false,
				];
			}
			return $response;
		}
		return $response;
	}

	public function update_profile(array $details)
	{

		$response = [
			'is_profile_updated'  => false,
			'is_email_exist' 	  => false,
			'is_mobile_exist'     => false,
		];
		$is_profile_updated     = false;
		$user_id 		   = 0;
		$signup_parameters = [];

		if (!empty($details['email'])) {
			$user_email_detail_sql = "SELECT Email FROM customer WHERE Email=:email AND CustomerNo !=:user_id";
			$user_email_detail = $this->executeSQL(
				$user_email_detail_sql,
				[
					'email'   => $this->sanitize_xss($details['email']),
					'user_id' => $this->sanitize_xss($details['user_id'])
				],
				true
			);

			if (!is_null($user_email_detail) && !empty($user_email_detail)) {
				$response = [
					'is_profile_updated'  => false,
					'is_email_exist' 	  => true,
					'is_mobile_exist'     => false,
				];
				return $response;
			}
		}

		if (!empty($details['mobile_no'])) {
			$mobile = $this->sanitize_xss($details['mobile_no']);
			$user_mobile_detail_sql = "SELECT MobileNo FROM customer WHERE MobileNo=:mobile AND CustomerNo !=:user_id";
			$user_mobile_detail = $this->executeSQL(
				$user_mobile_detail_sql,
				[
					'user_id' => $this->sanitize_xss($details['user_id']),
					'mobile'  => $mobile
				],
				true
			);

			if (!is_null($user_mobile_detail) && !empty($user_mobile_detail)) {
				$response = [
					'is_profile_updated'  => false,
					'is_email_exist' 	  => false,
					'is_mobile_exist'     => true,
				];
				return $response;
			}
		}


		$signup_parameters['name']   	 = $this->sanitize_xss($details['name']);
		$signup_parameters['email']  	 = $this->sanitize_xss($details['email']);
		$signup_parameters['gender']   	 = $this->sanitize_xss($details['gender']);
		$signup_parameters['mobile']   	 = $this->sanitize_xss($details['mobile_no']);
		$signup_parameters['user_id']    = $this->sanitize_xss($details['user_id']);
		$signup_parameters['address']    = $this->sanitize_xss($details['address']);
		$signup_parameters['birthday']   = !empty($this->sanitize_xss($details['birthday'])) ? date('Y-m-d', strtotime(date($this->sanitize_xss($details['birthday'])))) : "";

		/*!empty($this->sanitize_xss($sales_bill_detail['discount']))?$this->sanitize_xss($sales_bill_detail['discount']):0;*/

		$this->beginTxn();

		$user_sql = "SELECT CustomerNo FROM customer WHERE CustomerNo=:user_id";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$is_profile_updated = $this->performDBUpdate(self::UPDATE_PROFILE_SQL, $signup_parameters);

			if ($is_profile_updated) {
				$this->commitTxn();

				$email_verify_sql = 'Update customer SET Email_Verify=:email_verify WHERE CustomerNo=:User_Id';
				$this->performDBUpdate($email_verify_sql, ['email_verify' => 1, 'User_Id' => $this->sanitize_xss($details['user_id'])]);
			} else {
				$this->rollBackTxn();
			}
		}


		$response = [
			'is_profile_updated'  => $is_profile_updated,
			'is_email_exist' 	  => false,
			'is_mobile_exist'     => false,
		];

		return $response;
	}
	public function updateAaddressSetDefault(array $details)
	{

		$response = [
			'is_profile_updated'  => false,
		];
		$is_profile_updated     = false;
		$user_id 		   = 0;
		$address_parameters = [];

		$address_parameters['address_id'] = $this->sanitize_xss($details['address_id']);
		$address_parameters['user_id']    = $this->sanitize_xss($details['user_id']);
		$address_parameters['status']     = 1;

		$this->beginTxn();


		$user_sql = "SELECT CustomerNo FROM customer WHERE CustomerNo=:user_id";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$is_profile_updated = $this->performDBUpdate(self::UPDATE_SET_ADDRESS_SQL, $address_parameters);

			if ($is_profile_updated) {
				$this->commitTxn();
			} else {
				$this->rollBackTxn();
			}
		}


		$response = [
			'is_profile_updated'  => $is_profile_updated,
		];

		return $response;
	}

	public function addCustomerAddress(array $details)
	{

		$response = [
			'is_address_added'  => false,
			'you_can_not_add'   => false,
		];
		$is_address_added     = false;

		$address_parameters = [];
		$address_parameters['unitno']           = $this->sanitize_xss($details['unitno']);
		$address_parameters['apartment']  	 	= $this->sanitize_xss($details['apartment']);
		$address_parameters['postcode']    		= $this->sanitize_xss($details['postcode']);
		$address_parameters['address']    		= $this->sanitize_xss($details['address']);
		$address_parameters['user_id']   		= $this->sanitize_xss($details['user_id']);
		$address_parameters['latitude']   		= $this->sanitize_xss($details['latitude']);
		$address_parameters['longitude']   		= $this->sanitize_xss($details['longitude']);

		$this->beginTxn();

		$post_code_sql = "SELECT Pincode FROM pincode_master 
						  WHERE Pincode=:postcode AND Status=:status";
		$post_code = $this->executeSQL(
			$post_code_sql,
			[
				'postcode' => $this->sanitize_xss($details['postcode']),
				'status'   => 1
			],
			true
		);

		if (!is_null($post_code) && !empty($post_code)) {
			$is_address_added = $this->performDBUpdate(self::ADD_CUSTOMER_ADDRESS_SQL, $address_parameters);

			if ($is_address_added) {
				$this->commitTxn();
			} else {
				$this->rollBackTxn();
			}
			$response = [
				'is_address_added'  => $is_address_added,
				'you_can_not_add'  => true,
			];
			return $response;
		}
		$response = [
			'is_address_added'  => $is_address_added,
			'you_can_not_add'  => false,
		];
		return $response;
	}
	public function addContact(array $details)
	{

		$response = [
			'is_contact_added'  => false,
		];
		$is_contact_added     = false;

		$contact_parameters = [];
		$contact_parameters['purpose']  	 	= $this->sanitize_xss($details['purpose']);
		$contact_parameters['name']  	 		= $this->sanitize_xss($details['name']);
		$contact_parameters['contact_number']   = $this->sanitize_xss($details['contact_number']);
		$contact_parameters['email']    		= $this->sanitize_xss($details['email']);
		$contact_parameters['comment']   		= $this->sanitize_xss($details['comment']);
		$contact_parameters['platform']   		= $this->sanitize_xss($details['platform']);

		$this->beginTxn();

		$is_contact_added = $this->performDBUpdate(self::ADD_CONTACT_SQL, $contact_parameters);

		if ($is_contact_added) {
			$this->commitTxn();
			$this->sendAdminSMS();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_contact_added'  => $is_contact_added,
		];
		return $response;
	}
	public function sendAdminSMS()
	{
		$mobile_sql = "SELECT OwnerMobileNo FROM restaurant_list WHERE RestaurantId=:restaurant_id";
		$mobile_detail = $this->executeSQL($mobile_sql, ['restaurant_id' => 1], true);

		if (!empty($mobile_detail)) {
			$owner_mobile_no   = $mobile_detail["OwnerMobileNo"];
			$owner_mobile_no   = explode(",", $owner_mobile_no);
			$message = 'Contact us form has been submitted On Sunrise Fresh Mobile App. Please check the Admin for more details.';
			foreach ($owner_mobile_no as $key => $mobile) {
				$mobile = ltrim($this->sanitize_xss($mobile), "+61");
				SMSNotifier::sendOwnerSMS($mobile, $message);
			}
		}
		return true;
	}
	public function updateCustomerAddress(array $details)
	{

		$response = [
			'is_address_updated'  => false,
			'you_can_not_add'     => false,
		];
		$is_address_updated     = false;

		$address_parameters = [];

		$address_parameters['unitno']           = $this->sanitize_xss($details['unitno']);
		$address_parameters['apartment']  	 	= $this->sanitize_xss($details['apartment']);
		$address_parameters['postcode']    		= $this->sanitize_xss($details['postcode']);
		$address_parameters['address']    		= $this->sanitize_xss($details['address']);
		$address_parameters['user_id']   		= $this->sanitize_xss($details['user_id']);
		$address_parameters['latitude']   		= $this->sanitize_xss($details['latitude']);
		$address_parameters['longitude']   		= $this->sanitize_xss($details['longitude']);
		$address_parameters['address_id']   	= $this->sanitize_xss($details['address_id']);

		$this->beginTxn();

		$post_code_sql = "SELECT Pincode FROM pincode_master 
						  WHERE Pincode=:postcode AND Status=:status";
		$post_code = $this->executeSQL(
			$post_code_sql,
			[
				'postcode' => $this->sanitize_xss($details['postcode']),
				'status'   => 1
			],
			true
		);

		if (!is_null($post_code) && !empty($post_code)) {
			$user_sql = "SELECT CustomerNo FROM customer WHERE CustomerNo=:user_id";
			$user = $this->executeSQL(
				$user_sql,
				[
					'user_id' => $this->sanitize_xss($details['user_id']),
				],
				true
			);

			if (!is_null($user) && !empty($user)) {
				$is_address_updated = $this->performDBUpdate(self::UPDATE_ADDRESS_SQL, $address_parameters);

				if ($is_address_updated) {
					$this->commitTxn();
				} else {
					$this->rollBackTxn();
				}
			}
			$response = [
				'is_address_updated'  => $is_address_updated,
				'you_can_not_add'     => true,
			];
			return $response;
		}
		return $response;
	}
	public function deleteAddress(array $details)
	{

		$response = [
			'is_deleted'  => false,
		];
		$is_deleted     	= false;
		$user_id 		    = 0;
		$address_parameters = [];

		$address_parameters['address_id'] = $this->sanitize_xss($details['address_id']);
		$address_parameters['user_id']    = $this->sanitize_xss($details['user_id']);

		$this->beginTxn();


		$user_sql = "SELECT CustomerNo FROM customer WHERE CustomerNo=:user_id";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$remove_detail_sql = 'DELETE FROM address_book WHERE AddressId=:address_id AND CustomerNo=:user_id';

			$is_deleted = $this->performDBUpdate($remove_detail_sql, $address_parameters);

			if ($is_deleted) {
				$this->commitTxn();
			} else {
				$this->rollBackTxn();
			}
		}


		$response = [
			'is_deleted'  => $is_deleted,
		];

		return $response;
	}

	public function addFavourite(array $details)
	{

		$response = [
			'is_favourite_added'  => false,
			'is_allready_exist'   => false,
		];
		$is_favourite_added     = false;

		$favourite_parameters = [];

		$favourite_parameters['user_id']   	 = $this->sanitize_xss($details['user_id']);
		$favourite_parameters['product_id']  = $this->sanitize_xss($details['product_id']);



		$fav_sql = "SELECT Item_Id,CustomerNo FROM favourite WHERE Item_Id=:product_id AND CustomerNo=:user_id";
		$fav = $this->executeSQL(
			$fav_sql,
			[
				'product_id' => $this->sanitize_xss($details['product_id']),
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($fav) && !empty($fav)) {
			$response = [
				'is_favourite_added'  => false,
				'is_allready_exist'   => true,
			];
			return $response;
		}
		$this->beginTxn();

		$is_favourite_added = $this->performDBUpdate(self::ADD_FAVOURITE_SQL, $favourite_parameters);

		if ($is_favourite_added) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_favourite_added'  => $is_favourite_added,
			'is_allready_exist'   => false,
		];

		return $response;
	}
	public function removeFavourite(array $details)
	{

		$response = [
			'is_favourite_deleted'  => false,
		];
		$is_favourite_deleted     = false;

		$favourite_parameters = [];

		$favourite_parameters['user_id']   	   = $this->sanitize_xss($details['user_id']);
		$favourite_parameters['product_id']    = $this->sanitize_xss($details['product_id']);
		$this->beginTxn();


		$is_favourite_sql = "DELETE FROM favourite WHERE Item_Id=:product_id AND CustomerNo=:user_id";
		$is_favourite_deleted = $this->performDBUpdate($is_favourite_sql, $favourite_parameters);

		if ($is_favourite_deleted) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_favourite_deleted'  => $is_favourite_deleted,
		];

		return $response;
	}

	public function count_order_total_amount($order_detail, $delivery_charge)
	{
		$total_amount = 0;
		if (isset($order_detail['item_details'])) {
			if ($order_detail['item_details'] != '') {
				$myArray = explode(',', $order_detail['item_details']);

				foreach ($myArray as $key) {
					$ItemSplitSpace = explode(' ', $key);

					$ItemNo 		= $ItemSplitSpace[0];
					$Quantity 		= $ItemSplitSpace[1];
					$Price 			= $ItemSplitSpace[2];
					$total_amount   += (float)$Price * (float)$Quantity;
				}
			}
		}
		$setting_sql = "SELECT MinBillAmount FROM restaurant_list WHERE RestaurantId=:RestaurantId";
		$setting = $this->executeSQL(
			$setting_sql,
			[
				'RestaurantId' => 1,
			],
			true
		);

		if (!is_null($setting) && !empty($setting)) {
			$total_amount = $total_amount + $delivery_charge;
			if ($total_amount >= $setting['MinBillAmount']) {
				return true;
			}
		}
		return false;
	}
	public function order_address_detail_by_address_id_and_user_id($order_detail)
	{
		$address_sql = "SELECT * FROM address_book WHERE CustomerNo=:user_id AND AddressId=:AddressId";
		$address = $this->executeSQL(
			$address_sql,
			[
				'user_id' => $this->sanitize_xss($order_detail['user_id']),
				'AddressId' => $this->sanitize_xss($order_detail['address_id']),
			],
			true
		);

		return $address;
	}

	public function coupon_code_add_in_user_master($details)
	{
		$is_added = false;
		if ($this->sanitize_xss($details["coupon_code"]) != "") {
			$coupon_params = [
				'customer_no' => $this->sanitize_xss($details['user_id']),
				'coupon_code' => $this->sanitize_xss($details['coupon_code']), 'restaurant_id' => 1
			];
			$add_coupon_sql = "INSERT INTO coupon_user(SrNo,CustomerNo,CouponCode,RestaurantId) VALUES (NULL,:customer_no,:coupon_code,:restaurant_id)";
			$is_added = $this->performDBUpdate($add_coupon_sql, $coupon_params);
			return $is_added;
		}
		return false;
	}
	public function confirmOrder(array $details)
	{

		$response = [
			'is_order_added'    => false,
			'is_order_message'  => false,
		];
		$is_order_added  = false;


		$setting_sql = "SELECT * FROM restaurant_list WHERE RestaurantId=:RestaurantId AND RestOpenClose=:RestOpenClose";
		$setting = $this->executeSQL(
			$setting_sql,
			[
				'RestOpenClose' => 1,
				'RestaurantId' => 1,
			],
			true
		);

		if (!is_null($setting) && !empty($setting)) {

			$shop_owner_mobile_no = $setting['MobileNo'];
			$latitude 			  = $setting['Latitude'];
			$longitude			  = $setting['Longitude'];
			$gst 				  = $setting['Gst'];
			$shop_name 	          = $setting['RestaurantName'];
			$shop_address         = $setting['Address'];
			$deliver_time 		  = $setting['DeliverTime'];
			$delivery_charge 	  = $setting['DeliveryCharge'];


			$is_valid_amount = $this->count_order_total_amount($details, $delivery_charge);

			if ($details['delivery_type'] == "Delivery" && $is_valid_amount == false) {
				$response = [
					'is_order_added'  => false,
					'is_order_message'  => 'Your order amount value is less then $ ' . $setting['MinBillAmount'] . " so you can't make order.",
					'Orderid'  => 0,
				];
				return $response;
			}

			$this->beginTxn();
			//max order id
			$order_max_sql = "SELECT Max(OrderId) As OrderId FROM order_master";
			$max_order_id = $this->getSingleValue($order_max_sql, 'OrderId');
			if ($max_order_id > 0) {
				$max_order_id = $max_order_id + 1;
			} else {
				$max_order_id = 1;
			}

			//max reference id
			$order_refer_max_sql = "SELECT Max(ReferenceId) As ReferenceId FROM order_master";
			$max_reference_id = $this->getSingleValue($order_refer_max_sql, 'ReferenceId');
			if ($max_reference_id > 0) {
				$max_reference_id = $max_reference_id + 1;
			} else {
				$max_reference_id = 101;
			}

			// get address


			$name = "";
			$unit_no = "";
			$address1 = "";
			$address2 = "";
			$landmark = "";
			$pincode = "";
			$mobile_no = "";
			$address_type = "";

			$address_detail = $this->order_address_detail_by_address_id_and_user_id($details);
			if (!empty($address_detail)) {
				$name 		  	= $address_detail['Name'];
				$unit_no    	= $address_detail['UnitNo'];
				$address1    	= $address_detail['Address1'];
				$address2    	= $address_detail['Address2'];
				$landmark    	= $address_detail['LandMark'];
				$pincode     	= $address_detail['Pincode'];
				$mobile_no    	= $address_detail['MobileNo'];
				$address_type 	= $address_detail['AddressType'];
			}
			if (!empty($address1)) {
				if (!empty($unit_no)) {
					$unit_no = $unit_no . ', ';
				}
				$address1 = $unit_no . $address1 . ', ' . $pincode;
			}



			/*if($address1 == "" || empty($address1)){	
					$address_r_sql = "SELECT * FROM customer WHERE CustomerNo=:user_id";
			        $address_r = $this->executeSQL($address_r_sql,['user_id'=>$this->sanitize_xss($details['user_id'])],true);
				    if(!empty($address_r)){		  
				        $mobile_no 	= $address_r['MobileNo'];
				        $name 		= $address_r['CustomerName'];	
				        $address1   = $name.','.$address1.','.$pincode;		
	    			}
				}	*/

			if ($details['delivery_type'] == "Collect") {
				$delivery_charge = 0;
			}

			$user_sql = "SELECT CustomerNo,CustomerName FROM customer WHERE CustomerNo=:user_id";
			$user = $this->executeSQL($user_sql, ['user_id' => $this->sanitize_xss($details['user_id'])], true);
			//echo "<pre>";print_r($user);die();
			if (!is_null($user) && !empty($user)) {

				$order_sql = "SELECT Count(*) as rowCount FROM order_master WHERE ReferenceId=:reference_id";
				$orderIfExist = $this->executeSQL($order_sql, ['reference_id' => $this->sanitize_xss($max_reference_id)], true);

				if ($orderIfExist['rowCount'] > 0) {
					$noOfRecord = true;
					$IsMsgSent  = false;
				} else {
					$myArray = explode(',', $details['item_details']);
					$order_items_list = [];
					foreach ($myArray as $key) {
						$ItemSplitSpace = explode(' ', $key);
						$ItemNo 		= $ItemSplitSpace[0];
						$Quantity 		= (float)$ItemSplitSpace[1];
						$Price 			= (float)$ItemSplitSpace[2];

						$order_parameters = [];

						$order_parameters['user_id']   	 		= $this->sanitize_xss($details['user_id']);
						$order_parameters['address_id']  		= $this->sanitize_xss($details['address_id']);
						$order_parameters['item_no'] 			= $ItemNo;
						$order_parameters['price']  			= $Price;
						$order_parameters['quantity']  			= $Quantity;
						$order_parameters['dates']  			= date("Y-m-d H:i:s");
						$order_parameters['max_order_id']  		= $max_order_id;
						$order_parameters['gst']  				= $gst;
						$order_parameters['delivery_charge']    = 0;
						if ($details['is_delivery_charge']  == 'Yes') {
							$order_parameters['delivery_charge']  	= $delivery_charge;
						}
						$order_parameters['name']    			= $user['CustomerName'];
						$order_parameters['address1']    		= $address1;
						$order_parameters['pincode']    		= $pincode;
						$order_parameters['address_type']    	= $address_type;
						$order_parameters['latitude']    		= $latitude;
						$order_parameters['longitude']    		= $longitude;
						$order_parameters['mobile_no']    		= $mobile_no;
						$order_parameters['coupon_code']    	= $this->sanitize_xss($details['coupon_code']);
						$order_parameters['coupon_amount']    	= $this->sanitize_xss($details['coupon_amount']);
						$order_parameters['payment_type']    	= $this->sanitize_xss($details['payment_type']);
						$order_parameters['delivery_type']    	= $this->sanitize_xss($details['delivery_type']);
						$order_parameters['transaction_id']    	= $this->sanitize_xss($details['transaction_id']);
						$order_parameters['status']    			= 1;
						$order_parameters['restaurant_id']    	= 1;
						$order_parameters['shop_name']    	    = $shop_name;
						$order_parameters['shop_address']    	= $shop_address;
						$order_parameters['platform_type']    	= $this->sanitize_xss($details['platform_type']);
						$order_parameters['instruction']    	= $this->sanitize_xss($details['instruction']);
						$order_parameters['reference_id']    	= $max_reference_id;
						$order_parameters['payment_confirm']    = $this->sanitize_xss($details['online_payment_confirm']);
						$order_parameters['pickup_slot']        = $this->sanitize_xss($details['pickup_slot']);

						$process_to_checkout_amount = $this->sanitize_xss($details['process_to_checkout_amount']); //change by haidar 8/9/2021
						//$order_parameters['order_status']       = 'Confirm';
						$order_parameters['order_status']  = 'Pending';
						/*Pending*/
						//[start] change by haidar on 8/9/2021

						if ($order_parameters['payment_confirm'] == 'No' && $process_to_checkout_amount == '0.00') {
							$order_parameters['order_status'] = 'Confirm';
						}



						//[end] change by haidar on 8/9/2021

						//[start] change by haidar on 7/9/2021
						if (!empty($this->sanitize_xss($details['credit_amount']))) {
							$order_parameters['credit_amount_use'] = $this->sanitize_xss($details['credit_amount']);
						} else {
							$order_parameters['credit_amount_use'] = $this->sanitize_xss($details['credit_amount']);
						}
						//[end] change by haidar on 7/9/2021

						$order_items_list[]   = $order_parameters;
					}

					//[start] change by haidar on 02/09/2021

					$credit_amount		= $this->sanitize_xss($details['credit_amount']);


					if ($credit_amount != "") {

						$creditNote_parameters = [];
						$creditNote_parameters['credit_amount'] = $this->sanitize_xss($details['credit_amount']);
						$creditNote_parameters['user_id'] = $this->sanitize_xss($details['user_id']);
						$creditNote_parameters['reference_id'] = $max_reference_id;

						$row_sql = "SELECT CN_Netamount FROM customer WHERE CustomerNo=:CustomerNo";
						$row = $this->executeSQL($row_sql, ['CustomerNo' => $this->sanitize_xss($details['user_id'])], true);



						if ($row['CN_Netamount'] != 0) {
							$this->performDBUpdate("UPDATE customer SET CN_Netamount = CN_Netamount - :credit_amount WHERE CustomerNo=:user_id", ['credit_amount' => $this->sanitize_xss($details['credit_amount']), 'user_id' => $this->sanitize_xss($details['user_id'])]);

							while ($credit_amount != 0) {



								$row_sql = "SELECT * FROM credit_note WHERE CustomerNo=:CustomerNo and Is_used=0";
								$row = $this->executeSQL($row_sql, ['CustomerNo' => $this->sanitize_xss($details['user_id'])], true);


								if ($credit_amount <= $row['CN_Remainning_amount']) // if credit_Amt <= remainning Amt particular CN_Id
								{

									// done for update remainning amount in CN  
									//when blank have in CN_usedOrderRefId then don't use CONCAT function simple assign reference_id  
									if (empty($row['CN_usedOrderRefId'])) {
										$this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount = CN_Remainning_amount -:credit_amount,CN_usedOrderRefId =:reference_id WHERE CN_Id=:cnId and Is_used=0", array("credit_amount" => $credit_amount, "reference_id" => $max_reference_id, "cnId" => $row['CN_Id']));
									} else {
										$this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount = CN_Remainning_amount -:credit_amount,CN_usedOrderRefId = CONCAT(CN_usedOrderRefId,',',:reference_id) WHERE CN_Id=:cnId and Is_used=0", array("credit_amount" => $credit_amount, "reference_id" => $max_reference_id, "cnId" => $row['CN_Id']));
									}

									// done for flag change 
									$this->performDBUpdate("UPDATE credit_note set Is_used=:isused where CN_Id=:cnId and CN_Remainning_amount=:remainning_amt", array("isused" => 1, "cnId" => $row['CN_Id'], "remainning_amt" => 0));
									$credit_amount = 0;
								} else                                        // else  credit_Amt > remainning Amt particular CN_Id
								{

									$row_sql = $this->executeSQL("SELECT CN_Remainning_amount from credit_note where CN_Id=:cnid", ['cnid' => $row['CN_Id']], true);

									$credit_amount =   $credit_amount - $row_sql['CN_Remainning_amount'];

									$this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount =:credit_amount,CN_usedOrderRefId = CONCAT(CN_usedOrderRefId,',',:reference_id),Is_used=1 WHERE CN_Id=:cnId", array("credit_amount" => 0.00, "reference_id" => $max_reference_id, "cnId" => $row['CN_Id']));
								}
							}
						}
					}

					//[end]change by haidar on 02/09/2021


					$is_order_added = $this->performBatchUpdate(self::ADD_ORDER_SQL, $order_items_list);
					if ($is_order_added) {
						$this->commitTxn();
						$this->coupon_code_add_in_user_master($details);


						$row_sql = "SELECT OrderId,ReferenceId FROM order_master WHERE CustomerNo=:CustomerNo AND AddressId=:AddressId GROUP By OrderId ORDER BY OrderNo Desc LIMIT 1";
						$row = $this->executeSQL($row_sql, ['CustomerNo' => $this->sanitize_xss($details['user_id']), 'AddressId' => $this->sanitize_xss($details['address_id'])], true);

						if (!empty($row)) {
							$new_order_no   = $row["OrderId"];
						}

						if ($this->sanitize_xss($details['address_id']) == "" || $this->sanitize_xss($details['address_id']) == "0") {
							//Take away
							/*$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order, Your order will be ready within ".$deliver_time." mins. So, Please visit our Sunrise Fresh and collect your parcel after ".$deliver_time." mins.",
									'Orderid'  => $new_order_no,
								];*/
							$response = [
								'is_order_added'  => true,
								'is_order_message'  => "Sunrise Fresh has received your order.",
								'Orderid'  => $new_order_no,
							];
						} else {
							//Home delivery
							/*$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order, Sunrise Fresh will initiate processing of your order within ".$deliver_time." minutes.",
									'Orderid'  => $new_order_no,
								];*/
							$response = [
								'is_order_added'  => true,
								'is_order_message'  => "Sunrise Fresh has received your order.",
								'Orderid'  => $new_order_no,
							];
						}
						$this->sendSMSToOwner($new_order_no);
					} else {
						$this->rollBackTxn();
						$response =
							[
								'is_order_added'  => false,
								'is_order_message'  => "Error in place your order",
								'Orderid'  => 0,
							];
					}
				}
			}
		} else {
			$response = [
				'is_order_added'  => false,
				'is_order_message'  => "Sunrise Fresh is closed, you can't make order.",
				'Orderid'  => 0,
			];
		}
		return $response;
	}
	public function sendSMSToOwner($order_id)
	{
		$mobile_sql = "SELECT OwnerMobileNo FROM restaurant_list WHERE RestaurantId=:restaurant_id";
		$mobile_detail = $this->executeSQL($mobile_sql, ['restaurant_id' => 1], true);

		if (!empty($mobile_detail)) {
			$owner_mobile_no   = $mobile_detail["OwnerMobileNo"];
			$owner_mobile_no   = explode(",", $owner_mobile_no);

			$order_sql = "SELECT SUM(Price * Quantity) as total_amount,OrderId,ReferenceId,OrderNo,
	 					 Date,DeliveryCharge,Gst,CouponAmount,Pickup_Slot
	 		 			 FROM order_master 
	 					 WHERE OrderId=:order_id 
	 					 GROUP By OrderId ORDER BY OrderNo Desc LIMIT 1";
			$order_detail = $this->executeSQL($order_sql, ['order_id' => $order_id], true);
			//$message = 'New Order '.$order_id.' is genereted please check more detail in admin Panel.';
			if (!empty($order_detail)) {

				$sub_total =  number_format($order_detail['total_amount'], 2);
				$after_coupon_amount = (float)$order_detail['total_amount'] - (float)$order_detail['CouponAmount'];
				$gst                = $after_coupon_amount * (float)$order_detail['Gst'] / 100;
				$net_amount         = $after_coupon_amount + (float)$gst + (float)$order_detail['DeliveryCharge'];
				$net_amount         = number_format($net_amount, 2);

				$total_amount = $order_detail['total_amount'] - $order_detail['CouponAmount'];
				$date = date_create($order_detail['Date']);
				$date = date_format($date, "d-m-Y H:i:s");

				$message = 'New Order  || ' . $order_detail['ReferenceId'] . ' || ' . $date . ' || ' . 'A$' . $net_amount;
				if (!empty($order_detail['Pickup_Slot']) && $order_detail['Pickup_Slot'] != '') {
					$message .= ' || PICK ' . $order_detail['Pickup_Slot'];
				}
			}
			foreach ($owner_mobile_no as $key => $mobile) {
				$mobile = ltrim($this->sanitize_xss($mobile), "+61");
				SMSNotifier::sendOwnerSMS($mobile, $message);
			}
		}
		return true;
	}
	public function updateDeviceToken(array $details)
	{

		$response = [
			'is_token_updated'  => false,
		];
		$is_token_updated     = false;
		$user_id 		   = 0;
		$device_parameters = [];

		$device_parameters['device_firebase_token']  = $details['device_firebase_token'];
		$device_parameters['platform']    		     = $this->sanitize_xss($details['platform']);
		$device_parameters['user_id']    		     = $this->sanitize_xss($details['user_id']);

		$this->beginTxn();


		$user_sql = "SELECT CustomerNo FROM customer WHERE CustomerNo=:user_id";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$is_token_updated = $this->performDBUpdate(self::UPDATE_DEVICE_TOKEN_SQL, $device_parameters);

			if ($is_token_updated) {
				$this->commitTxn();
			} else {
				$this->rollBackTxn();
			}
		}
		$response = [
			'is_token_updated'  => $is_token_updated,
		];

		return $response;
	}
	public function resendOTP(array $details)
	{

		$response = [
			'is_sent'  => false,
		];
		$is_sent     = false;

		$otp 			   			= rand(1000, 9999);
		$parameters 				= [];
		$parameters['user_id']    	= $this->sanitize_xss($details['user_id']);
		$parameters['otp'] 			= $otp;
		$this->beginTxn();


		$user_sql = "SELECT CustomerNo,MobileNo,Email FROM customer WHERE CustomerNo=:user_id";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $this->sanitize_xss($details['user_id']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$is_sent = $this->performDBUpdate(self::UPDATE_OTP_SQL, $parameters);
			if ($is_sent) {
				$this->commitTxn();

				if ($details['is_email'] == 'Yes') {
					EmailNotifier::sendOtpEmail($this->sanitize_xss($user['Email']), $otp);
				}
				if ($details['is_mobile'] == 'Yes') {
					$mobile = ltrim($this->sanitize_xss($user['MobileNo']), "0");
					SMSNotifier::sendOtpSms($mobile, $otp);
				}
			} else {
				$this->rollBackTxn();
			}
		}
		$response = [
			'is_sent'  => $is_sent,
		];

		return $response;
	}

	public function changePassword($details)
	{
		$new_password = password_hash($this->sanitize_xss($details['new_password']), PASSWORD_BCRYPT);
		$change_password_sql = 'Update customer SET Password=:new_password WHERE CustomerNo=:User_Id';

		return $this->performDBUpdate($change_password_sql, ['new_password' => $new_password, 'User_Id' => $this->sanitize_xss($details['user_id'])]);
	}

	public function addPriceChangeAlertandStockAvilable(array $details)
	{

		$response = [
			'is_added' => false,

		];
		$is_added     = false;

		$add_parameters = [];
		$item_price     = 0;
		$add_parameters['product_id']   = $this->sanitize_xss($details['product_id']);
		$add_parameters['user_id']  	= $this->sanitize_xss($details['user_id']);
		$add_parameters['type']  		= $this->sanitize_xss($details['type']);
		$add_parameters['platform']  	= $this->sanitize_xss($details['platform']);

		$this->beginTxn();

		$item_sql = "SELECT Price_Text,OfferPrice_Text FROM item_master WHERE ItemNo=:product_id";
		$item = $this->executeSQL(
			$item_sql,
			[
				'product_id'  => $this->sanitize_xss($details['product_id']),
			],
			true
		);
		if (!is_null($item) && !empty($item)) {
			if ($item['OfferPrice_Text'] > 0) {
				$item_price 			  = $item['OfferPrice_Text'];
				$add_parameters['type'] = 'Promotion';
			} else {
				$item_price = $item['Price_Text'];
			}
		}

		$add_parameters['item_price'] = $item_price;

		$user_sql = "SELECT id FROM notification_detail WHERE User_Id=:user_id AND Product_id=:product_id AND Type=:type";
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' 	=> $this->sanitize_xss($details['user_id']),
				'product_id'  => $this->sanitize_xss($details['product_id']),
				'type'  => $this->sanitize_xss($details['type']),
			],
			true
		);

		if (!is_null($user) && !empty($user)) {
			$notification_sql = 'Update notification_detail 
        	SET Product_id=:product_id,Updated_Date=NOW(),Item_Price=:item_price,Platform=:platform
        	WHERE User_Id=:user_id AND Product_id=:product_id AND Type=:type';
			$is_added = $this->performDBUpdate($notification_sql, $add_parameters);
		} else {
			$is_added = $this->performDBUpdate(self::ADD_NOTIFICAION_SQL, $add_parameters);
		}

		if ($is_added) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_added'  => $is_added,
		];
		return $response;
	}
	public function removeCustomerAddress(array $details)
	{

		$response = [
			'is_address_deleted'  => false,
		];
		$is_address_deleted     = false;

		$address_parameters = [];

		$address_parameters['user_id']   	= $this->sanitize_xss($details['user_id']);
		$address_parameters['address_id']   = $this->sanitize_xss($details['address_id']);
		$this->beginTxn();

		$is_address_sql = "DELETE FROM address_book WHERE AddressId=:address_id AND CustomerNo=:user_id";
		$is_address_deleted = $this->performDBUpdate($is_address_sql, $address_parameters);

		if ($is_address_deleted) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_address_deleted'  => $is_address_deleted,
		];
		return $response;
	}
	public function ForgotPasswordresendOTP(array $details)
	{

		$response = [
			'is_sent'  => false,
			'otp' => 0,
			'user_id'  => 0,
			'not_signup' => false  // change by haidar on 04/10/2021
		];
		$is_sent     = false;
		$not_signup  = false;
		$mobile = '';
		$otp 			   					= rand(1000, 9999);
		$parameters 						= [];
		if ($details['type'] == 'Email') {
			$parameters['email_or_mobile']    	= $this->sanitize_xss($details['email_or_mobile']);
		}
		if ($details['type'] == 'Mobile') {
			$mobile = ltrim($this->sanitize_xss($details['email_or_mobile']), "0");
			$parameters['email_or_mobile']  = $mobile;
		}
		$parameters['otp'] 					= $otp;


		$this->beginTxn();

		if ($details['type'] == 'Email') {
			$query_sql = 'Email=:user_id';
			$mobile = $this->sanitize_xss($details['email_or_mobile']);
		}
		if ($details['type'] == 'Mobile') {
			$query_sql = 'MobileNo=:user_id';
			$mobile = $this->sanitize_xss($details['email_or_mobile']);
		}

		$user_sql = 'SELECT CustomerNo,MobileNo,Email FROM customer WHERE ' . $query_sql . '';
		$user = $this->executeSQL(
			$user_sql,
			[
				'user_id' => $mobile,
			],
			true
		);
		$user_id = 0;
		if (!is_null($user) && !empty($user)) {
			$user_id = $user['CustomerNo'];
			if ($details['type'] == 'Email') {
				$is_sent = $this->performDBUpdate(self::UPDATE_OTP_EMAIL_SQL, $parameters);
			}
			if ($details['type'] == 'Mobile') {
				$is_sent = $this->performDBUpdate(self::UPDATE_OTP_MOBILE_SQL, $parameters);
			}

			if ($is_sent) {
				$this->commitTxn();
				if ($details['type'] == 'Email') {
					EmailNotifier::sendOtpEmail($this->sanitize_xss($user['Email']), $otp);
				}
				if ($details['type'] == 'Mobile') {
					$mobile = ltrim($this->sanitize_xss($user['MobileNo']), "0");
					SMSNotifier::sendOtpSms($mobile, $otp);
				}
			} else {
				$this->rollBackTxn();
			}
		} else {
			$not_signup = true;       // change by haidar on 04/10/2021
		}
		$response = [
			'is_sent'  => $is_sent,
			'otp'      => $otp,
			'user_id'  => $user_id,
			'not_signup' => $not_signup
		];

		return $response;
	}

	public function getCategoryIdByItemId($item_id)
	{
		$item_sql = 'SELECT CategoryNo FROM item_master WHERE ItemNo=:item_id';
		$item = $this->executeSQL($item_sql, ['item_id' => $item_id], true);

		if (!is_null($item) || !empty($item)) {
			return $item['CategoryNo'];
		}
		return 0;
	}

	public function saveCategorySearchItems($items_detail, $user_id)
	{

		$current_date = date('Y-m-d');
		if (!empty($items_detail)) {
			$result = [];
			$items_list = [];
			foreach ($items_detail as $key => $value) {
				$result['item_id'] = $value['id'];
				$result['dates']   = $current_date;
				$result['user_id'] = $user_id;
				$result['category_id'] = $this->getCategoryIdByItemId($value['id']);
				$items_list[] = $result;
			}
			$this->performBatchUpdate(self::ADD_SEARCH_SQL, $items_list);
			return true;
		}
		return true;
	}
	public function getPriceByItemId($item_id)
	{
		$item_sql = 'SELECT Price_Text FROM item_master WHERE ItemNo=:item_id';
		$item = $this->executeSQL($item_sql, ['item_id' => $item_id], true);

		if (!is_null($item) || !empty($item)) {
			return $item['Price_Text'];
		}
		return 0;
	}
	public function getFirbaseTokenByUserId($user_id)
	{
		$user_sql = 'SELECT DeviceFirebaseToken FROM customer WHERE CustomerNo=:user_id';
		$user = $this->executeSQL($user_sql, ['user_id' => $user_id], true);

		if (!is_null($user) || !empty($user)) {
			return $user;
		}
		return 0;
	}
	public function deletePushNotificationDetailItem($id)
	{
		$is_notification_sql = "DELETE FROM notification_detail WHERE id=" . $id;
		$this->performDBUpdate($is_notification_sql, []);
		return true;
	}
	public function getStockDetailByItemId($item_id)
	{
		$item_sql = 'SELECT ItemName_Text,ItemNo,IsOutOfStock FROM item_master WHERE ItemNo=:item_id';
		$item = $this->executeSQL($item_sql, ['item_id' => $item_id], true);

		if (!is_null($item) || !empty($item)) {
			return $item;
		}
		return 0;
	}



	public function resetPassword($details)
	{
		$response = [
			'is_password_changed' => false,
			'is_otp_exist'		  => false,
		];

		$is_password_changed = false;
		$user_detail_sql = "SELECT CustomerNo,OtpCode,MobileNo,Email FROM customer WHERE CustomerNo=:user_id 
							AND OtpCode=:otp";
		$get_user_detail = $this->executeSQL($user_detail_sql, ['user_id' => $this->sanitize_xss($details['user_id']), 'otp' => $this->sanitize_xss($details['otp'])], true);

		if (!is_null($get_user_detail) && !empty($get_user_detail)) {
			$this->beginTxn();

			$new_password = password_hash($this->sanitize_xss($details['new_password']), PASSWORD_BCRYPT);
			$change_password_sql = 'Update customer SET Password=:new_password WHERE CustomerNo=:User_Id';

			$is_password_changed = $this->performDBUpdate($change_password_sql, ['new_password' => $new_password, 'User_Id' => $this->sanitize_xss($details['user_id'])]);

			if ($is_password_changed) {
				$this->commitTxn();
				if ($get_user_detail['MobileNo'] != '') {
					$otp_sql = 'Update customer SET OTP_Verify=:mobile_verify WHERE CustomerNo=:User_Id';
					$this->performDBUpdate($otp_sql, ['mobile_verify' => 1, 'User_Id' => $this->sanitize_xss($details['user_id'])]);
				} else {
					$otp_sql = 'Update customer SET Email_Verify=:email_verify WHERE CustomerNo=:User_Id';
					$this->performDBUpdate($otp_sql, ['email_verify' => 1, 'User_Id' => $this->sanitize_xss($details['user_id'])]);
				}
			} else {
				$this->rollBackTxn();
			}
			$response = [
				'is_password_changed' => $is_password_changed,
				'is_otp_exist'		  => true,
			];
		}
		return $response;
	}

	public function addSignupWithSocialAccount(array $details)
	{

		$response = [
			'is_user_saved'   => false,
			'user_id' 		  => 0,
			'is_email_exist'  => false,
			'register_by'	  => '',
		];
		$is_user_saved     = false;
		$user_id 		   = 0;
		$signup_parameters = [];
		$otp 			   = rand(1000, 9999);
		$signup_parameters['name']   	 		= $this->sanitize_xss($details['name']);
		$signup_parameters['token']   	        = md5(rand());
		$signup_parameters['mobile_otp']        = $otp;
		$signup_parameters['email']  		    = $this->sanitize_xss($details['email']);
		$signup_parameters['type']  		    = $this->sanitize_xss($details['type']);


		$user_detail_sql = "SELECT Email,RegisterBy,CustomerNo FROM customer WHERE Email=:email";
		$get_user_detail = $this->executeSQL($user_detail_sql, ['email' => $this->sanitize_xss($details['email'])], true);

		if (!is_null($get_user_detail) && !empty($get_user_detail)) {
			$registered_by = '';
			if ($get_user_detail['RegisterBy'] != "" || $get_user_detail['RegisterBy'] != NULL) {
				$registered_by = $get_user_detail['RegisterBy'];
			}
			$response = [
				'is_user_saved'   => false,
				'user_id' 		  => $get_user_detail['CustomerNo'],
				'is_email_exist'  => true,
				'register_by'     => $registered_by,
			];
			return $response;
		}

		$this->beginTxn();
		$is_user_saved = $this->performDBUpdate(self::ADD_SIGNUP_WITH_SOCIAL_SQL, $signup_parameters);
		$user_id = $this->getLastInsertedId();
		if ($is_user_saved) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_user_saved'   => $is_user_saved,
			'user_id' 		  => $user_id,
			'is_email_exist'  => false,
			'register_by'     => $details['type'],
		];
		return $response;
	}

	/*public function getCustomerProfileDetail(array $details)
	{
		$this->addLoginUserLog($details);
        $user_sql = 'SELECT CustomerNo,CustomerName,MobileNo,Email,DATE_FORMAT(BirthDay,"%d-%m-%Y") as BirthDate,Gender,RegisterBy FROM customer 
                      WHERE Status=:status AND CustomerNo=:user_id';
        $user_params = [
           'status'      => 1,
           'user_id'     => $this->sanitize_xss($details['user_id'])
        ];
        $user_detail = $this->executeSQL($user_sql,$user_params,true);

        if(!empty($user_detail))
        {
           if($user_detail['MobileNo'] == '' || $user_detail['MobileNo'] == NULL){
                $user_detail['MobileNo'] = '';
           }
            if($user_detail['CustomerName'] == '' || $user_detail['CustomerName'] == NULL){
                $user_detail['CustomerName'] = '';
           }
            if($user_detail['Email'] == '' || $user_detail['Email'] == NULL){
                $user_detail['Email'] = '';
           }
           if($user_detail['BirthDate'] == '' || $user_detail['BirthDate'] == NULL){
                $user_detail['BirthDate'] = '';
           }
           if($user_detail['Gender'] == '' || $user_detail['Gender'] == NULL){
                $user_detail['Gender'] = '';
           }
           if($user_detail['RegisterBy'] == '' || $user_detail['RegisterBy'] == NULL){
                $user_detail['RegisterBy'] = '';
           }
           return $user_detail;
         }
      return false;
	}*/
	public function addLoginUserLog(array $details)
	{
		$is_log_added   = false;
		$response = [
			'is_log_added'   => false,
		];
		$log_parameters = [];
		$log_parameters['user_id']       = $this->sanitize_xss($details['user_id']);
		$log_parameters['user_type']     = 'Customer';
		$log_parameters['platform_type'] = $this->sanitize_xss($details['platform_type']);
		$log_parameters['login_via']   	 = $this->sanitize_xss($details['login_via']);
		$log_parameters['device_id']   	 = $this->sanitize_xss($details['device_id']);
		$log_parameters['ip_address']    = $this->sanitize_xss($details['ip_address']);

		$this->beginTxn();
		$is_log_added =  $this->performDBUpdate(self::ADD_USER_LOG_SQL, $log_parameters);
		if ($is_log_added) {
			$this->commitTxn();
		} else {
			$this->rollBackTxn();
		}
		$response = [
			'is_log_added'   => $is_log_added,
		];
		return $response;
	}
	public function updateOrderTransaction(array $details)
	{
		$response = [
			'is_updated'  => false,
		];
		$is_updated     = false;
		$user_id 		   = 0;
		$order_parameters = [];

		$order_parameters['order_id']                = $this->sanitize_xss($details['order_id']);
		$order_parameters['online_payment_confirm']  = $this->sanitize_xss($details['online_payment_confirm']);
		$order_parameters['pay_transaction_id']      = $this->sanitize_xss($details['pay_transaction_id']);
		$order_parameters['status']                  = 'Confirm';
		$this->beginTxn();


		$user_sql = "SELECT OrderId FROM order_master WHERE OrderId=:order_id";
		$order = $this->executeSQL(
			$user_sql,
			[
				'order_id' => $order_parameters['order_id'],
			],
			true
		);

		if (!is_null($order) && !empty($order)) {
			$is_updated = $this->performDBUpdate(self::UPDATE_ORDER_CONFIRM_SQL, $order_parameters);

			if ($is_updated) {
				$this->commitTxn();
			} else {
				$this->rollBackTxn();
			}
		}
		$response = [
			'is_updated'  => $is_updated,
		];

		return $response;
	}
}
