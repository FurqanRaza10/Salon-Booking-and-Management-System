<?php
date_default_timezone_set("Asia/Kolkata");



define("DBHOST", "localhost");
define("DBUSER", "root");
define("DBPASS", "");
define("DBNAME", "salon_booking");
define('DBDRIVER', 'mysql');

?>