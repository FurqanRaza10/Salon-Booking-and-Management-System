<?php
namespace Inspire\Api;

include_once __DIR__.'/../class/CoreDataService.php';
include_once __DIR__.'/../lib/collection/Collection.php';
include_once __DIR__.'/../class/app_config.php';
include_once __DIR__.'/../class/Response.php';
use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use \stdClass;


class ApiService extends CoreDataService
{
  
   public function __construct()
   {
       parent::__construct();
       
   }
   public function countCategoryItem($category_id)
   {
      $count = "0";
      $category_sql = 'SELECT COUNT(*) as Total_item FROM item_master WHERE IsActive=:is_active AND CategoryNo=:CategoryNo';
      $category_params = [
       'is_active' => 1,
       'CategoryNo' => $this->sanitize_xss($category_id)
      ];
      $category_detail = $this->executeSQL($category_sql,$category_params,true);
      if(!is_null($category_detail) && !empty($category_detail) && $category_detail['Total_item'] > 0)
      {
          $count =  $category_detail['Total_item'];
          return $count;
      }
      return $count;
   }
   public function getHomePageDetail($user_id)
   {
     global $app_path;

     $result = [];
     /* START Category List*/
     $category_sql = 'SELECT CategoryNo as id,CategoryName_Text as CategoryName,ImagePath,ImagePathExt FROM dishes_types WHERE Status=:status';
     $category_params = [
       'status' => 1
     ];
     $category_detail = $this->executeSQL($category_sql,$category_params);

     $category_list = [];
     foreach ($category_detail as $key => $value) {

        $category_list[$key] = $value;
        $category_list[$key]['count'] = $this->countCategoryItem($value['id']);
        if($value['ImagePath'] !=''){
          /*$category_list[$key]['ImagePath'] =  $app_path['category_img_server_url'].'/'.$value['ImagePath'];*/
         
          $category_list[$key]['ImagePath'] = $app_path['item_img_url'].'/Category/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

         $category_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_center/Category/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
          //unset($category_list[$key]['ImagePathExt']);
        }else{
          $category_list[$key]['ImagePath'] = '';
          $category_list[$key]['ImagePath_thumb'] = '';
        } 

     }
     $result['Category_list'] = $category_list;
      /* END  Category List*/

     /* START Promotion item List*/
     $product_promotions_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.ImagePathExt,im.PromotionStartDate,im.PromotionEndDate,im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im 
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status AND im.IsPromotion=:IsPromotion';
     $product_promotions_params = [
       'status'      => 1,
       'IsPromotion' => 1,
     ];
     $product_promotions_detail = $this->executeSQL($product_promotions_sql,$product_promotions_params);

     $promotion_list = [];
     $i=0;
     foreach ($product_promotions_detail as $key1 => $value1) 
     {

       if($value1['PromotionStartDate'] !='0000-00-00' && $value1['PromotionEndDate'] !='0000-00-00' && $value1['OfferPrice'] > 0)
       {
          $current_date = date("Y-m-d");
          if($value1['PromotionStartDate'] <= $current_date && $value1['PromotionEndDate'] >= $current_date)
          {

              $promotion_list[$i] = $value1;

              if($value1['ImagePath'] !=''){
               /* $promotion_list[$i]['ImagePath'] = $app_path['item_img_server_url'].'/'.$value1['ImagePath'].'.'.$value1['ImagePathExt'];
                */
              $promotion_list[$i]['ImagePath'] = $app_path['item_img_url'].'/Item/'.$value1['ImagePath'].'.'.$value1['ImagePathExt'];

              $promotion_list[$i]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value1['ImagePath'].'.'.$value1['ImagePathExt'];
                
              }else{
                 $promotion_list[$i]['ImagePath'] = '';
                 $promotion_list[$i]['ImagePath_thumb'] = '';
              } 
              unset($promotion_list[$i]['ImagePathExt']);

              $PromotionStartDate = strtotime($value1['PromotionStartDate']);  
              $PromotionEndDate = strtotime($value1['PromotionEndDate']);  
              
              $PromotionStartDate = date ("d-m-Y",$PromotionStartDate);  
              $PromotionEndDate = date ("d-m-Y",$PromotionEndDate);  
              $promotion_list[$i]['PromotionStartDate'] = $PromotionStartDate;
              $promotion_list[$i]['PromotionEndDate'] = $PromotionEndDate;

              $promotion_list[$i]['OfferPrice'] = "";
              if($value1['OfferPrice'] > 0){
                $promotion_list[$i]['OfferPrice'] = $value1['OfferPrice'];
              }

              $promotion_list[$i]['IsFavourite'] = "0";
              if($user_id !='' && $user_id > 0){
                  $is_favourite = $this->checkIsItemFavourite($user_id,$value1['id']);
                  if($is_favourite){
                      $promotion_list[$i]['IsFavourite'] = "1";
                  }
              }
              $promotion_list[$i]['itemsDetails'] = "";
              if($value1['Ingredients'] != ''){
                $promotion_list[$i]['itemsDetails'] = $value1['Ingredients'];
              }
              unset($promotion_list[$i]['Ingredients']);
              $i++;
          }
       }
     }
     $result['promotions_item_list'] = $promotion_list;
    /* END Promotion item List*/

     /* START New Arrival item List*/
     $product_new_arrival_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.ImagePathExt,DATE_FORMAT(im.PromotionStartDate, "%d-%m-%Y") as PromotionStartDate, DATE_FORMAT(im.PromotionEndDate, "%d-%m-%Y") as PromotionEndDate, im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im 
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status AND im.IsNewArrival=:IsNewArrival';
     $product_new_arrival_params = [
       'status'       => 1,
       'IsNewArrival' => 1
     ];

     

     $product_new_arrival_detail = $this->executeSQL($product_new_arrival_sql,$product_new_arrival_params);
     $new_arrival_list = [];
     foreach ($product_new_arrival_detail as $key => $value) {
        $new_arrival_list[$key] = $value;
        if($value['ImagePath'] !=''){
          /*$new_arrival_list[$key]['ImagePath'] = $app_path['item_img_server_url'].'/'.$value['ImagePath'].'.'.$value['ImagePathExt'];*/
          
          $new_arrival_list[$key]['ImagePath'] = $app_path['item_img_url'].'/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

          $new_arrival_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

          unset($new_arrival_list[$key]['ImagePathExt']);
        }else{
           $new_arrival_list[$key]['ImagePath'] = '';
           $new_arrival_list[$key]['ImagePath_thumb'] = '';
        } 
        $new_arrival_list[$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $new_arrival_list[$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $new_arrival_list[$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['id']);
            if($is_favourite){
                $new_arrival_list[$key]['IsFavourite'] = "1";
            }
        }
        $new_arrival_list[$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $new_arrival_list[$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($new_arrival_list[$key]['Ingredients']);
     }

     $result['new_arrival_item_list'] = $new_arrival_list;
    //echo "<pre>";print_r($result);die();
    /* END New Arrival item List*/  

     /* START Best Seller item List*/
     $product_best_seller_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.ImagePathExt,DATE_FORMAT(im.PromotionStartDate, "%d-%m-%Y") as PromotionStartDate, DATE_FORMAT(im.PromotionEndDate, "%d-%m-%Y") as PromotionEndDate,im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im 
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status AND im.IsBestSeller=:IsBestSeller';
     $product_best_seller_params = [
       'status'       => 1,
       'IsBestSeller' => 1
     ];
    
     $product_best_seller_detail = $this->executeSQL($product_best_seller_sql,$product_best_seller_params);
     $best_seller_list = [];
    
     foreach ($product_best_seller_detail as $key => $value) {
        $best_seller_list[$key] = $value;
        if($value['ImagePath'] !=''){
         /* $best_seller_list[$key]['ImagePath'] = $app_path['item_img_server_url'].'/'.$value['ImagePath'].'.'.$value['ImagePathExt'];*/

         $best_seller_list[$key]['ImagePath'] = $app_path['item_img_url'].'/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

          $best_seller_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
          unset($best_seller_list[$key]['ImagePathExt']);
        }else{
          $best_seller_list[$key]['ImagePath'] = '';
          $best_seller_list[$key]['ImagePath_thumb'] = '';
        } 
        $best_seller_list[$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $best_seller_list[$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $best_seller_list[$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['id']);
            if($is_favourite){
                $best_seller_list[$key]['IsFavourite'] = "1";
            }
        }
        $best_seller_list[$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $best_seller_list[$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($best_seller_list[$key]['Ingredients']);
     }

     $result['best_seller_item_list'] = $best_seller_list;
    /* END Best Seller item List*/  

     $item_list = [];
     $product_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status';
      $product_params = [
       'status'       => 1,
      ];

     $product_detail = $this->executeSQL($product_sql,$product_params);
     
     foreach ($product_detail as $key => $value) 
     {
        
        $item_list[$key] = $value;
        if($value['ImagePath'] != ''){


          $item_list[$key]['ImagePath'] =  $app_path['item_img_url']."/Item/".$value['ImagePath'].'.'.$value['ImagePathExt'];

          $item_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
                

        }else{
          $item_list[$key]['ImagePath'] = '';
          $item_list[$key]['ImagePath_thumb'] = '';
        } 
        $item_list[$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $item_list[$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $item_list[$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['id']);
            if($is_favourite){
                $item_list[$key]['IsFavourite'] = "1";
            }
        }
        $item_list[$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $item_list[$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($item_list[$key]['Ingredients']);
        unset($item_list[$key]['ImagePathExt']);
     }
      $result['item_list'] = $item_list;
      
     return $result;
   }

   public function getCategoryList()
   {
    
     $category_sql = 'SELECT CategoryNo as id,CategoryName_Text as CategoryName,ImagePath,ImagePathExt FROM dishes_types WHERE Status=:status';
     $category_params = [
       'status' => 1
     ];
     $category_detail = $this->executeSQL($category_sql,$category_params);
     $category_list = [];
     foreach ($category_detail as $key => $value) {
        $category_list[$key] = $value;
        if($value['ImagePath'] !=''){
          /*$category_list[$key]['ImagePath'] = $app_path['category_img_server_url'].'/Category/'.$value['ImagePath'].'.'.$value['ImagePathExt'];*/
        
         $category_list[$key]['ImagePath'] = $app_path['item_img_url'].'/Category/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

         $category_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_center/Category/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

         // $category_list[$key]['ImagePath'] = $app_path['item_img_url'].'/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
          //$category_list[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/c_fill,h_200,w_200/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
          //unset($category_list[$key]['ImagePathExt']);
        }else{
          $category_list[$key]['ImagePath'] = '';
          $category_list[$key]['ImagePath_thumb'] = '';
        } 
     }
     
     return $category_list;
   }
   public function getCategoryDetail($category_id)
   {
     global $app_path;

     $category_sql = 'SELECT CategoryNo as id,CategoryName_Text as CategoryName,ImagePath,ImagePathExt FROM dishes_types WHERE Status=:status AND CategoryNo=:category_id';
     $category_params = [
       'status'      => 1,
       'category_id' => $this->sanitize_xss($category_id)
     ];
     $category_detail = $this->executeSQL($category_sql,$category_params,true);

     if(!empty($category_detail)){
      if($category_detail['ImagePath'] !=''){
         /* $category_detail['ImagePath'] = $app_path['category_img_server_url'].'/'.$category_detail['ImagePath'];*/

         $category_detail['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_center/Category/'.$category_detail['ImagePath'].'.'.$category_detail['ImagePathExt'];
         $category_detail['ImagePath'] = $app_path['item_img_url'].'/Category/'.$category_detail['ImagePath'].'.'.$category_detail['ImagePathExt'];

         

        }else{
          $category_detail['ImagePath'] = '';
          $category_detail['ImagePath_thumb'] = '';
        } 
     }
     return $category_detail;
   }

   public function getProductDetailByCategoryId($category_id,$user_id)
   {
     global $app_path; 

     $product_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status AND im.CategoryNo=:category_id';
     $product_params = [
       'status'       => 1,
       'category_id'  => $this->sanitize_xss($category_id),
     ];
     $product_detail = $this->executeSQL($product_sql,$product_params);
     $result = [];
     foreach ($product_detail as $key => $value) 
     {
        $result['category_detail'][$key] =  $value;
        if($value['ImagePath'] != ''){


          $result['category_detail'][$key]['ImagePath'] =  $app_path['item_img_url']."/Item/".$value['ImagePath'].'.'.$value['ImagePathExt'];

          $result['category_detail'][$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
                

        }else{
          $result['category_detail'][$key]['ImagePath'] = '';
          $result['category_detail'][$key]['ImagePath_thumb'] = '';
        } 
        $result['category_detail'][$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $result['category_detail'][$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $result['category_detail'][$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['id']);
            if($is_favourite){
                $result['category_detail'][$key]['IsFavourite'] = "1";
            }
        }
        $result['category_detail'][$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $result['category_detail'][$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($result['category_detail'][$key]['Ingredients']);
        unset($result['category_detail'][$key]['ImagePathExt']);
     }
     return $result;
   }
   public function checkIsItemFavourite($user_id,$item_id)
   {
      $favourite_sql = 'SELECT * FROM favourite 
                    WHERE Status=:status AND(Item_Id=:item_id AND CustomerNo=:user_id)';
      $favourite_params = [
       'status'      => 1,
       'item_id'     => $this->sanitize_xss($item_id),
       'user_id'     => $this->sanitize_xss($user_id)
      ];
      $favourite_detail = $this->executeSQL($favourite_sql,$favourite_params,true);
      if(!is_null($favourite_detail) && !empty($favourite_detail)){
          return true;
      }
      return false;
   }
   public function getCategoryWiseItemList($category_id,$user_id)
   {
      $result = [];
      $categories_list = $this->getCategoryDetail($this->sanitize_xss($category_id));
      $result = $categories_list;
      if(!is_null($categories_list) && !empty($categories_list)){
          $result['count'] = $this->countCategoryItem($categories_list['id']);
      }
      
      $category_detail = $this->getProductDetailByCategoryId($categories_list['id'],$user_id);
      if(!is_null($category_detail) && !empty($category_detail))
      {
        $result['category_detail'] = $category_detail['category_detail'];
      }else{
        $result['category_detail'] = [];
      }
      
      return $result;  
   } 
   public function verifyPicode($details)
   {
       $pincode_sql = 'SELECT Pincode FROM pincode_master 
                      WHERE Status=:status AND Pincode=:pincode';
       $pincode_params = [
         'status'      => 1,
         'pincode'     => $this->sanitize_xss($details['pincode'])
       ];
       $pincode_detail = $this->executeSQL($pincode_sql,$pincode_params,true);
       if(!empty($pincode_detail)){
          return true;
       }
       return false;
   } 
   public function getCustomerProfileDetail($user_detail)
   {  
       $user_id   = isset($user_detail['user_id']) ? $user_detail['user_id'] : 0;
       
       $user_sql = 'SELECT CustomerNo,CustomerName,MobileNo,Email,CN_Netamount,DATE_FORMAT(BirthDay,"%d-%m-%Y") as BirthDate,Gender,RegisterBy FROM customer WHERE Status=:status AND CustomerNo=:user_id';//change by haidar on 02/09/2021
       $user_params = [
         'status'      => 1,
         'user_id'     => $this->sanitize_xss($user_id)
       ];
       $user_detail = $this->executeSQL($user_sql,$user_params,true);

       if(!empty($user_detail))
       {
         if($user_detail['MobileNo'] == '' || $user_detail['MobileNo'] == NULL){
              $user_detail['MobileNo'] = '';
         }
          if($user_detail['CustomerName'] == '' || $user_detail['CustomerName'] == NULL){
              $user_detail['CustomerName'] = '';
         }
          if($user_detail['Email'] == '' || $user_detail['Email'] == NULL){
              $user_detail['Email'] = '';
         }
         if($user_detail['BirthDate'] == '' || $user_detail['BirthDate'] == NULL){
              $user_detail['BirthDate'] = '';
         }
         if($user_detail['Gender'] == '' || $user_detail['Gender'] == NULL){
              $user_detail['Gender'] = '';
         }
         if($user_detail['RegisterBy'] == '' || $user_detail['RegisterBy'] == NULL){
              $user_detail['RegisterBy'] = '';
         }
         return $user_detail;
       }
    return false;
   }

   public function getCustomerOrderHistory($user_id)
   {  
      global $app_path;
      $user_sql = 'SELECT * FROM order_master
                   WHERE CustomerNo=:user_id 
                   GROUP BY OrderId ORDER BY OrderNo DESC';
      $user_params = [
         'user_id'                    =>  $this->sanitize_xss($user_id)
      ];
      $user_detail = $this->executeSQL($user_sql,$user_params);               
      
      $result = [];
      foreach ($user_detail as $key => $row) 
      {
            $order_date = date("d",strtotime($row["Date"]))." ".date("M",strtotime($row["Date"])).", ".date("g:i A",strtotime($row["Date"]));

            $result[$key]['order_id']           = $row['OrderId'];
            $result[$key]['reference_id']       = $row['ReferenceId'];
            $result[$key]['order_date']         = $order_date;
            $result[$key]['name']               = $row['Name'];
            $result[$key]['mobile_no']          = $row['MobileNo'];
            if ($row['OrderStatus'] == "Confirm") {
              $order_status = "Confirmed";
            }elseif ($row['OrderStatus'] == "On The Way") {
              $order_status = "Out For Delivery";
            }
            elseif ($row['OrderStatus'] == "Preparing") {
              $order_status = "Processing Orders";
            }
            else{
              $order_status = $row['OrderStatus'];
            }

            $result[$key]['status']             = $order_status;
            $result[$key]['address1']           = $row['Address1'];
            //$result[$key]['address2']           = $row['Address2'];
            $result[$key]['landMark']           = $row['LandMark'];
            $result[$key]['address_type']       = $row['AddressType'];
            $result[$key]['payment_type']       = $row['PaymentType'];
            $result[$key]['delivery_type']      = $row['DeliveryType'];
            $result[$key]['pay_transaction_id'] = $row['PayTransactionId'];
            $result[$key]['order_cancel_reason']= $row['OrderCancelReason'];
            $result[$key]['platform_type']      = $row['PlatformType'];
            $result[$key]['instruction']        = $row['Instruction'];
            $result[$key]['gst']                = $row['Gst'];
            $result[$key]['delivery_charge']    = $row['DeliveryCharge'];
            $result[$key]['coupon_amount']      = $row['CouponAmount'];
            $result[$key]['cn_amount_use']      = $row['CN_amount_use'];//change by haidar on 7/9/2021 9:30 pm
            

            $order_item_detail_sql = 'SELECT om.ItemNo,om.Quantity,om.Price,om.OrderId,im.ImagePath,im.ItemName_Text,im.ImagePathExt,im.ItemNo,om.Gst,om.DeliveryCharge 
              FROM order_master as om
              LEFT JOIN item_master im ON im.ItemNo=om.ItemNo  
              WHERE om.OrderId=:order_id';
             $order_item_params = [
               'order_id'     => $row['OrderId']
             ];
             $order_items = $this->executeSQL($order_item_detail_sql,$order_item_params);
             
             $sub_total_amount = 0;
             $total_item = 0;
             foreach ($order_items as $key1 => $item) 
             {    
                $image_path = '';
                if($item['ImagePath'] != '' || $item['ImagePath'] != NULL){
                   /* $image_path = $app_path['item_img_server_url'].'/'.$item['ImagePath'].'.'.$item['ImagePathExt'];*/

                     $image_path = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

                }
                $itemsdetails = [
                        'ItemNo'          => $item['ItemNo'],
                        'ItemName'        => $item['ItemName_Text'],   
                        'Price'           => $item['Price'],
                        'Quantity'        => $item['Quantity'],
                        'ImagePath'       => $image_path
                ];

                $result[$key]['OrderItems'][$key1] = $itemsdetails;
                $total_item       += $item['Quantity'];
                $sub_total_amount += $item['Price'] * $item['Quantity'];
            }
            $result[$key]['total_item'] = strval(number_format($total_item,2, '.', ''));
            $result[$key]['sub_total'] =  strval(number_format($sub_total_amount,2, '.', ''));

            $after_coupon_amount = (float)$sub_total_amount-(float)$row['CouponAmount'];
            
            $gst                = $after_coupon_amount * (float)$row['Gst']/100;
            $net_amount         = $after_coupon_amount + (float)$gst + (float)$row['DeliveryCharge'] - (float)$row['CN_amount_use']; // chnage by haidar 9/9/2021

           $result[$key]['total_gst']   = strval(number_format($gst,2, '.', ''));
           $result[$key]['net_amount']  = strval(number_format($net_amount,2, '.', ''));
           
           //[start] change by haidar on 09/06/2021 4:15pm
            $cn_details_sql="SELECT CN_Remarks,CN_Amount FROM credit_note WHERE CN_orderRefId=:ReferenceId and CustomerNo=:user_id";
                  
            $cn_details_params = [
              'ReferenceId'    => $result[$key]['reference_id'],
              'user_id'        =>  $this->sanitize_xss($user_id)
            ]; 

            $cn_details = $this->executeSQL($cn_details_sql,$cn_details_params);
            // print_r($cn_details);
            $cn_remarks = "";
            $cn_amount = "";
            foreach($cn_details as $key1 => $detail){
              $cn_remarks = $detail['CN_Remarks'];
              $cn_amount = $detail['CN_Amount'];
            }
            if ($cn_remarks == "") {
                $cn_remarks = "";
            }
            if ($cn_amount == "") {
                $cn_amount = "";
            }
            $result[$key]['cn_remarks'] = $cn_remarks;
            $result[$key]['cn_amount']  = $cn_amount;
            
            //[end]   change by haidar on 09/06/2021  
      }   
      
      return $result;
       
   }
     //[start] change by haidar on 05/09/2021
   public function getCreditNotesList($user_id){
    $cn_list_sql = "SELECT * FROM credit_note WHERE CustomerNo=:user_id ORDER BY CN_Id DESC";
    $cn_params = [
      'user_id' => $this->sanitize_xss($user_id)
    ];

    $get_cn_list = $this->executeSQL($cn_list_sql,$cn_params);

    $result = [];

    foreach ($get_cn_list as $key => $row) {
        $order_date = date("d",strtotime($row["CN_GenerateDate"]))." ".date("M",strtotime($row["CN_GenerateDate"]))." ".date("Y",strtotime($row["CN_GenerateDate"]));
        $result[$key]['Date'] = $order_date;
        $result[$key]['CN_Generated_in_OrderId'] = $row['CN_orderRefId'];
        $result[$key]['Original_CN_amount'] = $row['CN_Amount'];
        $result[$key]['Remaining_Amount'] = $row['CN_Remainning_amount'];
        $result[$key]['Used_in_OrderId'] = $row['CN_usedOrderRefId'];

    }

    return $result;
   }
   //[end] change by haidar on 05/09/2021
   public function getCustomerAddressList($user_id)
   {  
     $address_sql = 'SELECT AddressId as address_id,CustomerNo as user_id,Name as apartment,Address1 as address,UnitNo as unitno,Pincode as post_code,Latitude as latitude,Longitude as longitude
      FROM address_book where CustomerNo=:user_id';
     $address_params = [
       'user_id'     => $this->sanitize_xss($user_id)
     ];
     $address_detail = $this->executeSQL($address_sql,$address_params);
     return $address_detail;
   }
   public function getContactList()
   {  
     $contact_sql = 'SELECT CNo,Name,ContactNo,Email,Comment as Address FROM contact_us_master where Status=:status';
     $contact_params = [
       'status'     => 1
     ];
     $contact_detail = $this->executeSQL($contact_sql,$contact_params);
     return $contact_detail;
   }   

   public function getShopDetail()
   {  
     $shop_sql = 'SELECT RestaurantName as ShopName,Address,Landmark,City,Pincode,State,Nationality,Latitude,Longitude,Gst,DeliveryCharge,RestaurantTimeFrom as StartTime,RestaurantTimeTo as ToTime,HomeDelivery,TakeAway,PaymentCOD,PaymentOnline,Km as DeliveryKM,DeliverTime,GstNo,MinBillAmount,RestOpenClose,CustomerCareNo FROM restaurant_list where Status=:status AND RestaurantId=1';
     $shop_params = [
       'status'     => 1
     ];
     $shop_detail = $this->executeSQL($shop_sql,$shop_params);
     return $shop_detail;
   }
   public function getFavouriteList($user_id)
   {  
     global $app_path; 
     $favourite_sql = 'SELECT fv.SrNo,im.ItemNo,fv.Item_Id,
     cm.CategoryName_Text as CategoryName,im.ItemName_Text as ItemName,
     im.Price_Text as Price,OfferPrice_Text as OfferPrice,
     im.ImagePath,im.IsOutOfStock,im.IsPromotion,
     im.IsNewArrival,im.IsBestSeller,
     im.ImagePathExt,im.Ingredients
     FROM favourite as fv
     LEFT JOIN item_master as im ON im.ItemNo = fv.Item_Id
     LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
     WHERE im.IsActive=:status AND fv.Status=:status AND fv.CustomerNo=:user_id';
     $favourite_params = [
       'user_id'   => $this->sanitize_xss($user_id),
       'status'    => 1
     ];
      
     $favourite_detail = $this->executeSQL($favourite_sql,$favourite_params);

      $result = [];
     foreach ($favourite_detail as $key => $value) 
     {
        $result[$key] =  $value;
        if($value['ImagePath'] != ''){
       /*   $result[$key]['ImagePath'] =  $app_path['item_img_server_url']."/".$value['ImagePath'].'.'.$value['ImagePathExt'];*/

          $result[$key]['ImagePath'] =  $app_path['item_img_url']."/Item/".$value['ImagePath'].'.'.$value['ImagePathExt'];

          $result[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];

        }else{
          $result[$key]['ImagePath'] = '';
          $result[$key]['ImagePath_thumb'] = '';
        } 
        $result[$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $result[$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $result[$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['Item_Id']);
            if($is_favourite){
                $result[$key]['IsFavourite'] = "1";
            }
        }
        $result[$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $result[$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($result[$key]['Ingredients']);
        unset($result[$key]['ImagePathExt']);

     }

     return $result;

   }
    public function calculateCouponAmount($coupon_code)
    { 
      $coupon_code_sql = "SELECT SrNo as id,CouponCode as Coupon_Code,CouponMaxAmount as Coupon_Amount,StartDate as Aplicable_Date,EndDate as Expiry_Date,Status
      FROM coupon_code WHERE CouponCode = :coupon_code AND Status=1";
      $coupon_details = $this->executeSQL($coupon_code_sql,['coupon_code' => $this->sanitize_xss($coupon_code)],true);
      if(is_null($coupon_details))
           $coupon_details = new Collection([]);
        else
           $coupon_details = new Collection($coupon_details);
      return $coupon_details;
    }
     public function calculateCouponAmountPrivate($coupon_code)
    { 
      $coupon_code_sql = "SELECT SrNo,CouponName,CouponPercentage,CouponCode as Coupon_Code,CouponMaxAmount as Coupon_Amount,CouponTitle,CouponDetails,CouponCondition,StartDate as StartDate,EndDate as EndDate,Status
      FROM coupon_code WHERE CouponCode = :coupon_code AND Status=1 AND IsPublic=1";
      $coupon_details = $this->executeSQL($coupon_code_sql,['coupon_code' => $this->sanitize_xss($coupon_code)],true);
      if(is_null($coupon_details))
           $coupon_details = new Collection([]);
        else
           $coupon_details = new Collection($coupon_details);
      return $coupon_details;
    }
   public function checkCouponCode($coupon_code_detail)
   {  
      $current_date   = date('Y-m-d');
     //echo $current_date;die();
      $coupon_details = $this->calculateCouponAmount($this->sanitize_xss($coupon_code_detail['coupon_code']));
      if (is_null($coupon_details['Coupon_Code']) === TRUE) {
        $error_messages = new Collection([]);
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, 'Invalid Promo Code', $error_messages->values());
        exit;
      }
    // print_r($coupon_details['Aplicable_Date']);die();
      if ($coupon_details['Aplicable_Date'] > $current_date) {
        $error_messages = new Collection([]);
         $Aplicable_Date = strtotime($coupon_details['Aplicable_Date']);          
         $Aplicable_Date = date ("d-m-Y",$Aplicable_Date);  

        $error_msg = 'Promo code will be applicable after '.$Aplicable_Date;
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, $error_msg, $error_messages->values());
        exit;
      }
      if ($coupon_details['Expiry_Date'] < $current_date) {
        $error_messages = new Collection([]);
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, 'Your Promo code is expired', $error_messages->values());
        exit;
      }

       $coupon_user_sql = 'SELECT * FROM coupon_user WHERE CouponCode=:couponCode 
                             AND CustomerNo=:user_id';

       $coupon_user_params = [
         'user_id'       => $this->sanitize_xss($coupon_code_detail['user_id']),
         'couponCode'    => $this->sanitize_xss($coupon_code_detail['coupon_code']),
       ];
       $coupon_user_detail = $this->executeSQL($coupon_user_sql,$coupon_user_params,true);
       if(!empty($coupon_user_detail))
       {
          $error_messages = new Collection([]);
          $error_messages->set('coupon_details', new stdClass()); 
          $coupon_details['Payable_Amount'] = $this->sanitize_xss($coupon_code_detail['payable_amount']);
          $coupon_details['Is_Coupon_Used_By_This_User'] = true;
          echo Response::generateJSONResponse(400, 'This Promo code is already used.', $error_messages->values());
          exit;
       }else
       {
          if($coupon_details['Coupon_Amount']){
            $total_payable_amount = $this->sanitize_xss($coupon_code_detail['payable_amount']) - $coupon_details['Coupon_Amount'];
          }else{
            $total_payable_amount = $this->sanitize_xss($coupon_code_detail['payable_amount']);
          }
          
          $coupon_details['Payable_Amount'] = $total_payable_amount;
          $coupon_details['Is_Coupon_Used_By_This_User'] = false;
          echo Response::generateJSONResponse(200, 'Promo Code', array('coupon_details' => $coupon_details->values()));
          exit;
       }
   }
   public function checkCouponCodePrivate($coupon_code_detail)
   {  
      $current_date   = date('Y-m-d');
      $coupon_details = $this->calculateCouponAmountPrivate($this->sanitize_xss($coupon_code_detail['coupon_code']));
      unset($coupon_details['Status']);
      if (is_null($coupon_details['Coupon_Code']) === TRUE) {
        $error_messages = new Collection([]);
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, 'Invalid Promo Code', $error_messages->values());
        exit;
      }
      if ($coupon_details['StartDate'] > $current_date) {
        $error_messages = new Collection([]);
         $Aplicable_Date = strtotime($coupon_details['StartDate']);          
         $Aplicable_Date = date ("d-m-Y",$Aplicable_Date);  

        $error_msg = 'Promo code will be applicable after '.$Aplicable_Date;
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, $error_msg, $error_messages->values());
        exit;
      }
      if($coupon_details['EndDate'] < $current_date) {
        $error_messages = new Collection([]);
        $error_messages->set('coupon_details', new stdClass());
        echo Response::generateJSONResponse(400, 'Your Promo code is expired', $error_messages->values());
        exit;
      }
      
       $coupon_user_sql = 'SELECT * FROM coupon_user WHERE CouponCode=:couponCode 
                             AND CustomerNo=:user_id';
       $coupon_user_params = [
         'user_id'       => $this->sanitize_xss($coupon_code_detail['user_id']),
         'couponCode'    => $this->sanitize_xss($coupon_code_detail['coupon_code']),
       ];
       $coupon_user_detail = $this->executeSQL($coupon_user_sql,$coupon_user_params,true);
        if(!empty($coupon_user_detail))
        {
          //$coupon_details['Payable_Amount'] = $this->sanitize_xss($coupon_code_detail['payable_amount']);
          //$coupon_details['Is_Coupon_Used_By_This_User'] = true;
          //echo Response::generateJSONResponse(200, 'Promo Code', array('is_used_by_this_user' => true));
          $error_messages = new Collection([]);
          $error_messages->set('coupon_details', new stdClass()); 
          echo Response::generateJSONResponse(400, 'This Promo code is already used.', $error_messages->values());
          exit;
        }else
        {
          if($coupon_details['Coupon_Amount']){
            $total_payable_amount = $this->sanitize_xss($coupon_code_detail['payable_amount']) - $coupon_details['Coupon_Amount'];
          }else{
            $total_payable_amount = $this->sanitize_xss($coupon_code_detail['payable_amount']);
          }
          
         // $coupon_details['Payable_Amount'] = $total_payable_amount;
         // $coupon_details['Is_Coupon_Used_By_This_User'] = false;
          echo Response::generateJSONResponse(200, 'Promo Code', array('coupon_details' => $coupon_details->values()));
          exit;
       }
   }
   public function CouponCodeList()
   {  
     $coupon_code_sql = 'SELECT SrNo,CouponName,CouponCode,CouponPercentage,CouponMaxAmount,CouponTitle,CouponDetails,CouponCondition,StartDate,EndDate,IsPublic
      FROM coupon_code 
      WHERE status=:status AND(StartDate <=:date_today AND EndDate >=:date_today) AND IsPublic=:is_public';

     $coupon_code_params = [
       'status'     => 1,
       'date_today' => date('Y-m-d'),
       'is_public'  => 0
     ];
     $coupon_code_detail = $this->executeSQL($coupon_code_sql,$coupon_code_params);
     return $coupon_code_detail;
   }
   public function calculateCartItems($details)
   { 
      $sub_total = 0;
      $net_total = 0;
      if(isset($details['item_details'])){
        if($details['item_details'] != ''){
          $myArray = explode(',', $details['item_details']);

          foreach($myArray as $key) 
          { 
            $ItemSplitSpace = explode(' ',$key);

                  $ItemNo     = $ItemSplitSpace[0];
                  $Quantity     = $ItemSplitSpace[1];   
                  $Price      = $ItemSplitSpace[2];   
                  $sub_total   += (float)$Price * (float)$Quantity;
              }
        }
      }

      $result['sub_total'] = $sub_total;
      if($details['coupon_amount'] > 0){
          $net_total = $sub_total - $details['coupon_amount'];
      }
      $result['sub_total']     =  $sub_total;
      $result['coupon_amount'] =  $details['coupon_amount'];
      $result['net_total']     =  $net_total;
     
      return $result;
   }
   public function checkUserId($user_id)
   {  
     $user_sql = 'SELECT CustomerNo,Password FROM customer WHERE CustomerNo=:user_id';

     $user_params = [
       'user_id'   => $this->sanitize_xss($user_id),
     ];
     $user_detail = $this->executeSQL($user_sql,$user_params,true);
     return $user_detail;
   }
   public function getProductDetailBySearchString($search_string,$user_id)
   {
     global $app_path; 
     $search_string = $this->sanitize_xss($search_string);
     $product_sql = 'SELECT im.ItemNo as id,im.ItemName_Text as ItemName,cm.CategoryName_Text as CategoryName,im.Price_Text as Price,im.OfferPrice_Text as OfferPrice,im.ImagePath,im.IsOutOfStock,im.IsPromotion,im.IsNewArrival,im.IsBestSeller,im.ImagePathExt,im.Ingredients
       FROM item_master as im
       LEFT JOIN dishes_types as cm ON cm.CategoryNo = im.CategoryNo
       WHERE im.IsActive=:status AND im.ItemName_Text LIKE :search_string';
      $product_params = [
       'status'       => 1,
       'search_string'       =>"%".$search_string."%",
      ];

     $product_detail = $this->executeSQL($product_sql,$product_params);
     $result = [];
     foreach ($product_detail as $key => $value) 
     {
        $result[$key] =  $value;
        if($value['ImagePath'] != ''){


          $result[$key]['ImagePath'] =  $app_path['item_img_url']."/Item/".$value['ImagePath'].'.'.$value['ImagePathExt'];

          $result[$key]['ImagePath_thumb'] = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$value['ImagePath'].'.'.$value['ImagePathExt'];
                

        }else{
          $result[$key]['ImagePath'] = '';
          $result[$key]['ImagePath_thumb'] = '';
        } 
        $result[$key]['OfferPrice'] = "";
        if($value['OfferPrice'] > 0){
          $result[$key]['OfferPrice'] = $value['OfferPrice'];
        }
        $result[$key]['IsFavourite'] = "0";
        if($user_id !='' && $user_id > 0){
            $is_favourite = $this->checkIsItemFavourite($user_id,$value['id']);
            if($is_favourite){
                $result[$key]['IsFavourite'] = "1";
            }
        }
        $result[$key]['itemsDetails'] = "";
        if($value['Ingredients'] != ''){
          $result[$key]['itemsDetails'] = $value['Ingredients'];
        }
        unset($result[$key]['Ingredients']);
        unset($result[$key]['ImagePathExt']);
     }
    
     return $result;
   }
   public function getUSerDetailByEmailORMobile($details)
   {
        $mobile = '';
        if($details['type_login'] == 'Email'){
          $sql = 'Email=:mobile';
          $mobile = $this->sanitize_xss($details['email_or_mobile']);  
        }
        if($details['type_login'] == 'Mobile'){
          $sql = 'MobileNo=:mobile';
          $mobile = ltrim($this->sanitize_xss($details['email_or_mobile']), "0");  
        }
        

        $auth_sql = 'SELECT CustomerNo,MobileNo,Email FROM customer WHERE '.$sql.'';
        $user = $this->executeSQL($auth_sql,['mobile' => $mobile],true);
         
        if(!is_null($user) || !empty($user))
        {
          return $user['CustomerNo'];
        }
      return 0;
   }
  
//[start] change by haidar on 12/09/2021
    
    public function getCartList($customer_Id)
    {
        global $app_path;
        $cart_list_sql = "SELECT * FROM table_cart
        WHERE Customer_Id=:customer_Id
        GROUP BY Customer_Id ORDER BY Cart_Id ASC";
        $cart_params = [
        'customer_Id' => $this->sanitize_xss($customer_Id)
        ];
        
        $get_cart_list = $this->executeSQL($cart_list_sql,$cart_params);
        
        $result = [];
        
        foreach ($get_cart_list as $key => $row) {
            $result[$key]['customer_id'] = $row['Customer_Id'];
            
            // for get items list
            $cart_item_detail_sql = "SELECT im.ItemNo,im.ImagePath,im.ImagePathExt,im.ItemName_Text,im.Price_Text,im.OfferPrice_Text,im.IsActive,im.IsDeleted,im.IsOutOfStock,tc.Quantity,tc.Customer_Id,tc.Item_Id,tc.Quantity FROM table_cart as tc INNER JOIN item_master as im ON tc.Item_Id=im.ItemNo WHERE tc.Customer_Id=:customer_Id";
            $cart_item_params = [
            'customer_Id'     => $row['Customer_Id']
            ];
            
            $get_cart_item_detail = $this->executeSQL($cart_item_detail_sql,$cart_item_params);
            $sub_total_amount = 0;
            $to_pay = 0;
            
            foreach ($get_cart_item_detail as $key1 => $item) {
              
              	//[start] change by haidar on 24/09/2021
              	if ($item['IsActive'] == 0 || $item['IsDeleted'] == 1 || $item['IsOutOfStock'] == 1) {
                    $is_deleted = $this->performDBUpdate("DELETE from  table_cart  where Item_Id=:Product_Id",
                    [
                      'Product_Id' => $item['ItemNo'],
                    ]);
                }
              	else
                {
                  $image_path = '';
                  if($item['ImagePath'] != '' || $item['ImagePath'] != NULL){
                      /* $image_path = $app_path['item_img_server_url'].'/'.$item['ImagePath'].'.'.$item['ImagePathExt'];*/

                      $image_path = $app_path['item_img_url'].'/w_200,h_200,c_fill,g_auto/Item/'.$item['ImagePath'].'.'.$item['ImagePathExt'];

                  }

                  $item_price = $item['Price_Text'];
                  if($item['OfferPrice_Text'] != 0){
                      $item_price = $item['OfferPrice_Text'];
                  }

                  $items_details = [
                  'item_no' => $item['ItemNo'] ,
                  'item_name' => $item['ItemName_Text'],
                  'price' => $item_price,
                  'quantity' => $item['Quantity'],
                  'sub_total'   => number_format((float)$item_price * (float)$item['Quantity'],2, '.', ''),
                  'image_path' => $image_path,
                   'image_name' => $item['ImagePath']
                  ];

                  $sub_total_amount += $item_price * $item['Quantity'];
                  $result[$key]['item_list'][$key1] = $items_details;
                }
              	//[end] change by haidar on 24/09/2021
                
            }
            
            $result[$key]['address_id'] = $row['AddressId'];
            // for get adderss
            $address_sql = 'SELECT AddressId as address_id,CustomerNo as user_id,Name as apartment,Address1 as address,UnitNo as unitno,Pincode as post_code,Latitude as latitude,Longitude as longitude
            FROM address_book where AddressId=:AddressId';
            $address_params = [
            'AddressId'     => $row['AddressId']
            ];
            $address_detail = $this->executeSQL($address_sql,$address_params);
            $result[$key]['address'] = $address_detail;
            //[start] change by haidar on 29/9/2021
            if ($get_cart_list[0]['PickupDate'] < date("d-m-Y")) {
              $this->performDBUpdate("UPDATE table_cart SET PickupDate=:pickup_date,PickupSlot=:pickup_slot WHERE Customer_Id=:customer_Id",
              [
                'pickup_date'     => "",
                'pickup_slot'     => "",
                'customer_Id'     => $customer_Id,
              ]);
              $result[$key]['pickup_date'] = "";
              $result[$key]['pickup_slot'] = "";
            }
            else {
              $result[$key]['pickup_date'] = $row['PickupDate'];
              $result[$key]['pickup_slot'] = $row['PickupSlot'];
            }
            //[end] change by haidar on 29/9/2021
            $result[$key]['instruction'] = $row['Instruction'];
            
            // for coupon code
            
            $coupon_code_sql = 'SELECT SrNo,CouponName,CouponCode,CouponPercentage,CouponMaxAmount,CouponTitle,CouponDetails,CouponCondition,StartDate,EndDate,IsPublic
            FROM coupon_code
            WHERE SrNo=:promo_id';
            
            $coupon_code_params = [
            'promo_id' => $row['Promo_Id']
            ];
            $coupon_code_detail = $this->executeSQL($coupon_code_sql,$coupon_code_params);
          	$result[$key]['Coupon_detail'] = [];
            if (!empty($coupon_code_detail)) {
                foreach ($coupon_code_detail as $key2 => $details) {
                    $coupon_code_list = [
                    'sr_no' => $details['SrNo'],
                    'coupon_name' => $details['CouponName'],
                    'coupon_code'  => $details['CouponCode'],
                    'coupon_percentage'  => $details['CouponPercentage'],
                    'coupon_max_amount'  => $details['CouponMaxAmount'],
                    'coupon_title'  => $details['CouponTitle'],
                    'coupon_details'  => $details['CouponDetails'],
                    'coupon_condition'  => $details['CouponCondition'],
                    'coupon_condition'  => $details['CouponCondition'],
                    'start_date'  => $details['StartDate'],
                    'end_date'  => $details['EndDate'],
                    'is_public'  => $details['IsPublic'],
                    
                    ];
                     //[start] change by haidar on 29/9/2021
                    if ($details['EndDate'] < date("Y-m-d")) {
                      $this->performDBUpdate("UPDATE table_cart SET Promo_Id=:promo_id WHERE Customer_Id=:customer_Id",
                      [
                        'promo_id'     => "",
                        'customer_Id'     => $customer_Id,
                      ]);
                    }
                    else {
                      $result[$key]['Coupon_detail'][$key2] = $coupon_code_list;
                      $promo_amount = number_format($details['CouponPercentage']*$sub_total_amount/100,2, '.', '');
                      
                      if($promo_amount >= $details['CouponMaxAmount']) {
                          $promo_amount = $details['CouponMaxAmount'];
                      }
                    }
                    //[end] change by haidar on 29/9/2021
                  
                }
            }
            
            
            $result[$key]['item_total']    = number_format($sub_total_amount,2, '.', '');
            
            $result[$key]['promo_amount'] = "0.00";
            if (isset($promo_amount)) {
                $result[$key]['promo_amount']    = $promo_amount;
            }
            $sub_total_amount -= $result[$key]['promo_amount'];
            $to_pay +=  $sub_total_amount;
            // delivery_charge subtraction from item total
            $result[$key]['delivery_charge'] = "0.00";
            if ($row['AddressId'] != "") {   // change by haidar on 30-09-2021
              $delivery_charge = "SELECT DeliveryCharge,MinBillAmount FROM restaurant_list WHERE Status=:status";
              $delivery_charge_details = $this->executeSQL($delivery_charge,['status' => 1]);
              if ($sub_total_amount < $delivery_charge_details[0]['MinBillAmount']) {
                  $to_pay += $delivery_charge_details[0]['DeliveryCharge'];
                  $result[$key]['delivery_charge'] = $delivery_charge_details[0]['DeliveryCharge'];
              }
            }
            
            
            // for credit_notes
            $get_credit_notes = "SELECT CN_Netamount FROM customer WHERE CustomerNo=:customer_Id";
            $credit_notes = $this->executeSQL($get_credit_notes,
                                              [
                                              'customer_Id'     => $row['Customer_Id']
                                              ]);
            $result[$key]['cn_netamount'] = $credit_notes[0]['CN_Netamount'];
            $cn_use_in = 0;
            if ($credit_notes[0]['CN_Netamount'] == 0) {
                $cn_use_in += 0;
            }
            elseif ($credit_notes[0]['CN_Netamount'] <= $to_pay) {
                $cn_use_in += $credit_notes[0]['CN_Netamount'];
            }
            else {
                $cn_use_in += $to_pay;
            }
            $to_pay -= $cn_use_in;
            // for cn_remaining_amount
            $cn_remanining = $credit_notes[0]['CN_Netamount'] - $cn_use_in;
            $result[$key]['cn_use_in'] =   number_format($cn_use_in,2, '.', '');
            $result[$key]['cn_remaining_amount'] =   number_format($cn_remanining,2, '.', '');
            $result[$key]['to_pay']    = number_format($to_pay,2, '.', '');
            
        }
        
        return $result;
        
    }
    //[end] change by haidar on 12/09/2021	

}
?>
