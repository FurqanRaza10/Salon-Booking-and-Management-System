<?php
namespace Inspire\Ahms\Application\Utils\Notification;

class PushNotifier
{
    const SHOULD_SEND_SMS = true;
    private static $SERVER_KEY = 'AAAAE0s3pnA:APA91bGBTvVvgeP4u2LRnV5ChUEku1bHKXj0fTYPxdQ-lEavT6yccnRYMIERCuKDBXUODNtpEwTpTrxNdBZ5R6XnmxfByS1MEcO0lFWwgcUe8s0fXv8QgAAjvNdkO3MUMiOGQIKdeKAT';
    public static function firePushNotificationforPriceChange($notification_detail)
    {
        $body = '{
              "notification":{
              "title": "'.$notification_detail['message_title'].'",
              "text":  "'.$notification_detail['message_text'].'",
              "sound" : "default",
              "click_action": "OPEN_ACTIVITY_1"
            },
            "to" : "'.$notification_detail['device_token'].'"
        }';
        self::executeAPI($body);
    }


    /**
    *  Call API
    *
    *  @param $body
    *
    * @return API response
    */
    private static function executeAPI( $body )
    {
        if (self::SHOULD_SEND_SMS){
            $ch = curl_init();
      			curl_setopt($ch, CURLOPT_URL, "https://fcm.googleapis.com/fcm/send");
      			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      			curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json","Authorization:key=".self::$SERVER_KEY));
      			curl_setopt($ch, CURLOPT_POST, 1);
      			curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
      			$result = curl_exec($ch);
            //var_dump($result);
      			return $result;
        }else {
            return null;
        }
    }//end of execute API
}//end of class

?>
