<?php

namespace Inspire\Api;

include_once __DIR__ . '/../class/CoreDataService.php';
include_once __DIR__ . '/../lib/collection/Collection.php';
include_once __DIR__ . '/../class/app_config.php';
include_once __DIR__ . '/../class/Response.php';

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use \stdClass;


class ApiService extends CoreDataService
{

  public function __construct()
  {
    parent::__construct();
  }
  public function getCategoryList()
  {
    global $app_path;
    $category_sql = 'SELECT * FROM category_master WHERE status=:status LIMIT 6';
    $category_params = [
      'status' => 1
    ];
    $category_detail = $this->executeSQL($category_sql, $category_params);
    $category_list = [];
    foreach ($category_detail as $key => $value) {
      $category_list[$key] = $value;
      if ($value['img_path'] != '') {

        $category_list[$key]['img_path'] = $app_path['item_img_url'] . '/Category/' . $value['img_path'];
      } else {
        $category_list[$key]['img_path'] = '';
      }
    }

    return $category_list;
  }
  public function getPopularSalon()
  {
    global $app_path;

    $popular_salon_sql = "SELECT * FROM salon_master as sm INNER JOIN rating_table as rt ON sm.salon_id=rt.salon_id WHERE sm.is_active=:status AND rt.ratting=5 OR rt.ratting=4";
    $popular_salon = $this->executeSQL($popular_salon_sql, ['status' => 1]);

    $popular_salon_list = [];

    foreach ($popular_salon as $key => $value) {

      $popular_salon_list[$key] = $value;
      if ($value['img_path'] != '') {
        $popular_salon_list[$key]['img_path'] = $app_path['item_img_url'] . '/Category/' . $value['img_path'];
        $popular_salon_list[$key]['logo_path'] = $app_path['item_img_url'] . '/Category/' . $value['logo_path'];
      } else {
        $popular_salon_list[$key]['img_path'] = '';
        $popular_salon_list[$key]['logo_path'] = '';
      }
    }

    return $popular_salon_list;
  }
  public function getAllCategoryList()
  {
    global $app_path;
    $category_sql = 'SELECT * FROM category_master WHERE status=:status';
    $category_params = [
      'status' => 1
    ];
    $category_detail = $this->executeSQL($category_sql, $category_params);
    $category_list = [];
    foreach ($category_detail as $key => $value) {
      $category_list[$key] = $value;
      if ($value['img_path'] != '') {

        $category_list[$key]['img_path'] = $app_path['item_img_url'] . '/Category/' . $value['img_path'];
      } else {
        $category_list[$key]['img_path'] = '';
      }
    }

    return $category_list;
  }
  public function getAllSalon()
  {
    global $app_path;

    $all_salon_sql = "SELECT * FROM salon_master as sm INNER JOIN rating_table as rt ON sm.salon_id=rt.salon_id WHERE sm.is_active=:status;";
    $all_salon = $this->executeSQL($all_salon_sql, ['status' => 1]);

    $all_salon_list = [];

    foreach ($all_salon as $key => $value) {

      $all_salon_list[$key] = $value;
      if ($value['img_path'] != '') {
        $all_salon_list[$key]['img_path'] = $app_path['item_img_url'] . '/Category/' . $value['img_path'];
        $all_salon_list[$key]['logo_path'] = $app_path['item_img_url'] . '/Category/' . $value['logo_path'];
      } else {
        $all_salon_list[$key]['img_path'] = '';
        $all_salon_list[$key]['logo_path'] = '';
      }
    }
    return $all_salon_list;
  }
}
