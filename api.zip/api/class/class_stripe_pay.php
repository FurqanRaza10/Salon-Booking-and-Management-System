<?php
include_once __DIR__.'/../vendor/stripe/stripe-php/init.php';



// This is a sample test API key. Sign in to see examples pre-filled with your key.
//\Stripe\Stripe::setApiKey('sk_live_VlYydPColHm9fQDVd0WLdcq4006Jjwudmd');//Live Key

\Stripe\Stripe::setApiKey('sk_test_IYStT7UlEwzD6razk31G3tFH00xVzEqQRq');//Test Key


function calculateOrderAmount(array $items){
  // Replace this constant with a calculation of the order's amount
  // Calculate the order total on the server to prevent
  // customers from directly manipulating the amount on the client
  return 1400;
}


?>