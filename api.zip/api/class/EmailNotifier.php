<?php
namespace Inspire\Ahms\Application\Utils\Notification;
include_once __DIR__.'/../vendor/autoload.php';



/**
* This class will help to send email with gievn data
*/
class EmailNotifier
{
	/**
	 * PHPMailer type
	 * @var PHPMailer
	 */
	private  $mail;

	public function __construct()
	{
		
	}
	public static function sendOtpEmail($email,$otp)
	{   
		//$guzzleClient = new \GuzzleHttp\Client(['verify' => false]);
		$subject="OTP Verification";
		$body = $otp.' is your OTP for user registration at Salon Hub.';
		$header= "From: hschaudhary06@gmail.com";

		if (mail($email,$subject,$body,$header)) {
           return true;
		}else{
			return false;
		}
		// $subject = 'OTP Verification';
		// $to = $email;
		// $content = $otp.' is your OTP for user registration at Salon Hub Salon platform.';

		// $key = 'SG.DAI_-sjATa2xPSSMwHjiCg.fyGmsxAGKcDIMyfNImoAwKsNB1fXYDIdFoMKS5N8AZY';

	    // $email = new \SendGrid\Mail\Mail();
	    // $email->setFrom("hschaudhary06@gmail.com","Salon Hub");
	    // $email->setSubject($subject);
	    // $email->addTo($to);
	    // $email->addContent("text/plain",$content);
	    // $sendgrid = new \SendGrid($key);
	    // try{
	    // 	$response = $sendgrid->send($email);
	    // 	// echo '<pre>';print_r($response);die();
	    // 	return $response;
	    // }catch(Exception $e){
	    // 	// echo 'Email Caught exception'.$e->getMessage()."\n";
	    // 	return false;
	    // }
	}
	public static function sendOrdersConfirmationFromAdminToCustomerEmail($email,$subject,$msg)
	{   
		//$guzzleClient = new \GuzzleHttp\Client(['verify' => false]);

		$subject = $subject;
		$to = $email;
		$content = $msg;

		$key = 'SG.DAI_-sjATa2xPSSMwHjiCg.fyGmsxAGKcDIMyfNImoAwKsNB1fXYDIdFoMKS5N8AZY';

	    $email = new \SendGrid\Mail\Mail();
	    $email->setFrom("info@sunrisefresh.com.au","Sunrise Fresh");
	    $email->setSubject($subject);
	    $email->addTo($to);
	    $email->addContent("text/plain",$content);
	    $sendgrid = new \SendGrid($key);
	    try{
	    	$response = $sendgrid->send($email);
	    	//echo '<pre>';print_r($response);die();
	    	return $response;
	    }catch(Exception $e){
	    	//echo 'Email Caught exception'.$e->getMessage()."\n";
	    	return false;
	    }
	}
    public static function sendNotificationEmail($email,$msg)
	{   
		//$guzzleClient = new \GuzzleHttp\Client(['verify' => false]);

		$subject = 'Notification';
		$to = $email;
		$content = $msg;

		$key = 'SG.DAI_-sjATa2xPSSMwHjiCg.fyGmsxAGKcDIMyfNImoAwKsNB1fXYDIdFoMKS5N8AZY';

	    $email = new \SendGrid\Mail\Mail();
	    $email->setFrom("info@sunrisefresh.com.au","Sunrise Fresh");
	    $email->setSubject($subject);
	    $email->addTo($to);
	    $email->addContent("text/plain",$content);
	    $sendgrid = new \SendGrid($key);
	    try{
	    	$response = $sendgrid->send($email);
	    	//echo '<pre>';print_r($response);die();
	    	return $response;
	    }catch(Exception $e){
	    	//echo 'Email Caught exception'.$e->getMessage()."\n";
	    	return false;
	    }
	}
  
}