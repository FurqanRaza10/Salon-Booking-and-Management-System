<?php
namespace Inspire\Ahms\Application\Utils\Notification;
include_once __DIR__.'/../vendor/autoload.php';
include_once __DIR__.'/../class/app_config.php';
/**
* Use queue to notify via sms
* so queue will process in background to send sms notification
*/
class SMSNotifier
{
  

  public function __construct()
  {
    
  }
    
    
  public static function sendOtpSms($mobile,$mobile_pin)
  {
      global $app_api_key;
      
      // Live API Key
       $messagebird = new \MessageBird\Client($app_api_key['OTP_LIVE_API_KEY']);


      // Test API Key
      //$messagebird  = new \MessageBird\Client($app_api_key['OTP_TEST_API_KEY']);

      //$messagebird = new MessageBird\Client($app_api_key['OTP_TEST_API_KEY']);
      $message = new \MessageBird\Objects\Message;
    
      $message->originator = 'SunriseFrsh';
      $message->recipients = '+61'.$mobile;

      $msg = $mobile_pin.' is your OTP for user registration at Sunrise Fresh Online shopping platform.';

      $message->body =  $msg;
      $response = $messagebird->messages->create($message);
      //echo '<pre>';print_r($response);die();
  }  
  public static function sendOwnerSMS($mobile,$message_string)
  {
      global $app_api_key;
      // Live API Key
       $messagebird = new \MessageBird\Client($app_api_key['OTP_LIVE_API_KEY']);
      // Test API Key
      //$messagebird  = new \MessageBird\Client($app_api_key['OTP_TEST_API_KEY']);
      
      $message = new \MessageBird\Objects\Message;
      $message->originator = 'SunriseFrsh';
      $message->recipients = '+61'.$mobile;
      $msg = $message_string;
      $message->body =  $msg;
      $response = $messagebird->messages->create($message);
      //echo '<pre>';print_r($response);die();
  }
}
