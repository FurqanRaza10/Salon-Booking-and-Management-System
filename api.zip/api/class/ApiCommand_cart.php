<?php
namespace Inspire\Api;
include_once __DIR__.'/CoreDataService.php';
include_once __DIR__.'/SMSNotifier.php';
include_once __DIR__.'/EmailNotifier.php';
include_once __DIR__.'/PushNotification.php';
include_once __DIR__.'/PushNotifier.php';

date_default_timezone_set('Australia/NSW');

use Inspire\Ahms\Application\Utils\CoreDataService;
use Inspire\Ahms\Application\Utils\Notification\SMSNotifier;
use Inspire\Ahms\Application\Utils\Notification\EmailNotifier;
use Inspire\Ahms\Application\Utils\Notification\PushNotifier;
use stdClass;
/**
 */
class ApiCommand extends CoreDataService 
{
	const ADD_SIGNUP_WITH_SOCIAL_SQL = 'INSERT INTO customer(CustomerNo,CustomerName,Email,Token,OtpCode,RegisterBy) VALUES (NULL,:name,:email,:token,:mobile_otp,:type)';

	const ADD_SIGNUP_SQL = 'INSERT INTO customer(CustomerNo,CustomerName,Email,MobileNo,Password,Token,OtpCode) VALUES (NULL,:name,:email,:mobile,:password,:token,:mobile_otp)';

	const ADD_SIGNUP_WITH_MOBILE_SQL = 'INSERT INTO customer(CustomerNo,MobileNo,Gender,Token,OtpCode) VALUES (NULL,:mobile,:gender,:token,:mobile_otp)';

	const UPDATE_PROFILE_SQL = 'UPDATE customer SET CustomerName=:name,Email=:email,Gender=:gender,MobileNo=:mobile,Address=:address,BirthDay=:birthday 
		WHERE CustomerNo=:user_id';


/*
	const ADD_CUSTOMER_ADDRESS_SQL = 'INSERT INTO address_book(AddressId,Name,Address1,Address2,LandMark,Pincode,MobileNo,AddressType,Latitude,Longitude,CustomerNo,DefaultStatus) VALUES (NULL,:name,:address1,:address2,:landmark,:pincode,:mobile_no,:address_type,:user_lat,:user_long,:user_id,1)';*/

	const ADD_CUSTOMER_ADDRESS_SQL = 'INSERT INTO address_book(AddressId,Name,Pincode,Address1,UnitNo,CustomerNo,DefaultStatus,Latitude,Longitude) VALUES (NULL,:apartment,:postcode,:address,:unitno,:user_id,1,:latitude,:longitude)';

	const UPDATE_SET_ADDRESS_SQL = 'UPDATE address_book SET DefaultStatus=:status WHERE CustomerNo=:user_id AND AddressId=:address_id';

	const UPDATE_ADDRESS_SQL = 'UPDATE address_book 
		SET Name=:apartment,Address1=:address,UnitNo=:unitno,Pincode=:postcode,Latitude=:latitude,
		Longitude=:longitude WHERE CustomerNo=:user_id AND AddressId=:address_id';

	const ADD_FAVOURITE_SQL = 'INSERT INTO favourite(SrNo,Item_Id,CustomerNo) VALUES (NULL,:product_id,:user_id)';

	const ADD_ORDER_SQL = 'INSERT INTO order_master(`OrderNo`, `CustomerNo`, `AddressId`, `ItemNo`,`Price`, `Quantity`, `Date`, `OrderId`,`Gst`,`DeliveryCharge`,`Name`,`Address1`,`Pincode`,`AddressType`,`Latitude`,`Longitude`,`MobileNo`,`CouponCode`,`CouponAmount`,`PaymentType`,`DeliveryType`,`PayTransactionId`,`Status`,`RestaurantId`,`RestaurantName`,`RestaurantAddress`,`PlatformType`,`Instruction`,`CN_amount_use`,`ReferenceId`,`OnlinePaymentConfirm`,`Pickup_Slot`,`OrderStatus`) 

	VALUES (NULL,:user_id,:address_id,:item_no,:price,:quantity,:dates,:max_order_id,:gst,:delivery_charge,:name,:address1,:pincode,:address_type,:latitude,:longitude,:mobile_no,:coupon_code,:coupon_amount,:payment_type,:delivery_type,:transaction_id,:status,:restaurant_id,:shop_name,:shop_address,:platform_type,:instruction,:credit_amount_use,:reference_id,:payment_confirm,:pickup_slot,:order_status)';// change by haidar

	const UPDATE_DEVICE_TOKEN_SQL = 'UPDATE customer SET DeviceFirebaseToken=:device_firebase_token,Platform=:platform WHERE CustomerNo=:user_id';

	const UPDATE_OTP_SQL = 'UPDATE customer SET OtpCode=:otp WHERE CustomerNo=:user_id';
	
	const ADD_CONTACT_SQL = 'INSERT INTO contact_us_master(CNo,Name,ContactNo,Email,Comment,Platform,Status,Purpose) VALUES (NULL,:name,:contact_number,:email,:comment,:platform,1,:purpose)';

	const ADD_NOTIFICAION_SQL = 'INSERT INTO notification_detail(id,Product_id,User_Id,Type,Item_Price,Platform) VALUES (NULL,:product_id,:user_id,:type,:item_price,:platform)';

	const UPDATE_OTP_EMAIL_SQL = 'UPDATE customer SET OtpCode=:otp WHERE Email=:email_or_mobile';
    const UPDATE_OTP_MOBILE_SQL = 'UPDATE customer SET OtpCode=:otp WHERE MobileNo=:email_or_mobile';

    const ADD_SEARCH_SQL = 'INSERT INTO product_category_search(`ID`, `Date`, `CategoryID`, `ItemID`,`UserID`)
	VALUES (NULL,:dates,:category_id,:item_id,:user_id)';

	const ADD_USER_LOG_SQL = 'INSERT INTO log_master(id,user_id,user_type,platform_type,login_via,device_id,ip_address) VALUES (NULL,:user_id,:user_type,:platform_type,:login_via,:device_id,:ip_address)';
  
    const UPDATE_ORDER_CONFIRM_SQL = "UPDATE order_master SET OrderStatus=:status,OnlinePaymentConfirm=:online_payment_confirm,PayTransactionId=:pay_transaction_id
                                              WHERE OrderId=:order_id AND OrderStatus='Pending'";
	public function __construct() {
		parent::__construct ();
		
	}


	public function confirmOrder(array $details) {
		
		$response = [
			'is_order_added'    => false,
			'is_order_message'  => false,
		];
		$is_order_added  = false;
		
		
	    $setting_sql = "SELECT * FROM restaurant_list WHERE RestaurantId=:RestaurantId AND RestOpenClose=:RestOpenClose";
        $setting = $this->executeSQL($setting_sql,
		[
		  'RestOpenClose' => 1,
		  'RestaurantId' => 1,
		],true);

        if(!is_null($setting) && !empty($setting))
        {

        	$shop_owner_mobile_no = $setting['MobileNo'];
    		$latitude 			  = $setting['Latitude'];
    		$longitude			  = $setting['Longitude'];
    		$gst 				  = $setting['Gst'];
    		$shop_name 	          = $setting['RestaurantName'];
    		$shop_address         = $setting['Address'];
    		$deliver_time 		  = $setting['DeliverTime'];
    		$delivery_charge 	  = $setting['DeliveryCharge'];
            
            
           		$is_valid_amount = $this->count_order_total_amount($details,$delivery_charge);
        	
	        	if($details['delivery_type'] == "Delivery" && $is_valid_amount == false)
	        	{
					$response = [
						'is_order_added'  => false,
						'is_order_message'  => 'Your order amount value is less then $ '.$setting['MinBillAmount']." so you can't make order.",
						'Orderid'  => 0,
					];
					return $response;
				}

        		$this->beginTxn();
        		//max order id
				$order_max_sql = "SELECT Max(OrderId) As OrderId FROM order_master";
		        $max_order_id = $this->getSingleValue($order_max_sql,'OrderId');
			    if($max_order_id > 0){ $max_order_id = $max_order_id + 1;  
			    }else{ $max_order_id = 1;}

			    //max reference id
				$order_refer_max_sql= "SELECT Max(ReferenceId) As ReferenceId FROM order_master";
		        $max_reference_id = $this->getSingleValue($order_refer_max_sql,'ReferenceId');
			    if($max_reference_id > 0){ $max_reference_id = $max_reference_id + 1;  
			    }else{ $max_reference_id = 101;}

			  // get address
          
          
			    $name = ""; $unit_no = "";  $address1 = ""; $address2 = ""; $landmark = ""; 
			    $pincode = ""; $mobile_no = ""; $address_type = ""; 
			   
			    $address_detail = $this->order_address_detail_by_address_id_and_user_id($details);
	    		if(!empty($address_detail))
	    		{
	    			 $name 		  	= $address_detail['Name'];
					 $unit_no    	= $address_detail['UnitNo'];
					 $address1    	= $address_detail['Address1'];
					 $address2    	= $address_detail['Address2'];
					 $landmark    	= $address_detail['LandMark'];
					 $pincode     	= $address_detail['Pincode'];
					 $mobile_no    	= $address_detail['MobileNo'];
					 $address_type 	= $address_detail['AddressType'];
	    		}
	    		if(!empty($address1)) {
	    		    if (!empty($unit_no)) {
	    		        $unit_no = $unit_no.', ';
	    		    }
					$address1 = $unit_no.$address1.', '.$pincode;
		    	}
          
          
          
	    		/*if($address1 == "" || empty($address1)){	
					$address_r_sql = "SELECT * FROM customer WHERE CustomerNo=:user_id";
			        $address_r = $this->executeSQL($address_r_sql,['user_id'=>$this->sanitize_xss($details['user_id'])],true);
				    if(!empty($address_r)){		  
				        $mobile_no 	= $address_r['MobileNo'];
				        $name 		= $address_r['CustomerName'];	
				        $address1   = $name.','.$address1.','.$pincode;		
	    			}
				}	*/

				if($details['delivery_type'] == "Collect"){
	            	$delivery_charge= 0;
	            }
	            
	            $user_sql = "SELECT CustomerNo,CustomerName FROM customer WHERE CustomerNo=:user_id";
			    $user = $this->executeSQL($user_sql,['user_id' => $this->sanitize_xss($details['user_id'])],true);
			    //echo "<pre>";print_r($user);die();
				 if(!is_null($user) && !empty($user))
				{

					$order_sql = "SELECT Count(*) as rowCount FROM order_master WHERE ReferenceId=:reference_id";
			    	$orderIfExist = $this->executeSQL($order_sql,['reference_id' =>$this->sanitize_xss($max_reference_id)],true);

					if($orderIfExist['rowCount'] > 0 ){
						$noOfRecord = true;
						$IsMsgSent  = false;
					}
					else
					{
						$myArray = explode(',', $details['item_details']);
						$order_items_list = [];
						foreach($myArray as $key) 
						{ 
				 	 		$ItemSplitSpace = explode(' ',$key);
	                        $ItemNo 		= $ItemSplitSpace[0];
	                        $Quantity 		= (float)$ItemSplitSpace[1];   
	                        $Price 			= (float)$ItemSplitSpace[2];   

                        	$order_parameters = [ ];
	
					        $order_parameters['user_id']   	 		= $this->sanitize_xss($details['user_id']);
							$order_parameters['address_id']  		= $this->sanitize_xss($details['address_id']);
							$order_parameters['item_no'] 			= $ItemNo;
							$order_parameters['price']  			= $Price;
							$order_parameters['quantity']  			= $Quantity;
							$order_parameters['dates']  			= date("Y-m-d H:i:s");
							$order_parameters['max_order_id']  		= $max_order_id;
							$order_parameters['gst']  				= $gst;
							$order_parameters['delivery_charge']    = 0;
							if($details['is_delivery_charge']  == 'Yes'){
								$order_parameters['delivery_charge']  	= $delivery_charge;
							}
							$order_parameters['name']    			= $user['CustomerName'];
							$order_parameters['address1']    		= $address1;
							$order_parameters['pincode']    		= $pincode;
							$order_parameters['address_type']    	= $address_type;
							$order_parameters['latitude']    		= $latitude;
							$order_parameters['longitude']    		= $longitude;
							$order_parameters['mobile_no']    		= $mobile_no;
							$order_parameters['coupon_code']    	= $this->sanitize_xss($details['coupon_code']);
							$order_parameters['coupon_amount']    	= $this->sanitize_xss($details['coupon_amount']);
							$order_parameters['payment_type']    	= $this->sanitize_xss($details['payment_type']);
							$order_parameters['delivery_type']    	= $this->sanitize_xss($details['delivery_type']);
							$order_parameters['transaction_id']    	= $this->sanitize_xss($details['transaction_id']);
							$order_parameters['status']    			= 1;
							$order_parameters['restaurant_id']    	= 1;
							$order_parameters['shop_name']    	    = $shop_name;
							$order_parameters['shop_address']    	= $shop_address;
							$order_parameters['platform_type']    	= $this->sanitize_xss($details['platform_type']);
							$order_parameters['instruction']    	= $this->sanitize_xss($details['instruction']);
							$order_parameters['reference_id']    	= $max_reference_id;
							$order_parameters['payment_confirm']    = $this->sanitize_xss($details['online_payment_confirm']);
							$order_parameters['pickup_slot']        = $this->sanitize_xss($details['pickup_slot']);
							$process_to_checkout_amount = $this->sanitize_xss($details['process_to_checkout_amount']);//change by haidar 8/9/2021
							//$order_parameters['order_status']       = 'Confirm';
                            $order_parameters['order_status']  = 'Pending';
                            /*Pending*/
                            //[start] change by haidar on 8/9/2021
                            
							if($order_parameters['payment_confirm'] == 'No' && $process_to_checkout_amount == '0.00')
							{
							    $order_parameters['order_status']= 'Confirm';
							}
							    
						
							
						    //[end] change by haidar on 8/9/2021

							//[start] change by haidar on 7/9/2021
							 if(!empty($this->sanitize_xss($details['credit_amount'])))
                            {
                            	$order_parameters['credit_amount_use']=$this->sanitize_xss($details['credit_amount']);
                            }
                             else{
                            	$order_parameters['credit_amount_use']=$this->sanitize_xss($details['credit_amount']);
                             
                            }
                            	//[end] change by haidar on 7/9/2021
							
							$order_items_list[]   = $order_parameters;
							
						}
						
						//[start] change by haidar on 02/09/2021

						$credit_amount		= $this->sanitize_xss($details['credit_amount']);
						

						if ($credit_amount!="") {

							$creditNote_parameters = [ ];
							$creditNote_parameters['credit_amount'] = $this->sanitize_xss($details['credit_amount']);
							$creditNote_parameters['user_id'] = $this->sanitize_xss($details['user_id']);
							$creditNote_parameters['reference_id'] = $max_reference_id;
							
							$row_sql = "SELECT CN_Netamount FROM customer WHERE CustomerNo=:CustomerNo";
		    				$row = $this->executeSQL($row_sql,['CustomerNo'=>$this->sanitize_xss($details['user_id'])],true);



		    				if ($row['CN_Netamount']!=0) {
									$this->performDBUpdate("UPDATE customer SET CN_Netamount = CN_Netamount - :credit_amount WHERE CustomerNo=:user_id",['credit_amount' =>$this->sanitize_xss($details['credit_amount']),'user_id' =>$this->sanitize_xss($details['user_id'])]);
							
								while($credit_amount!=0){



									$row_sql = "SELECT * FROM credit_note WHERE CustomerNo=:CustomerNo and Is_used=0";
		    						$row = $this->executeSQL($row_sql,['CustomerNo'=>$this->sanitize_xss($details['user_id'])],true);

                                   
								if($credit_amount<=$row['CN_Remainning_amount']) // if credit_Amt <= remainning Amt particular CN_Id
								{

									// done for update remainning amount in CN  
									//when blank have in CN_usedOrderRefId then don't use CONCAT function simple assign reference_id  
									if(empty($row['CN_usedOrderRefId'])){
										$this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount = CN_Remainning_amount -:credit_amount,CN_usedOrderRefId =:reference_id WHERE CN_Id=:cnId and Is_used=0",array("credit_amount"=>$credit_amount,"reference_id"=> $max_reference_id,"cnId"=>$row['CN_Id']));

									}
									else{
										$this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount = CN_Remainning_amount -:credit_amount,CN_usedOrderRefId = CONCAT(CN_usedOrderRefId,',',:reference_id) WHERE CN_Id=:cnId and Is_used=0",array("credit_amount"=>$credit_amount,"reference_id"=> $max_reference_id,"cnId"=>$row['CN_Id']));
									}

									// done for flag change 
									$this->performDBUpdate("UPDATE credit_note set Is_used=:isused where CN_Id=:cnId and CN_Remainning_amount=:remainning_amt",array("isused"=>1,"cnId"=>$row['CN_Id'],"remainning_amt"=>0));
							        $credit_amount=0;


								}
								else                                        // else  credit_Amt > remainning Amt particular CN_Id
								{
								    
								    	$row_sql = $this->executeSQL("SELECT CN_Remainning_amount from credit_note where CN_Id=:cnid",['cnid'=>$row['CN_Id']],true);

									  $credit_amount=   $credit_amount - $row_sql['CN_Remainning_amount'];

                                 	 $this->performDBUpdate("UPDATE credit_note SET CN_Remainning_amount =:credit_amount,CN_usedOrderRefId = CONCAT(CN_usedOrderRefId,',',:reference_id),Is_used=1 WHERE CN_Id=:cnId",array("credit_amount"=>0.00,"reference_id"=> $max_reference_id,"cnId"=>$row['CN_Id'])); 
										
								}




									
								}
							
		    					

		    				}

							

						}
						
						//[end]change by haidar on 02/09/2021

						$is_order_added = $this->performBatchUpdate(self::ADD_ORDER_SQL,$order_items_list);
						if($is_order_added){
                          	//[start] change by haidar on 21/09/2021 
                          	if($process_to_checkout_amount == '0.00' ){
                                

                                //when order is confirmed then delete item from table_cart
                                    $item_delete_sql = "DELETE FROM table_cart WHERE Customer_Id=:user_id";
                                    $item_parameters = 
                                    [
                                        'user_id' => $this->sanitize_xss($details['user_id']),
                                    ];	
                                    $this->performDBUpdate($item_delete_sql,$item_parameters);

                                
                            }
                          	//[end] change by haidar on 21/09/2021 
                         	$this->commitTxn();
 							$this->coupon_code_add_in_user_master($details);	


 							$row_sql = "SELECT OrderId,ReferenceId FROM order_master WHERE CustomerNo=:CustomerNo AND AddressId=:AddressId GROUP By OrderId ORDER BY OrderNo Desc LIMIT 1";
		    				$row = $this->executeSQL($row_sql,['CustomerNo'=>$this->sanitize_xss($details['user_id']),'AddressId'=>$this->sanitize_xss($details['address_id'])],true);

				        	if (!empty($row)) {	
		                        $new_order_no   = $row["OrderId"];
				        	}

		                    if($this->sanitize_xss($details['address_id']) == "" || $this->sanitize_xss($details['address_id']) == "0"){ 
		                    	//Take away
		                    	/*$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order, Your order will be ready within ".$deliver_time." mins. So, Please visit our Sunrise Fresh and collect your parcel after ".$deliver_time." mins.",
									'Orderid'  => $new_order_no,
								];*/
								$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order.",
									'Orderid'  => $new_order_no,
								];
				        	}else{
				        	   //Home delivery
				        		/*$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order, Sunrise Fresh will initiate processing of your order within ".$deliver_time." minutes.",
									'Orderid'  => $new_order_no,
								];*/
								$response = [
									'is_order_added'  => true,
									'is_order_message'  => "Sunrise Fresh has received your order.",
									'Orderid'  => $new_order_no,
								];
				        	}
				        	$this->sendSMSToOwner($new_order_no);	
                        }
	                    else
						{
							$this->rollBackTxn();
							$response = 
							[
								'is_order_added'  => false,
								'is_order_message'  => "Error in place your order",
								'Orderid'  => 0,
							];
						}
					}
				}
        	
        	
		}
		else{
			$response = [
				'is_order_added'  => false,
				'is_order_message'  => "Sunrise Fresh is closed, you can't make order.",
				'Orderid'  => 0,
			];
		}
		return $response;
	}

     public function updateOrderTransaction(array $details){
	    $response = [
			'is_updated'  => false,
		];
		$is_updated     = false;
		$user_id 		   = 0;
		$order_parameters = [ ];
		
        $order_parameters['order_id']                = $this->sanitize_xss($details['order_id']);
        $order_parameters['online_payment_confirm']  = $this->sanitize_xss($details['online_payment_confirm']);
        $order_parameters['pay_transaction_id']      = $this->sanitize_xss($details['pay_transaction_id']);
        $order_parameters['status']                  = 'Confirm';
		$this->beginTxn();
		

        $user_sql = "SELECT OrderId,CustomerNo FROM order_master WHERE OrderId=:order_id";
        $order = $this->executeSQL($user_sql,
		[
		  'order_id' => $order_parameters['order_id'],
		],true);

        if(!is_null($order) && !empty($order))
        {
          	//[start] change by haidar on 21/09/2021 
				
                //	when order is confirmed then delete item from table_cart
                $item_delete_sql = "DELETE FROM table_cart WHERE Customer_Id=:user_id";
                $item_parameters = 
                [
                    'user_id' => $order['CustomerNo'],
                ];	
                $this->performDBUpdate($item_delete_sql,$item_parameters);

            //[end] change by haidar on 21/09/2021
        	$is_updated = $this->performDBUpdate(self::UPDATE_ORDER_CONFIRM_SQL,$order_parameters);
			
			if ($is_updated) {
				$this->commitTxn();
			}
			else{
				$this->rollBackTxn();
			}
        } 
		$response = [
			'is_updated'  => $is_updated,
		];

		return $response;
	}
	//[start] change by haidar on 12/09/2021 9:59am
	public function addCartItems(array $details)
	{
		$is_added = false;
		$is_updated = false;
		$is_deleted = false;
		$response = [
			'is_added' => false,
			'is_updated' => false,
			'is_deleted' => false,
			'is_exist' => false,
		];

		$address_id = $this->sanitize_xss($details['address_id']);
		$cart_parameters = [ ];
		
		$cart_parameters['customer_Id'] = $this->sanitize_xss($details['customer_id']);
		$cart_parameters['AddressId']   = $address_id;
		$cart_parameters['PickupSlot']  = $this->sanitize_xss($details['pickup_slot']);
		$cart_parameters['PickupDate']  = $this->sanitize_xss($details['pickup_date']);
		$cart_parameters['promo_id']  	= $this->sanitize_xss($details['promo_id']);
		$cart_parameters['instruction'] = $this->sanitize_xss($details['instruction']);


		$this->beginTxn();

		$result_item = $this->executeSQL("SELECT * from item_master where ItemNo=:Product_Id",
		[
			'Product_Id' => $this->sanitize_xss($details['product_id']),
		],true);

		$result_customer = $this->executeSQL("SELECT * from customer where customerNo=:customer_Id",
		[
			'customer_Id' => $this->sanitize_xss($details['customer_id']),
		],true);

		if (!empty($result_item) && !empty($result_customer)) {
			
			$select_sql = $this->executeSQL("SELECT * from table_cart where Item_Id=:Product_Id and Customer_Id=:customer_Id",
			[
				'Product_Id' => $this->sanitize_xss($details['product_id']),
				'customer_Id' => $this->sanitize_xss($details['customer_id']),
			],true);

			if (!empty($select_sql)) {
				if ($this->sanitize_xss($details['quantity']) > 0) {
					// update for quntity
					$is_updated = $this->performDBUpdate("UPDATE table_cart set Quantity=:quantity
					where Item_Id=:Product_Id and Customer_Id=:customer_Id",
					[
						'quantity' => $this->sanitize_xss($details['quantity']),
						'Product_Id' => $this->sanitize_xss($details['product_id']),
						'customer_Id' => $this->sanitize_xss($details['customer_id']),
					]);
					if ($is_updated) {
						$this->commitTxn();
					}
					else{
						$this->rollBackTxn();
					}
					// update for delivery
					$is_updated = $this->performDBUpdate("UPDATE table_cart SET AddressId=:AddressId,PickupSlot=:PickupSlot,PickupDate=:PickupDate,Promo_Id=:promo_id,Instruction=:instruction
					WHERE Customer_Id=:customer_Id",$cart_parameters);
					$response = [
						'is_added' => false,
						'is_updated' => $is_updated,
						'is_deleted' => false,
					];
				}
				else{
						// delete items into cart 
					$is_deleted = $this->performDBUpdate("DELETE from  table_cart  where Item_Id=:Product_Id and Customer_Id=:customer_Id",
					[
						'Product_Id' => $this->sanitize_xss($details['product_id']),
						'customer_Id' => $this->sanitize_xss($details['customer_id']),
					]);
					if ($is_deleted) {
						$this->commitTxn();
					}
					else{
						$this->rollBackTxn();
					}
					$response = [
						'is_added' => false,
						'is_updated' => false,
						'is_deleted' => $is_deleted,
					];					
				}
			}
			else
			{
				 // insert new items in cart 
				 //[start] Change By Haidar on 1-11-2021 3:29 PM
				 $pincode_sql = 'SELECT pm.Pincode,pm.DeliveryDays FROM address_book as adr INNER JOIN pincode_master as pm ON adr.Pincode=pm.Pincode WHERE pm.Status=:status AND adr.AddressId=:AddressId';
				$pincode_params = [
				'status'      => 1,
				'AddressId'   => $address_id
				];
				$pincode_detail = $this->executeSQL($pincode_sql,$pincode_params,true);
				if($this->sanitize_xss($details['address_id'])!=""){
					if(!empty($pincode_detail)){
						if(strpos($pincode_detail['DeliveryDays'],date("l")) == false)
						{
							$response = [
								'is_added' => false,
								'is_updated' => false,
								'is_deleted' => false,
								'is_exist' => true,
								'pincode'    => $pincode_detail['Pincode']
							];
							$address_id = "";
						}
						else{
							$is_added = $this->performDBUpdate("INSERT INTO table_cart (Item_Id,Customer_Id,Quantity,AddressId,PickupSlot,PickupDate,Promo_Id,Instruction) 
							values(:Product_Id,:customer_Id,:quantity,:AddressId,:PickupSlot,:PickupDate,:promo_id,:instruction)",
							[
								'quantity' 	  => $this->sanitize_xss($details['quantity']),
								'Product_Id'  => $this->sanitize_xss($details['product_id']),
								'customer_Id' => $this->sanitize_xss($details['customer_id']),
								'AddressId'   => $address_id,
								'PickupSlot'  => $this->sanitize_xss($details['pickup_slot']),
								'PickupDate'  => $this->sanitize_xss($details['pickup_date']),
								'promo_id'    => $this->sanitize_xss($details['promo_id']),
								'instruction' => $this->sanitize_xss($details['instruction']),
							]);
							if ($is_added) {
								$this->commitTxn();
							}
							else{
								$this->rollBackTxn();
							}
							// update for delivery
							$is_updated = $this->performDBUpdate("UPDATE table_cart SET AddressId=:AddressId,PickupSlot=:PickupSlot,PickupDate=:PickupDate,Promo_Id=:promo_id,Instruction=:instruction
							WHERE Customer_Id=:customer_Id",
							$cart_parameters);
							$response = [
								'is_added' => $is_added,
								'is_updated' => false,
								'is_deleted' => false,
								'days_name'  => $pincode_detail['DeliveryDays'],
								'pincode'    => $pincode_detail['Pincode']
							];
						}
					}
				}
						$is_added = $this->performDBUpdate("INSERT INTO table_cart (Item_Id,Customer_Id,Quantity,AddressId,PickupSlot,PickupDate,Promo_Id,Instruction) 
						values(:Product_Id,:customer_Id,:quantity,:AddressId,:PickupSlot,:PickupDate,:promo_id,:instruction)",
						[
							'quantity' 	  => $this->sanitize_xss($details['quantity']),
							'Product_Id'  => $this->sanitize_xss($details['product_id']),
							'customer_Id' => $this->sanitize_xss($details['customer_id']),
							'AddressId'   => $address_id,
							'PickupSlot'  => $this->sanitize_xss($details['pickup_slot']),
							'PickupDate'  => $this->sanitize_xss($details['pickup_date']),
							'promo_id'    => $this->sanitize_xss($details['promo_id']),
							'instruction' => $this->sanitize_xss($details['instruction']),
						]);
						if ($is_added) {
							$this->commitTxn();
						}
						else{
							$this->rollBackTxn();
						}
						// update for delivery
						$is_updated = $this->performDBUpdate("UPDATE table_cart SET AddressId=:AddressId,PickupSlot=:PickupSlot,PickupDate=:PickupDate,Promo_Id=:promo_id,Instruction=:instruction
						WHERE Customer_Id=:customer_Id",
						$cart_parameters);
						$response = [
							'is_added' => $is_added,
							'is_updated' => false,
							'is_deleted' => false,
							'days_name'  => $pincode_detail['DeliveryDays'],
							'pincode'    => $pincode_detail['Pincode']
						];

				 //[end] Change By Haidar on 1-11-2021
			}

		}
		else {
						
		}
		return $response;

	} 
	//[end] change by haidar on 12/09/2021	
}

