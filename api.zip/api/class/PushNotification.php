<?php
//admin app server key (partner app server key)
define( 'ADMIN_API_ACCESS_KEY', 'AAAAE0s3pnA:APA91bGBTvVvgeP4u2LRnV5ChUEku1bHKXj0fTYPxdQ-lEavT6yccnRYMIERCuKDBXUODNtpEwTpTrxNdBZ5R6XnmxfByS1MEcO0lFWwgcUe8s0fXv8QgAAjvNdkO3MUMiOGQIKdeKAT');
function PushNotification($platform,$token,$title,$body)
{

// API access key from Google API's Console
$registrationIds = array($token);
// prep the bundle
$msg = array(
        'body'  => $body,
        'title'     => $title, //"YOUR ORDER STATUS",
        'vibrate'   => 1,
        'sound'     => "default",
        'icon' =>'1',
    ); 
    $fields = [];
    $android = "Android"; 

    if ($platform == $android) { 
        
        $fields = array(
            'registration_ids'  => $registrationIds,
            'data'              => $msg
        );
        
    } else {
        
        $fields = array(
            'registration_ids'  => $registrationIds,
            'notification'      => $msg
        );

    }
    
$headers = array(
            'Authorization: key=' . ADMIN_API_ACCESS_KEY,
            'Content-Type: application/json'
        );

$ch = curl_init();
curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
curl_setopt( $ch,CURLOPT_POST, true );
curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
$result = curl_exec($ch);
curl_close( $ch );

//echo '<pre>';print_r($result);die();
$result = json_decode($result, true);
    if($result['success'] == 1){
        return true;
    }
    return false;
}


?>