<?php
$app_path = 
[
	'item_img_url'=>"https://res.cloudinary.com/sunrise-fresh/image/upload",
	'item_img_server_url' => "https://inspiresoftware.co.in/inskart/restaurant_images/restaurant",
	'category_img_server_url' =>"https://inspiresoftware.co.in/inskart/restaurant_images/dishes"
];

$app_api_key = 
[
	'OTP_LIVE_API_KEY'=>"'wdFXg52rgNNzGBDpfSXk4lwqu'",
	'OTP_TEST_API_KEY'=>"'R6XgRNsnbgELoEJ5egNQwEOr8'",
];
?>