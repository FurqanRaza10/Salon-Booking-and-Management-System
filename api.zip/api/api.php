<?php
date_default_timezone_set('Australia/NSW');
$timestamp = date("Y-m-d H:i:s");

header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.

include_once __DIR__.'/class/app_config.php';
include_once __DIR__.'/class/Validator.php';
include_once __DIR__.'/class/Response.php';
include_once __DIR__.'/class/ApiCommand.php';
include_once __DIR__.'/class/ApiService.php';
include_once __DIR__.'/lib/collection/Collection.php';
include_once __DIR__.'/class/class_stripe_pay.php';

use Inspire\Ahms\Application\Utils\Validator;
use Inspire\Ahms\Application\Utils\Response;
use PHPR\Collection;
use Inspire\Api\ApiCommand;
use Inspire\Api\ApiService;

$error_messages = new Collection([]);
$apiCommand = new ApiCommand();
$apiService = new ApiService();


if(isset($_GET["action"]))
{

    if($_GET["action"] == "getHomeCategories" )
	{
		$category_list = $apiService->getCategoryList();
	    if(!is_null($category_list) && !empty($category_list)){
	    	echo Response::generateJSONResponse(200,"Category List.",array("category_list" => $category_list));
     	 	exit;
	    }else{
	    	echo Response::generateJSONResponse(200,"Category List.",array("category_list" =>[]));
     	    exit;
	    }
        
	}
	elseif ($_GET["action"] == "getPopularSalon") {
		$popular_salon = $apiService->getPopularSalon();
	    if(!is_null($popular_salon) && !empty($popular_salon)){
	    	echo Response::generateJSONResponse(200,"Popular Salon List",["PopularSalon" => $popular_salon]);
     	 	exit;
	    }else{
	    	echo Response::generateJSONResponse(200,"Popular Salon List",["PopularSalon" => []]);
     	    exit;
	    }
	}
	elseif($_GET["action"] == "getAllCategories" )
	{
		$category_list = $apiService->getAllCategoryList();
	    if(!is_null($category_list) && !empty($category_list)){
	    	echo Response::generateJSONResponse(200,"All Category List.",array("all_category_list" => $category_list));
     	 	exit;
	    }else{
	    	echo Response::generateJSONResponse(200,"Category List.",array("all_category_list" =>[]));
     	    exit;
	    }
        
	}
	elseif ($_GET["action"] == "getAllSalon") {
		$all_salon = $apiService->getAllSalon();
	    if(!is_null($all_salon) && !empty($all_salon)){
	    	echo Response::generateJSONResponse(200,"All Salon List",["AllSalon" => $all_salon]);
     	 	exit;
	    }else{
	    	echo Response::generateJSONResponse(200,"All Salon List",["AllSalon" => []]);
     	    exit;
	    }
	}
	elseif ($_GET["action"] == "signup") {
		$rules = 
		[
			'name'  		=> ['required'],
			'mobile' 		=> ['required'],
			'email'  		=> ['required'],
			'password'  	=> ['required'],
		];

		$validator_instance = Validator::makeValidator($_POST,$rules,true);
		if($validator_instance->isValidationFailed()){
		    //Preparing collection for error messages
		    $error_messages = new Collection($validator_instance->getErrorMessages());
		    $error_messages->set('message_title','Please correct below errors');
		    echo Response::generateJSONResponse(400,"Registration is not saved due to invalid data",$error_messages->values());
		    exit;
		}else 
		{
   
		    $user_response = $apiCommand->addSignup($_POST);
           
		    if($user_response['is_email_exist']){
	           $error_messages->set('message_title','Email  is already exist.');
	           echo Response::generateJSONResponse(500,"Unable to save Registration due to incorrect  data",$error_messages->values());
	           exit;
              
	        }

	        if($user_response['is_user_saved']){
	          echo Response::generateJSONResponse(200,"Registration successfully saved .",array("is_user_saved" => $user_response['is_user_saved'],
	          	  'user_id'     =>  $user_response['user_id'],'otp'=>$user_response['otp']));
	          exit;
	        }

	        $error_messages->set('message_title','Registration is not saved.');
	        echo Response::generateJSONResponse(500,"Unable to save Registration due to incorrect  data",$error_messages->values());
	        exit;		  	
		}
	}
	else if($_GET["action"] == "verify_otp")
	{
		$rules = 
		[
			'otp' => ['required'],
			'user_id'  	 => ['required'],
		];

		$validator_instance = Validator::makeValidator($_POST,$rules,true);
		if($validator_instance->isValidationFailed()){
		    //Preparing collection for error messages
		    $error_messages = new Collection($validator_instance->getErrorMessages());
		    $error_messages->set('message_title','Please correct below errors');
		    echo Response::generateJSONResponse(400,"Registration is not saved due to invalid data",$error_messages->values());
		    exit;
		}else 
		{
		    $user_response = $apiCommand->verifyEmailOTP($_POST);
		    if($user_response['is_verify']){
		    	echo Response::generateJSONResponse(200,"Email is Verified.",array("is_verify" => $user_response['is_verify']));
	         	 exit;
	        }
	       
	        $error_messages->set('message_title','OTP is not Verified.');
	        echo Response::generateJSONResponse(500,"Unable to Verified due to incorrect data",$error_messages->values());
	        exit;
	       
		}
	}
	else if($_GET["action"] == "login"){
		$rules = 
		[
			'username'  	=> ['required'],
			'password'  	=> ['required'],
		];
		$validator_instance = Validator::makeValidator($_POST,$rules,true);
		if($validator_instance->isValidationFailed()){
		    //Preparing collection for error messages
		    $error_messages = new Collection($validator_instance->getErrorMessages());
		    $error_messages->set('message_title','Please correct below errors');
		    echo Response::generateJSONResponse(400,"Login failed!",$error_messages->values());
		    exit;
		}else 
		{
		    $user_response = $apiCommand->login($_POST);
	        if($user_response['is_login']){
	          echo Response::generateJSONResponse(200,"Login successfull.",array("is_login" => $user_response['is_login']));
	          exit;
	        }else{
	          $error_messages->set('message_title','username or password is wrong');
	          echo Response::generateJSONResponse(500,"username or password is wrong",$error_messages->values());
	          exit;
	        }
		}


	}
    else
    {	
    
        $validator_instance = Validator::makeValidator($_POST,$rules,true);
			$error_messages = new Collection($validator_instance->getErrorMessages());
			$error_messages->set('message_title','Wrong Request');
	          echo Response::generateJSONResponse(500,"Wrong Request",$error_messages->values());
	        exit;
    }
 }

?>