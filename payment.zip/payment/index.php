<?php
require_once __DIR__ . '/../../application/utils/app_config.php';
require_once __DIR__ . '/../../application/master/get_item_details_controller.php';
require_once __DIR__ . '/../../application/utils/SessionManager.php';


use Inspire\Ahms\Application\Utils\SessionManager;

$sessionManager = new SessionManager();

// print_r($booking_item_list);
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <style>
   .payment-form{
      padding-bottom: 50px;
      font-family: 'Montserrat', sans-serif;
    }

    .payment-form.dark{
      background-color: #f6f6f6;
    }

    .payment-form .content{
      box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.075);
      background-color: white;
    }

    .payment-form .block-heading{
        padding-top: 50px;
        margin-bottom: 40px;
        text-align: center;
    }

    .payment-form .block-heading p{
      text-align: center;
      max-width: 420px;
      margin: auto;
      opacity:0.7;
    }

    .payment-form.dark .block-heading p{
      opacity:0.8;
    }

    .payment-form .block-heading h1,
    .payment-form .block-heading h2,
    .payment-form .block-heading h3 {
      margin-bottom:1.2rem;
      color: #3b99e0;
    }

    .payment-form .payment-methods {
      display: flex;
      justify-content: space-around;
      background-color: #ffffff;
      padding: 0;
      max-width: 600px;
      margin-bottom: 15px !important;
      margin: auto;
      cursor: pointer;
      
    }

    .payment-form .payment-methods div {
      padding: 10px 30px;
      background-color: #f9f9f9;
      border-radius: 8px;
      transition: background-color 0.3s ease;
      font-size: 1.2em;
      color: #555;
    }

    .payment-form .payment-methods div:hover {
      background-color: #e0e0e0;
    }

    .payment-form .payment-methods .active {
      background-color: #3b99e0;
      color: white;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    }

    .payment-form form{
      border-top: 2px solid #5ea4f3;
      box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.075);
      background-color: #ffffff;
      padding: 0;
      max-width: 600px;
      margin: auto;
    }

    .payment-form .title{
      font-size: 1em;
      border-bottom: 1px solid rgba(0,0,0,0.1);
      margin-bottom: 0.8em;
      font-weight: 600;
      padding-bottom: 8px;
    }

    .payment-form .products{
      background-color: #f7fbff;
        padding: 25px;
    }

    .payment-form .products .item{
      margin-bottom:1em;
      display: flex;
      justify-content: space-between;
    }

    .payment-form .products .item-name{
      font-weight:600;
      font-size: 0.9em;
    }

    .payment-form .products .item-description{
      font-size:0.8em;
      opacity:0.6;
    }

    .payment-form .products .item p{
      margin-bottom:0.2em;
    }

    .payment-form .products .price{
      float: right;
      font-weight: 600;
      font-size: 0.9em;
    }

    .payment-form .products .total{
      border-top: 1px solid rgba(0, 0, 0, 0.1);
      margin-top: 10px;
      padding-top: 19px;
      font-weight: 600;
      line-height: 1;
    }

    .payment-form .card-details{
      padding: 25px 25px 15px;
    }

    .payment-form .card-details label{
      font-size: 12px;
      font-weight: 600;
      margin-bottom: 15px;
      color: #79818a;
      text-transform: uppercase;
    }

    .payment-form .card-details button{
      margin-top: 0.6em;
      padding:12px 0;
      font-weight: 600;
    }

    .payment-form .date-separator{
      margin-left: 10px;
        margin-right: 10px;
        margin-top: 5px;
    }

    @media (min-width: 576px) {
      .payment-form .title {
        font-size: 1.2em; 
      }

      .payment-form .products {
        padding: 40px; 
        }

      .payment-form .products .item-name {
        font-size: 1em; 
      }

      .payment-form .products .price {
          font-size: 1em; 
      }

        .payment-form .card-details {
          padding: 40px 40px 30px; 
        }

        .payment-form .card-details button {
          margin-top: 2em; 
        } 
    }

  </style>
</head>
<body>

  
  <main class="page payment-page">
    <section class="payment-form">
      <div class="container">
        <div class="block-heading">
          <h2>Payment</h2>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in, mattis vitae leo.</p>
        </div>

        <!-- Payment Methods Toggle (Top sections for Credit Card and UPI) -->
        <div class="payment-methods">
          <div id="credit-card-tab" class="payment-method active">
            Credit Card Payment
          </div>
          <div id="upi-tab" class="payment-method">
            UPI/QR Payment
          </div>
        </div>

        <form action="payment-handler.php" method="POST">
          <div class="products">
            <h3 class="title">Checkout</h3>

            <?php
            $total=00;
            foreach ($booking_item_list as $booking_item) : ?>
                <?php $total += $booking_item['price']; ?>
              <div class="item">
              <p class="item-name"><?php echo $booking_item['service_name']; ?></p>
             
              <span class="price">$<?php echo $booking_item['price']; ?></span>
              </div>
              

            <?php endforeach; ?>
            
            <div class="total">Total <span class="price">$<?php echo $total;?></span></div>
            <input type="hidden" name="amount" value="<?php echo $total;?>" />
          </div>

          <!-- Credit Card Payment Section -->
          <div class="card-details" id="card-payment">
            <h3 class="title">Credit Card Details</h3>
            <div class="row">
              <div class="form-group col-sm-7">
                <label for="card-holder">Card Holder</label>
                <input id="card-holder" type="text" class="form-control" placeholder="Card Holder" required>
              </div>
              <div class="form-group col-sm-5">
                <label for="expiry-date">Expiration Date</label>
                <div class="input-group expiration-date">
                  <input type="text" class="form-control" placeholder="MM" required>
                  <span class="date-separator">/</span>
                  <input type="text" class="form-control" placeholder="YY" required>
                </div>
              </div>
              <div class="form-group col-sm-8">
                <label for="card-number">Card Number</label>
                <input id="card-number" type="text" class="form-control" placeholder="Card Number" required>
              </div>
              <div class="form-group col-sm-4">
                <label for="cvc">CVC</label>
                <input id="cvc" type="text" class="form-control" placeholder="CVC" required>
              </div>
              <div class="form-group col-sm-12">
                <button type="submit" class="btn btn-primary btn-block">Proceed</button>
              </div>
            </div>
          </div>

          <!-- UPI/QR Payment Section -->
          <div class="upi-section" id="upi-payment">
            <h3 class="title">Scan QR to Pay</h3>
            <div class="qr-code">
              <img src="https://via.placeholder.com/150" alt="QR Code">
              <p>Scan the QR code with your UPI app to complete the payment.</p>
            </div>
          </div>
        </form>
      </div>
    </section>
  </main>

  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script>
    // Handle toggling between Credit Card and UPI sections
    $('#credit-card-tab').on('click', function() {
      $('#credit-card-tab').addClass('active');
      $('#upi-tab').removeClass('active');
      $('#card-payment').show();
      $('#upi-payment').hide();
    });

    $('#upi-tab').on('click', function() {
      $('#upi-tab').addClass('active');
      $('#credit-card-tab').removeClass('active');
      $('#card-payment').hide();
      $('#upi-payment').show();
    });

    // Set default to show Credit Card payment
    $(document).ready(function() {
      $('#card-payment').show();
      $('#upi-payment').hide();
    });
  </script>
</body>
</html>




