<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require_once __DIR__ . '/../../application/libraries/Paypal/vendor/autoload.php';// If using Composer for PayPal SDK
require_once __DIR__ . '/../../application/master/MasterCommand.php';
require_once __DIR__ . '/../../application/master/MasterService.php';
require_once __DIR__ . '/../../application/utils/Response.php';
require_once __DIR__ . '/fpdf184/fpdf.php';


use MasterCommand\MasterCommand;
use MasterService\MasterService;
use Inspire\Ahms\Application\Utils\Response;

$MasterCommand = new MasterCommand();
$MasterService = new MasterService();

$clientId = 'AaKvwmKwhFxGpa42hCKxjksee9oLy2GD6cJ-1JGfaNI0Yu1BDebNhHO4ODSL0V-OhF9P5BjVDTLsQpTv';  // Replace with your Client ID
$clientSecret = 'EI89H6VsnXzoiYAakmsh6lTcR_KRyd2DkueCQE8fkMuAkCM17AiAW5drpnEoI9Za6kFXdTmI8zVj8nOe';  // Replace with your Client Secret

$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        $clientId,
        $clientSecret
    )
);


$payment_details = $_POST['details'];
$booking_details = $_POST['booking_item_list'];


$payment = $payment_details['purchase_units'][0]['payments']['captures'][0];


$payment_add = $MasterCommand->AddPayment($payment,$booking_details[0]);


if ($payment_add['is_added']) {

    echo Response::generateJSONResponse(200, 'Thank You For Payment.', ['payment_confirm' => $payment_add['is_added']]);


    // exit;
} 


?>
