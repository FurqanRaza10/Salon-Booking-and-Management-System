<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);


require_once __DIR__ . '/../../application/master/MasterCommand.php';
require_once __DIR__ . '/../../application/master/MasterService.php';
require_once __DIR__ . '/../../application/utils/Response.php';
require_once __DIR__ . '/fpdf184/fpdf.php';


use MasterCommand\MasterCommand;
use MasterService\MasterService;
use Inspire\Ahms\Application\Utils\Response;

$MasterCommand = new MasterCommand();
$MasterService = new MasterService();


$booking_no = isset($_GET['booking_no']) ? $_GET['booking_no'] : 0;


class PDF extends FPDF {
    // Page header
    function Header() {
        // Logo
        //$this->Image('logo.png',10,6,30); // Path to your logo image
        $this->SetFont('Arial','B',15);
        $this->Cell(0,10,'Invoice',0,1,'C');
        $this->Ln(10);
    }

    // Page footer
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

    // Fetch invoice details
    //$sql = "SELECT * FROM `invoices` as inv INNER JOIN customer_master as cm ON inv.customer_id=cm.customer_id INNER JOIN booking_master as bm ON inv.booking_no=bm.booking_no WHERE inv.transcation_id=:transction_id";
    $invoice_details = $MasterService->getInvoiceMainDetails($booking_no);//$payment['id']

    // print_r($invoice_details);
    
    
    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','',12);
    
    // Invoice and customer details
    $pdf->Cell(0,10,'Invoice Number: ' . $invoice_details[0]['invoce_id'],0,1);
    $pdf->Cell(0,10,'Transction Id: ' . $invoice_details[0]['transcation_id'],0,1);
    $pdf->Cell(0,10,'Invoice Date: ' . date('d-m-Y', strtotime($invoice_details[0]['transaction_date'])),0,1);
    $pdf->Cell(0,10,'Customer Name: ' . $invoice_details[0]['customer_name'],0,1);
    $pdf->Cell(0,10,'Customer Mobile No: ' . $invoice_details[0]['mobile_no'],0,1);
    $pdf->Ln(10);


    // item details
    $invoice_item_details = $MasterService->getInvoiceItemDetails($booking_no);
    
    // Table header
    $pdf->SetFont('Times','B',12);
    $pdf->Cell(40,7,'Service Name',1);
    $pdf->Cell(40,7,'Quantity',1);
    $pdf->Cell(50,7,'Total',1);
    $pdf->Ln();
    
    // Table rows
    $pdf->SetFont('Times','',12);
    $GRAND_TOTAL = 0;
    foreach ($invoice_item_details as $item) {
        $pdf->Cell(40,6,$item['service_name'],1);
        $pdf->Cell(40,6,1,1);
        $pdf->Cell(50,6,number_format($item['price'], 2),1);
        $pdf->Ln();
        $GRAND_TOTAL += $item['price'];
    }
    
    // Convert total amount to words
    //$obj = new CanadianCurrency($invoiceDetails['GRAND_TOTAL']);
    $words = '$';
    
    $pdf->Ln(10);
    $pdf->SetFont('Times','B',12);
    $pdf->Cell(0,10,'Total Amount: ' . number_format($GRAND_TOTAL, 2) . ' (' . $words . ')',0,1);
    ob_end_clean();
    $pdf->Output('D', 'Invoice_'.$invoice_details[0]['invoce_id'].'.pdf');
    

?>
