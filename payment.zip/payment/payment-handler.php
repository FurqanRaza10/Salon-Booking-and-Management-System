<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the PayPal SDK
require_once __DIR__ . '/../../application/libraries/Paypal/vendor/autoload.php'; // If using Composer for PayPal SDK
require_once __DIR__ . '/../../application/utils/app_config.php';


// Set up PayPal API credentials
$clientId = 'AaKvwmKwhFxGpa42hCKxjksee9oLy2GD6cJ-1JGfaNI0Yu1BDebNhHO4ODSL0V-OhF9P5BjVDTLsQpTv';  // Replace with your Client ID
$secret = 'EI89H6VsnXzoiYAakmsh6lTcR_KRyd2DkueCQE8fkMuAkCM17AiAW5drpnEoI9Za6kFXdTmI8zVj8nOe';  // Replace with your Client Secret

// Set up PayPal API context
$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        $clientId,     // ClientID
        $secret        // ClientSecret
    )
);

// Get the payment details from the request (amount, currency)
$paymentAmount = $_POST['amount'];
$currency = $_POST['currency'];

// Create a payer object
$payer = new \PayPal\Api\Payer();
$payer->setPaymentMethod("paypal");

// Set up the payment amount and details
$amountDetails = new \PayPal\Api\Details();
$amountDetails->setSubtotal($paymentAmount);

$paymentAmountObj = new \PayPal\Api\Amount();
$paymentAmountObj->setCurrency($currency)
                 ->setTotal($paymentAmount)
                 ->setDetails($amountDetails);

// Set up the transaction
$transaction = new \PayPal\Api\Transaction();
$transaction->setAmount($paymentAmountObj)
            ->setDescription("Payment for services");

// Set up redirect URLs
$redirectUrls = new \PayPal\Api\RedirectUrls();
$redirectUrls->setReturnUrl("http://localhost/salon_booking/view/payment/payment_success.php?success=true")
             ->setCancelUrl("http://localhost/salon_booking/view/payment/payment_success.php?success=false");

// Create the payment object
$payment = new \PayPal\Api\Payment();
$payment->setIntent("sale")
        ->setPayer($payer)
        ->setTransactions([$transaction])
        ->setRedirectUrls($redirectUrls);

// Create the payment and get the approval URL
try {
    $payment->create($apiContext);
    echo json_encode(["orderID" => $payment->getId()]);
} catch (\PayPal\Exception\PayPalConnectionException $ex) {
    echo json_encode(["error" => $ex->getMessage()]);
}
